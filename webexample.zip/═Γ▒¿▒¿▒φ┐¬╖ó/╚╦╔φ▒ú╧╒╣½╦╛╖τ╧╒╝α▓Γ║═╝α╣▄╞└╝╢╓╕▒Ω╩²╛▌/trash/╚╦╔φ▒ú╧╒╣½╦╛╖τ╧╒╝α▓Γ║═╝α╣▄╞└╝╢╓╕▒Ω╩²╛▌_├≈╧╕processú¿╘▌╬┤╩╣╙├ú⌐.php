<h> 注意：</h>
<br>
<h>使用前，务必确认已结账及完成统信报送;</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
    // 构建SQL查询  
    $sql = "

 	declare  @zyear VARCHAR(4) ;  set  @zyear = $zyear ;
	declare  @zmonth VARCHAR(2) ;  set  @zmonth = $zmonthS  ;  ---起期
  if len(@zmonth) = 1   SET    @zmonth = concat('0',@zmonth);


 with  temp0 as (  SELECT  *  FROM [CIRC].[dbo].[circ]
  where  [机构编码] = '000000'
  and 指标类型 <> '快报' 
  and 指标类型 <> '年度报'  
  and ( [期间] = concat(@zyear,@zmonth)  or  [期间] = concat(@zyear -1,@zmonth)  )) ,
  temp1 as (
SELECT  '原保险保费收入'AS 指标 , [指标值] as 金额 ,[指标名称] as 备注  FROM temp0
  where [指标代码] ='a60320001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,@zmonth)
union all 
SELECT '客户储金及投资款的新增金额' AS 指标 , [指标值] ,[指标名称]  FROM temp0
  where [指标代码] ='61720001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,@zmonth)
union all 
SELECT '独立账户负债的新增交费' AS 指标 , [指标值],[指标名称]    FROM temp0
  where [指标代码] ='61740001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,@zmonth)
  ---------14
union all 
SELECT '长期险本期规模保费收入' AS 指标 , 
sum( case 
when [指标代码] = 'a60320001' then  [指标值] 
when [指标代码] in( 'a60320175','a60321678','a60320184','a60320192') then -[指标值] else 0  end ) ,''    FROM temp0
  where [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
union all 
SELECT '长期险上年同期规模保费收入' AS 指标 , 
sum( case 
when [指标代码] = 'a60320001' then  [指标值] 
when [指标代码] in( 'a60320175','a60321678','a60320184','a60320192') then -[指标值] else 0  end ),''    FROM temp0
  where [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear -1 ,@zmonth)
 
  ---------15
union all 
SELECT  '长期险本期新单规模保费收入' AS 指标 , sum([指标值]) ,''    FROM temp0
  where [指标代码] in ('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320072','a60320076','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116','a60320124',
'a60320128','a60320145','a60320149','a60320201','a60320210','a60321681')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
union all 
SELECT  '长期险上年同期新单规模保费收入' AS 指标 , sum([指标值]),''    FROM temp0
  where [指标代码] in ('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320072','a60320076','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116','a60320124',
'a60320128','a60320145','a60320149','a60320201','a60320210','a60321681')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear -1 ,@zmonth)
--------16续期倒减
 ---------20

 union all 
SELECT  '长期险分销售渠道保费占比' AS 指标 , sum([指标值]),'个人代理渠道'    FROM temp0
  where [指标代码] in ('a60320221','a60320229','a60320237','a60320245','a60320258')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险分销售渠道保费占比' AS 指标 , sum([指标值]),'银行邮政代理渠道'    FROM temp0
  where [指标代码] in ('a60320324','a60320332','a60320340','a60320348','a60320361')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险分销售渠道保费占比' AS 指标 , sum([指标值]),'保险经纪渠道'    FROM temp0
  where [指标代码] in ('a60320383','a60320392')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险分销售渠道保费占比' AS 指标 , sum([指标值]),'公司直销渠道'    FROM temp0
  where [指标代码] in ('a60320264','a60320272','a60320280','a60320288','a60320301')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险分销售渠道保费占比' AS 指标 , sum([指标值]),'其他渠道'    FROM temp0
  where [指标代码] in ('a60320306','a60320317','a60320366','a60320377')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 ---------21
 union all 
SELECT  '长期险各险种类别的新单规模保费' AS 指标 , 
sum(  case 
when [指标代码] in('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320124','a60320128','a60320145','a60320149') then  [指标值] 
when [指标代码] in('a60320133','a60320137','a60320154','a60320158') then - [指标值] 
else 0 end ) ,'人寿保险（定期寿险、终身寿险、两全寿险）'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险各险种类别的新单规模保费' AS 指标 , 
sum(  case 
when [指标代码] in('a60320072','a60320076','a60320112','a60320116','a60320133','a60320137','a60320154','a60320158') then  [指标值] 
else 0 end ) ,'年金保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险各险种类别的新单规模保费' AS 指标 , 
sum( case 
when [指标代码] in('a60320201','a60320210') then  [指标值] 
else 0 end) ,'健康保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
SELECT  '长期险各险种类别的新单规模保费' AS 指标 , 
sum( case 
when [指标代码] in('a60321681') then  [指标值] 
else 0 end) ,'意外伤害保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
    
 ---------22
 union all 
 SELECT  '长期险各设计类型的新单规模保费' AS 指标 , 
sum( case 
when [指标代码] in( 'a60320045',  'a60320049',  'a60320054',  'a60320058',  'a60320063',  'a60320067',  'a60320072',  'a60320076',  'a60321681',  'a60320201',  'a60320210' ) then  [指标值] 
else 0 end ), '普通型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 union all 
 SELECT  '长期险各设计类型的新单规模保费' AS 指标 , 
sum( case 
when [指标代码] in('a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116') then  [指标值] 
else 0 end) ,'分红型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth) 
 union all 
 SELECT  '长期险各设计类型的新单规模保费' AS 指标 , 
sum( case 
when [指标代码] in('a60320124','a60320128','a60320145','a60320149') then  [指标值] 
else 0 end ),'万能及投资连结型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
   
 ---------33
 union all
 
SELECT  top(3)  '长期险佣金' AS 指标 , sum( 本期余额)  as 金额 ,  ''
from [DJSX].[dbo].[balance]
where [会计年度] = @zyear 
and [会计期间] between '01' and  @zmonth
and 长短期描述  = '长期'
and  ( 科目 like '6421%' or   科目 like '640201%'  )
 
 ---------36
union all 

SELECT  '短期险的规模保费收入' AS 指标 , 
sum( case 
when [指标代码] in('a60320172','a60320175','a60320183') then  [指标值] 
else 0 end ),'本年累计'     FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,@zmonth)
 
union all 

SELECT  '短期险的直接佣金' AS 指标 , sum(本期余额)  ,'本年累计' as 备注
from [DJSX].[dbo].[balance]
where [会计年度] = @zyear 
and [会计期间] between '01' and  @zmonth
and 长短期描述  like  '短期%'
and  ( 科目 like '6421%' or   科目 like '640201%'  )
and 科目描述 not like '%间接%'
) ,
temp2 as (

 ---------23
SELECT  top(3)  '前三位长期险产品的新单规模保费之和' AS 指标 , sum( - 本期余额)  as 金额 ,
[产品描述]
from [DJSX].[dbo].[balance]
where [会计年度] = @zyear 
and [会计期间] between '01' and  @zmonth
and 长短期描述  = '长期'
and  ( 科目 in ('2721010100','2711100000','2711101010') or ( 科目 like '603101%' and [产品描述] not like '%万能%'  and  [产品描述] not like '%投资连结%'  ))
group by [产品描述] 
order by 金额 desc 
)
 select * from temp1
 order by 指标

  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>

<br>	<h>	原保险保费收入占比	</h>	<br>	<h>	F=原保险保费收入/（原保险保费收入+客户储金及投资款的新增金额+独立账户负债的新增交费）	</h>	<br>	<br>
	<h>	长期险规模保费收入增长率	</h>	<br>	<h>	F=长期险本期规模保费收入/长期险上年同期规模保费收入-1	</h>	<br>	<br>
	<h>	长期险新单规模保费收入增长率	</h>	<br>	<h>	F=长期险本期新单规模保费收入/长期险上年同期新单规模保费收入-1	</h>	<br>	<br>
	<h>	长期险续期规模保费增长率	</h>	<br>	<h>	F=长期险本期续期规模保费收入/长期险上年同期续期规模保费收入-1	</h>	<br>	<br>
	<h>	长期险分销售渠道保费占比	</h>	<br>	<h>	F=长期险各销售渠道的新单规模保费/长期险新单规模保费
其中：
销售渠道包括个人代理渠道、银行邮政代理渠道、保险经纪渠道、公司直销渠道、其他渠道    	</h>	<br>	<br>
	<h>	长期险分险种类别保费占比	</h>	<br>	<h>	F=长期险各险种类别的新单规模保费/长期险新单规模保费
其中：
险种类别包括人寿保险（定期寿险、终身寿险、两全寿险）、年金保险、健康保险、意外伤害保险	</h>	<br>	<br>
	<h>	长期险分设计类型保费占比	</h>	<br>	<h>	F=长期险各设计类型的新单规模保费/长期险新单规模保费
其中：
1.设计类型包括普通型、分红型、万能及投资连结型
2.“个人税收递延型商业养老保险”、“专属商业养老保险”计入普通型	</h>	<br>	<br>
	<h>	前三大长期险产品保费集中度	</h>	<br>	<h>	F=前三位长期险产品的新单规模保费之和/长期险新单规模保费	</h>	<br>	<br>
	<h>	长期险业务及管理费比率	</h>	<br>	<h>	F=长期险业务及管理费/长期险规模保费
其中：
业务及管理费数据按实际支付口径填报	</h>	<br>	<br>
	<h>	长期险佣金比率	</h>	<br>	<h>	F=长期险佣金/长期险规模保费
其中：
佣金数据按实际支付口径填报	</h>	<br>	<br>
	<h>	短期险直接佣金比率	</h>	<br>	<h>	F=短期险的直接佣金/短期险的规模保费收入
其中：
1.佣金数据按实际支付口径填报
2.产品统计范围不包括城乡居民大病保险业务	</h>	<br>	<br>