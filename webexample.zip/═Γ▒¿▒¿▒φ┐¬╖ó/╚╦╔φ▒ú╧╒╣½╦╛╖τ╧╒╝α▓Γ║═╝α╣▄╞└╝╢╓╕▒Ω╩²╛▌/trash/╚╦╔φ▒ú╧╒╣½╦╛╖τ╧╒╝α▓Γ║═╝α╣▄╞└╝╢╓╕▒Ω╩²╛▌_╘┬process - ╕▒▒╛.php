<h> 注意：</h>
<br>
<h>使用前，务必确认已结账及完成统信报送;</h>
<br>
<br>

<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
	 

    // 构建SQL查询  
    $sql = "

 	declare  @zyear VARCHAR(4) ;  set  @zyear = $zyear ;
	declare  @zmonth VARCHAR(4) ;  set  @zmonth = $zmonthS  ;  ---起期

if len(@zmonth) = 1   SET    @zmonth = concat('0',@zmonth);
  
 with  temp0 as (   
 SELECT  distinct [机构编码]      ,[指标代码]      ,[指标名称]       ,[指标值]       ,[新旧准则]      ,[期间]  FROM [CIRC].[dbo].[circ]
  where  [机构编码] = '000000'
  and 指标类型 <> '快报' 
  and 指标类型 <> '年度报'  
  and ( [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )  or  [期间] = concat(@zyear -1,case when @zmonth = 14 then 12 else @zmonth  end ) ))  
  , temp2 as (
SELECT  top(3)  '前三位长期险产品的新单规模保费之和' AS 指标 , sum( - 本期余额)  as 金额 ,
[产品描述]
from [DJSX].[dbo].[balance]
where [会计年度] = @zyear 
and [会计期间] between '01' and  @zmonth
and 长短期描述  = '长期'
and  ( 科目 in ('2721010100','2711100000','2711101010') or ( 科目 like '603101%' and [产品描述] not like '%万能%'  and  [产品描述] not like '%投资连结%'  ))
group by [产品描述] 
order by 金额 desc 
)
, temp3 as ( 


SELECT  'F10001' as 指标代码 ,   '（定期存款、协议存款、结构性存款账面余额）' AS 指标 , sum( 期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
 from [DJSX].[dbo].[balance]
where [会计年度] = @zyear 
and [会计期间] =  @zmonth
and ( 科目 like '100202%' or  科目 like '100203%' or  科目 like '100204%' )
union all 
 SELECT  'F10002' as 指标代码 ,   '自用性不动产账面余额' AS 指标 , 0  as 金额 , '短期内该值都为0' as 备注
union all
 SELECT  'F10003' as 指标代码 ,   '上季末总资产' AS 指标 , 
 sum(期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
   from [DJSX].[dbo].[balance]
where [会计年度] = ( case when @zmonth = 03 then  @zyear   -1 else @zyear  end)
and [会计期间]  =  ( case when  @zmonth = 13 or   @zmonth = 14 then  9    when  @zmonth =  03  then  14     else @zmonth - 3  end  ) 
and ( 科目 like '1%' or 科目 =  '2721030100'  )  -----独立账户负债-其他应付款-资金划拨
union all
 SELECT  'F10004' as 指标代码 ,   '去年同期公司总资产' AS 指标 , sum(期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
   from [DJSX].[dbo].[balance]
where [会计年度] = @zyear  -1 
and [会计期间]  =   @zmonth  
and ( 科目 like '1%'or 科目 =  '2721030100'  )  -----独立账户负债-其他应付款-资金划拨
union all
 SELECT  'F10005' as 指标代码 ,   '本期末公司总资产' AS 指标 , sum(期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
   from [DJSX].[dbo].[balance]
where [会计年度] = @zyear   
and [会计期间]  =   @zmonth  
and ( 科目 like '1%'or 科目 =  '2721030100'  )  -----独立账户负债-其他应付款-资金划拨
union all
 SELECT  'F40001' as 指标代码 ,   '上季度末净资产' AS 指标 , -  sum(期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
   from [DJSX].[dbo].[balance]
where [会计年度] = ( case when @zmonth = 03 then  @zyear   -1 else @zyear  end)
and [会计期间]  =  ( case when  @zmonth = 13 or   @zmonth = 14 then  9    when  @zmonth =  03  then  14     else @zmonth - 3  end  ) 
and ( 科目 between  '4000000000' and '6ZZZZZZZZZ' )
union all
 SELECT  'F40002' as 指标代码 ,   '本期末净资产' AS 指标 , -  sum(期末余额)  as 金额 , '由于重分类和审计期间调账，请与SAP资产负债表核对后使用' as 备注
   from [DJSX].[dbo].[balance]
where [会计年度] = @zyear   
and [会计期间]  =   @zmonth  
and ( 科目 between  '4000000000' and '6ZZZZZZZZZ' )
union all

SELECT   'F60001' as 指标代码 ,    '原保险保费收入'AS 指标 , [指标值] as 金额 ,[指标名称] as 备注  FROM temp0
  where [指标代码] ='a60320001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end)

union all
SELECT   'F60002' as 指标代码 ,    '新单规模保费收入'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where 科目 like '603101%'
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%'  
 
union all
SELECT   'F60003' as 指标代码 ,    '长期险首年期交的规模保费收入'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or  科目 =  '6031010300')
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%'  
 union all
SELECT   'F60004' as 指标代码 ,    '长期险趸交的规模保费收入'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010100'  )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%'  

 union all
SELECT   'F60005' as 指标代码 ,  '长期险本期规模保费收入' AS 指标 , 
sum( case 
when [指标代码] = 'a60320001' then  [指标值] 
when [指标代码] in( 'a60320175','a60321678','a60320184','a60320192') then -[指标值] else 0  end ) ,''    FROM temp0
  where [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )

 union all
SELECT   'F60006' as 指标代码 ,'长期险上年同期规模保费收入' AS 指标 , 
sum( case 
when [指标代码] = 'a60320001' then  [指标值] 
when [指标代码] in( 'a60320175','a60321678','a60320184','a60320192') then -[指标值] else 0  end ),''    FROM temp0
  where [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear -1 ,case when @zmonth = 14 then 12 else @zmonth  end )

 union all
SELECT   'F60007' as 指标代码 , '长期险本期新单规模保费收入' AS 指标 , sum([指标值]) ,''    FROM temp0
  where [指标代码] in ('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320072','a60320076','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116','a60320124',
'a60320128','a60320145','a60320149','a60320201','a60320210','a60321681')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )

 union all
SELECT   'F60008' as 指标代码 ,'长期险上年同期新单规模保费收入' AS 指标 , sum([指标值]),''    FROM temp0
  where [指标代码] in ('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320072','a60320076','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116','a60320124',
'a60320128','a60320145','a60320149','a60320201','a60320210','a60321681')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear -1 ,case when @zmonth = 14 then 12 else @zmonth  end )

 union all
SELECT   'F60011' as 指标代码 ,'前三位长期险产品的新单规模保费之和' AS 指标 , sum(金额),'' from temp2

 
union all 
SELECT  'F600121', '长期险分销售渠道保费占比-个人代理渠道' AS 指标 , sum([指标值]),'个人代理渠道'    FROM temp0
  where [指标代码] in ('a60320221','a60320229','a60320237','a60320245','a60320258')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT   'F600122','长期险分销售渠道保费占比-银行邮政代理渠道' AS 指标 , sum([指标值]),'银行邮政代理渠道'    FROM temp0
  where [指标代码] in ('a60320324','a60320332','a60320340','a60320348','a60320361')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT   'F600123', '长期险分销售渠道保费占比-保险经纪渠道' AS 指标 , sum([指标值]),'保险经纪渠道'    FROM temp0
  where [指标代码] in ('a60320383','a60320392')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT  'F600124',  '长期险分销售渠道保费占比-公司直销渠道' AS 指标 , sum([指标值]),'公司直销渠道'    FROM temp0
  where [指标代码] in ('a60320264','a60320272','a60320280','a60320288','a60320301')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT  'F600125',  '长期险分销售渠道保费占比-其他渠道' AS 指标 , sum([指标值]),'其他渠道'    FROM temp0
  where [指标代码] in ('a60320306','a60320317','a60320366','a60320377')
  and [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 ---------21
 union all 
SELECT  'F600131',  '长期险各险种类别的新单规模保费-人寿保险（定期寿险、终身寿险、两全寿险）' AS 指标 , 
sum(  case 
when [指标代码] in('a60320045','a60320049','a60320054','a60320058','a60320063','a60320067','a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320124','a60320128','a60320145','a60320149') then  [指标值] 
when [指标代码] in('a60320133','a60320137','a60320154','a60320158') then - [指标值] 
else 0 end ) ,'人寿保险（定期寿险、终身寿险、两全寿险）'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT  'F600132',  '长期险各险种类别的新单规模保费-年金保险' AS 指标 , 
sum(  case 
when [指标代码] in('a60320072','a60320076','a60320112','a60320116','a60320133','a60320137','a60320154','a60320158') then  [指标值] 
else 0 end ) ,'年金保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT   'F600133', '长期险各险种类别的新单规模保费-健康保险' AS 指标 , 
sum( case 
when [指标代码] in('a60320201','a60320210') then  [指标值] 
else 0 end) ,'健康保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
SELECT  'F600134',  '长期险各险种类别的新单规模保费-意外伤害保险' AS 指标 , 
sum( case 
when [指标代码] in('a60321681') then  [指标值] 
else 0 end) ,'意外伤害保险'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
    
 ---------22
 union all 
 SELECT   'F600141', '长期险各设计类型的新单规模保费-普通型' AS 指标 , 
sum( case 
when [指标代码] in( 'a60320045',  'a60320049',  'a60320054',  'a60320058',  'a60320063',  'a60320067',  'a60320072',  'a60320076',  'a60321681',  'a60320201',  'a60320210' ) then  [指标值] 
else 0 end ), '普通型-“个人税收递延型商业养老保险”、“专属商业养老保险”计入普通型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
 union all 
 SELECT  'F600142',  '长期险各设计类型的新单规模保费-分红型' AS 指标 , 
sum( case 
when [指标代码] in('a60320085','a60320089','a60320094','a60320098','a60320103','a60320107','a60320112','a60320116') then  [指标值] 
else 0 end) ,'分红型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end ) 
 union all 
 SELECT  'F600143',  '长期险各设计类型的新单规模保费-万能及投资连结型' AS 指标 , 
sum( case 
when [指标代码] in('a60320124','a60320128','a60320145','a60320149') then  [指标值] 
else 0 end ),'万能及投资连结型'    FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )

union all 

SELECT  'F60015', '短期险的规模保费收入' AS 指标 , 
sum( case 
when [指标代码] in('a60320172','a60320175','a60320183') then  [指标值] 
else 0 end ),'本年累计'     FROM temp0
  where   [机构编码] = '000000'
  and [新旧准则] = '旧准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )

  union all 
SELECT 'F60016','客户储金及投资款的新增金额' AS 指标 , [指标值] ,[指标名称]  FROM temp0
  where [指标代码] ='61720001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )
union all 
SELECT 'F60017', '独立账户负债的新增交费' AS 指标 , [指标值],[指标名称]    FROM temp0
  where [指标代码] ='61740001'
  and [机构编码] = '000000'
  and [新旧准则] = '新准则'
  and [期间] = concat(@zyear,case when @zmonth = 14 then 12 else @zmonth  end )

   union all
SELECT   'F600181' as 指标代码 ,    '长期险各销售渠道首年期交的规模保费收入-个人代理渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or   科目 =  '6031010300' )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '101%'
   union all
SELECT   'F600182' as 指标代码 ,    '长期险各销售渠道首年期交的规模保费收入-银行邮政代理渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or   科目 =  '6031010300' )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '103%'
	   union all
SELECT   'F600183' as 指标代码 ,    '长期险各销售渠道首年期交的规模保费收入-保险经纪渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or   科目 =  '6031010300' )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '104002%'
	   union all
SELECT   'F600184' as 指标代码 ,    '长期险各销售渠道首年期交的规模保费收入-公司直销渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or   科目 =  '6031010300' )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  ( 渠道 like '102%' or 渠道 in ('104003','104004'))
	   union all
SELECT   'F600185' as 指标代码 ,    '长期险各销售渠道首年期交的规模保费收入-其他渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where ( 科目 =  '6031010200' or   科目 =  '6031010300' )
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  ( 渠道 not like '102%' or 渠道 not in ('104002','104003','104004') or 渠道 not like '101%'or 渠道 not like '103%'  ) 

  union all
SELECT   'F600191' as 指标代码 ,    '长期险各销售渠道趸交的规模保费收入-个人代理渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where  科目 =  '6031010100' 
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '101%'
   union all
SELECT   'F600192' as 指标代码 ,    '长期险各销售渠道趸交的规模保费收入-银行邮政代理渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where  科目 =  '6031010100' 
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '103%'
	   union all
SELECT   'F600193' as 指标代码 ,    '长期险各销售渠道趸交的规模保费收入-保险经纪渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where  科目 =  '6031010100' 
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  渠道 like '104002%'
	   union all
SELECT   'F600194' as 指标代码 ,    '长期险各销售渠道趸交的规模保费收入-公司直销渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where  科目 =  '6031010100' 
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'  
	 and  [产品描述] not like '%投资连结%' 
	 and  ( 渠道 like '102%' or 渠道 in ('104003','104004'))
	   union all
SELECT   'F600195' as 指标代码 ,    '长期险各销售渠道趸交的规模保费收入-其他渠道'AS 指标 , -  sum(本期余额) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
  where  科目 =  '6031010100'  
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	 and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
	 and  ( 渠道 not like '102%' or 渠道 not in ('104002','104003','104004') or 渠道 not like '101%'or 渠道 not like '103%'  ) 
	   union all
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------增加二次指标
SELECT   'F60021' as 指标代码 ,    '长期险首年期交的交费期间×长期险首年期交的各交费期间的规模保费收入'AS 指标 ,   sum(- 本期余额*缴费年期) as 金额 ,'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
   where    科目 like  '603101%'   
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
    and 长短期描述  = '长期'

	   union all
SELECT   'F60023' as 指标代码 ,    '长期险趸交的规模保费收入'AS 指标 ,  sum(- 本期余额 )   as 金额 ,'产品统计范围不包括投资连结型、万能型产品； 财务数据无法区分佣金的期趸交' as 备注     
from [DJSX].[dbo].[balance]
   where    科目 =   '6031010100'   
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
    and 长短期描述  = '长期'
	   union all
SELECT   'F60024' as 指标代码 ,    '本期标准保费'AS 指标 ,  
sum( 
case 
when   科目 =    '6031010100'                                                         then  - 本期余额*0.1
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  <>  '长期' then  - 本期余额
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  =   '长期' and 缴费年期*1  between  1 and 10   then  - 本期余额*缴费年期/10
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  =   '长期' and 缴费年期*1  > 10    then  - 本期余额
end 
)    as 金额 ,
'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
   where (  科目  like '603101%')
	and [会计年度] = @zyear 
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
  
	   union all
SELECT   'F60024' as 指标代码 ,    '上年同期标准保费'AS 指标 ,   
sum( 
case 
when   科目 =    '6031010100'                                                         then  - 本期余额*0.1
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  <>  '长期' then  - 本期余额
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  =   '长期' and 缴费年期*1  between  1 and 10   then  - 本期余额*缴费年期/10
when ( 科目 <>   '6031010100'    and 科目  like '603101%') and   长短期描述  =   '长期' and 缴费年期*1  > 10    then  - 本期余额
end  )    as 金额 ,
'产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
   where (  科目  like '603101%')
	and [会计年度] = @zyear  -1 
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
 
	   union all
SELECT   
case 
when  渠道 like '101%'  then   'F600271' 
when  渠道 like '103%'  then   'F600272' 
when  渠道   =  '104002'  then   'F600273' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   'F600274' 
else       'F600275'   end  as 指标代码 ,   
case 
when  渠道 like '101%'  then   '长期险首年期交的规模保费收入-个人代理渠道' 
when  渠道 like '103%'  then   '长期险首年期交的规模保费收入-银行邮政代理渠道' 
when  渠道   =  '104002'  then   '长期险首年期交的规模保费收入-保险经纪渠道' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   '长期险首年期交的规模保费收入-公司直销渠道' 
else       '长期险首年期交的规模保费收入-其他渠道'   end    AS 指标 ,   
sum( - 本期余额 )    as 金额 ,  '产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
   where (  科目  between  '6031010200' and  '6031010300'  )
	and [会计年度] = @zyear  
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
group by case 
when  渠道 like '101%'  then   'F600271' 
when  渠道 like '103%'  then   'F600272' 
when  渠道   =  '104002'  then   'F600273' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   'F600274' 
else       'F600275'   end    ,   
case 
when  渠道 like '101%'  then   '长期险首年期交的规模保费收入-个人代理渠道' 
when  渠道 like '103%'  then   '长期险首年期交的规模保费收入-银行邮政代理渠道' 
when  渠道   =  '104002'  then   '长期险首年期交的规模保费收入-保险经纪渠道' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   '长期险首年期交的规模保费收入-公司直销渠道' 
else       '长期险首年期交的规模保费收入-其他渠道'   end   
union all
SELECT   
case 
when  渠道 like '101%'  then   'F600291' 
when  渠道 like '103%'  then   'F600292' 
when  渠道   =  '104002'  then   'F600293' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   'F600294' 
else       'F600295'   end  as 指标代码 ,   
case 
when  渠道 like '101%'  then   '长期险趸交的规模保费收入-个人代理渠道' 
when  渠道 like '103%'  then   '长期险趸交的规模保费收入-银行邮政代理渠道' 
when  渠道   =  '104002'  then   '长期险趸交的规模保费收入-保险经纪渠道' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   '长期险趸交的规模保费收入-公司直销渠道' 
else       '长期险趸交的规模保费收入-其他渠道'   end    AS 指标 ,   
sum( - 本期余额 )    as 金额 ,  '产品统计范围不包括投资连结型、万能型产品' as 备注     
from [DJSX].[dbo].[balance]
   where (  科目  =  '6031010100'    )
	and [会计年度] = @zyear  
	and [会计期间] between '01' and  @zmonth
	and [产品描述] not like '%万能%'   	 and  [产品描述] not like '%投资连结%' 
group by 
case 
when  渠道 like '101%'  then   'F600291' 
when  渠道 like '103%'  then   'F600292' 
when  渠道   =  '104002'  then   'F600293' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   'F600294' 
else       'F600295'   end ,   
case 
when  渠道 like '101%'  then   '长期险趸交的规模保费收入-个人代理渠道' 
when  渠道 like '103%'  then   '长期险趸交的规模保费收入-银行邮政代理渠道' 
when  渠道   =  '104002'  then   '长期险趸交的规模保费收入-保险经纪渠道' 
when  渠道 like '102%'  or  渠道 between '104003' and '104004'   then   '长期险趸交的规模保费收入-公司直销渠道' 
else       '长期险趸交的规模保费收入-其他渠道'   end 	 
)

select 指标代码 ,	指标,	case when 金额 is null then 0 else 金额 end as 金额 ,备注
 from temp3
order by 指标代码

  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>