 
<br>
<h>业务数据明细表_6储金合同收入-分机构本期</h><br><br>
<h>注意:请确认已结账、数据库已更新数据。对外提供前，请与SAP相关报表核对总数。</h>	<br><br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonth = $_POST['zmonth'];  
}  
 
echo "报表期间: " . $zyear .  "-" . $zmonth  ;
     // 构建SQL查询 --------------------------------------------------------------------------------------------------1 
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
 select  '储金合同收入-分机构本期', @zyear as 会计年度,@zmonth as 会计期间,[公司代码],[公司描述], [科目], [科目描述] , 产品,产品描述,sum( -[本期余额]  ) as  '本期余额' 
   FROM [DJSX].[dbo].[balance]
 where  会计年度 =  @zyear 
  and 会计期间 =   @zmonth
  and 科目 like  '271110%'
     group by [公司代码],[公司描述], [科目], [科目描述] , 产品,产品描述
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
echo "<br>";
echo "<br>";
   