 
<br>
<h>业务数据明细表</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonth = $_POST['zmonth'];  
}  
 
echo "报表期间: " . $zyear .  "-" . $zmonth  ;
     // 构建SQL查询 --------------------------------------------------------------------------------------------------1 
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
select  '保费收入明细表-新', 
sum(case when  会计年度 =  @zyear and 会计期间 =  @zmonth  and  新准则项目分类 like '%原保险保费收入%新单%趸交%'  then  -[本期余额] else 0 end ) as  '新单趸交(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =  @zmonth  and  新准则项目分类 like '%原保险保费收入%新单%期交%'  then  -[本期余额] else 0 end ) as  '新单期交(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =  @zmonth  and  新准则项目分类 like '%原保险保费收入%续期%'  then  -[本期余额] else 0 end ) as  '续期(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%原保险保费收入%新单%趸交%'  then  -[本期余额] else 0 end ) as  '新单趸交(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%原保险保费收入%新单%期交%'  then  -[本期余额] else 0 end ) as  '新单期交(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%原保险保费收入%续期%'  then  -[本期余额] else 0 end ) as  '续期(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%原保险保费收入%'  then  -[本期余额] else 0 end ) as  '保费收入(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%原保险保费收入%'  then  -[本期余额] else 0 end ) as  '保费收入(累计)' 
  FROM [DJSX].[dbo].[balance]
  where  会计年度 =  @zyear 
  and 会计期间 between 01 and   @zmonth
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';

echo "<br>";
echo "<br>";
     // 构建SQL查询 --------------------------------------------------------------------------------------------------2
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
select  '保费收入明细表-旧', 
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%保费收入%'  then  -[本期余额] else 0 end ) as  '本期规模保费(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%保费收入%'  then  -[本期余额] else 0 end ) as  '本年累计规模保费(累计)' 
  FROM [DJSX].[dbo].[balance]
  where  会计年度 =  @zyear 
  and 会计期间 between 01 and   @zmonth
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
echo "<br>";
echo "<br>";
     // 构建SQL查询 --------------------------------------------------------------------------------------------------3
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
select  '业务支出明细表-新', 
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%赔款支出%'  then  [本期余额] else 0 end ) as  '赔款支出(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%赔款支出%'  then  [本期余额] else 0 end ) as  '赔款支出(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%死伤医疗%'  then  [本期余额] else 0 end ) as  '死伤医疗(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%死伤医疗%'  then  [本期余额] else 0 end ) as  '死伤医疗(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%年金给付%'  then  [本期余额] else 0 end ) as  '年金给付(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%年金给付%'  then  [本期余额] else 0 end ) as  '年金给付(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%保单红利%'  then  [本期余额] else 0 end ) as  '保单红利(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%保单红利%'  then  [本期余额] else 0 end ) as  '保单红利(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%退保%'  then  [本期余额] else 0 end ) as  '退保(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%退保%'  then  [本期余额] else 0 end ) as  '退保(累计)',
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  新准则项目分类 like '%满期给付%'  then  [本期余额] else 0 end ) as  '满期给付(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  新准则项目分类 like '%满期给付%'  then  [本期余额] else 0 end ) as  '满期给付(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  科目 in('6051080000', '2711080000','6402040000')  then  [本期余额] else 0 end ) as  '退保金本月-万能' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and   科目  in('6051080000', '2711080000','6402040000')   then  [本期余额] else 0 end ) as  '退保金本年-万能' 
FROM [DJSX].[dbo].[balance]
 where  会计年度 =  @zyear 
  and 会计期间 between 01 and   @zmonth
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
echo "<br>";
echo "<br>";
     // 构建SQL查询 --------------------------------------------------------------------------------------------------4
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
select  '业务支出明细表-旧', 
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%赔款支出%'  then  [本期余额] else 0 end ) as  '赔款支出(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%赔款支出%'  then  [本期余额] else 0 end ) as  '赔款支出(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%死伤医疗%'  then  [本期余额] else 0 end ) as  '死伤医疗(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%死伤医疗%'  then  [本期余额] else 0 end ) as  '死伤医疗(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%年金给付%'  then  [本期余额] else 0 end ) as  '年金给付(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%年金给付%'  then  [本期余额] else 0 end ) as  '年金给付(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%满期给付%'  then  [本期余额] else 0 end ) as  '满期给付(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%满期给付%'  then  [本期余额] else 0 end ) as  '满期给付(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%保单红利%'  then  [本期余额] else 0 end ) as  '保单红利(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%保单红利%'  then  [本期余额] else 0 end ) as  '保单红利(累计)' ,
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth  and  旧准则项目分类 like '%退保%'  then  [本期余额] else 0 end ) as  '退保(本期)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between 01 and     @zmonth  and  旧准则项目分类 like '%退保%'  then  [本期余额] else 0 end ) as  '退保(累计)'
   FROM [DJSX].[dbo].[balance]
 where  会计年度 =  @zyear 
  and 会计期间 between 01 and   @zmonth
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
echo "<br>";
echo "<br>";
     // 构建SQL查询 --------------------------------------------------------------------------------------------------5
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
select  '保费收入明细表-分机构', 
sum(case when  会计年度 =  @zyear and 会计期间 =    @zmonth     then  -[本期余额] else 0 end ) as  '本期余额(本位币)' ,
sum(case when  会计年度 =  @zyear and 会计期间  between  01 and     @zmonth     then  -[本期余额] else 0 end ) as  '期末余额(本位币)' 
   FROM [DJSX].[dbo].[balance]
 where  会计年度 =  @zyear 
  and 科目 like  '6031%'
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
echo "<br>";
echo "<br>";
     // 构建SQL查询 --------------------------------------------------------------------------------------------------6
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear  ;
declare  @zmonth int ;  set  @zmonth = $zmonth   ;
 select  '储金合同收入-分机构本期', sum( -[本期余额]  ) as  '本期余额' 
   FROM [DJSX].[dbo].[balance]
 where  会计年度 =  @zyear 
  and 会计期间 =   @zmonth
  and 科目 like  '271110%'
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
echo '<table border="1"><tr><th>'.implode('</th><th>', array_keys($results[0])).'</th></tr><tr><td>'.implode('</td></tr><tr><td>', array_map('implode', array_fill(0, count($results), '</td><td>'), $results)).'</td></tr></table>';
