<h> 注意：</h>
<br>
 <h> 2023年及之前，“保户储金及保户投资款-合同收入”、“独立账户负债-账户价值-本金”按新单统计;</h>
<br>
<h>2024年及之后，“保户储金及保户投资款-合同收入”已拆分首续期，分别统计；“独立账户负债-账户价值-本金”按新单统计;</h>
<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
 
with  temp0 as( select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2711060000','2721010100','2721010400')  or  [科目]  like '6031%'   )
and 会计年度 <= 2023
and  not ((  [科目] = '2711060000'  or  [科目] =   '2721010400'   or   [科目]  like '6031%' )      and ( 产品描述 like '%万能%' or 产品描述 like '%投资连结%' ))  ------ ---20240729解决新增+续期不等于合计 ，去除风险保费部分
and ((科目 like '6031%' and 产品 not in  ('121080','121018','121022','121023','122044','121001') ) or  (科目 like '2711060000' and 产品 not in  ('121001','122035','121022','121080' ) )
or  (科目 like '27%' and 科目 <>'2711060000' )
)

union all
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or  [科目]  like '6031%'   )
and 会计年度 >= 2024
and ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or 
( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )

),
--------------------------------------------------------------------------------------------------------------------------------------基础数据

--------------------------------------------------------------------------------------------------------------------------------------本年当月
temp1 as (
select '本年当月'as  项目 ,[会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  ,  公司代码  , [公司描述] ,[科目],[科目描述],
case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end as  首续期 ,[渠道] , [渠道描述] ,[产品], [产品描述] ,
sum(- [本期余额]) as 保费金额  FROM temp0  
where  [会计年度] = @zyear   
and [会计期间] = @zmonthS
group by [会计年度]*1  ,[会计期间]*1  ,  公司代码  ,[公司描述] ,  [渠道]  , [渠道描述] ,[产品], [产品描述],[科目],[科目描述],case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end  
union all -----------------------------------------------------------------------------------------------------------------------------本年累计------------------------------------
select '本年累计'as  项目 ,[会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  ,  公司代码  , [公司描述] ,[科目],[科目描述],
case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end as  首续期 ,[渠道] , [渠道描述] ,[产品], [产品描述] ,
sum(- [本期余额]) as 保费金额  FROM temp0  
where  [会计年度] = @zyear  
and [会计期间] between  '01' and  @zmonthS
group by [会计年度]*1  ,[会计期间]*1  ,  公司代码  ,[公司描述] ,  [渠道]  , [渠道描述] ,[产品], [产品描述],[科目],[科目描述],case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end 
union all-------------------------------------------------------------------------------------------------------------------------------上年当月----------------------
select '上年当月'as  项目 ,[会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  ,  公司代码  , [公司描述] ,[科目],[科目描述],
case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end as  首续期 ,[渠道] , [渠道描述] ,[产品], [产品描述] ,
sum(- [本期余额]) as 保费金额  FROM temp0   
where  [会计年度] = @zyear   -1 
and [会计期间] = @zmonthS
group by [会计年度]*1  ,[会计期间]*1  ,  公司代码  ,[公司描述] ,  [渠道]  , [渠道描述] ,[产品], [产品描述],[科目],[科目描述],case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end 
union all ---------------------------------------------------------------------------------------------------------------------------------上年累计------------------
select '上年累计' as  项目 ,[会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  ,  公司代码  , [公司描述] ,[科目],[科目描述],case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end as  首续期 ,[渠道] , [渠道描述] ,[产品], [产品描述] ,
sum(- [本期余额]) as 保费金额  FROM temp0   
where  [会计年度] = @zyear -  1 
and [会计期间] between  '01' and  @zmonthS
group by [会计年度]*1  ,[会计期间]*1  ,  公司代码  ,[公司描述] ,  [渠道]  , [渠道描述] ,[产品], [产品描述],[科目],[科目描述],case 
when 科目 in('2711100000','6031010300','2721010100','6031010200','2711101010','6031010100' ) then '新单' 
when 科目 in('6031020000','2711102000' ) then '续期'
else 科目描述 end  
)
select @zyear as '年度', @zmonthS as '期间',[产品], [产品描述] ,
sum ( case  when 项目 = '本年当月' and   首续期 = '新单' then  保费金额 else 0 end ) as 当年当月新单@规模保费,
sum ( case  when 项目 = '本年当月' and   首续期 = '续期' then  保费金额 else 0 end ) as 当年当月续期@规模保费,
sum ( case  when 项目 = '本年当月'						 then  保费金额 else 0 end ) as 当年当月合计@规模保费,
sum ( case  when 项目 = '本年累计' and   首续期 = '新单' then  保费金额 else 0 end ) as 本年累计新单@规模保费,
sum ( case  when 项目 = '本年累计' and   首续期 = '续期' then  保费金额 else 0 end ) as 本年累计续期@规模保费,
sum ( case  when 项目 = '本年累计'						 then  保费金额 else 0 end ) as 本年累计合计@规模保费,
sum ( case  when 项目 = '上年当月' and   首续期 = '新单' then  保费金额 else 0 end ) as 上年当月新单@规模保费,
sum ( case  when 项目 = '上年当月' and   首续期 = '续期' then  保费金额 else 0 end ) as 上年当月续期@规模保费,
sum ( case  when 项目 = '上年当月'						 then  保费金额 else 0 end ) as 上年当月合计@规模保费,
sum ( case  when 项目 = '上年累计' and   首续期 = '新单' then  保费金额 else 0 end ) as 上年累计新单@规模保费,
sum ( case  when 项目 = '上年累计' and   首续期 = '续期' then  保费金额 else 0 end ) as 上年累计续期@规模保费,
sum ( case  when 项目 = '上年累计'						 then  保费金额 else 0 end ) as 上年累计合计@规模保费 
from temp1
group by [产品], [产品描述]  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>

