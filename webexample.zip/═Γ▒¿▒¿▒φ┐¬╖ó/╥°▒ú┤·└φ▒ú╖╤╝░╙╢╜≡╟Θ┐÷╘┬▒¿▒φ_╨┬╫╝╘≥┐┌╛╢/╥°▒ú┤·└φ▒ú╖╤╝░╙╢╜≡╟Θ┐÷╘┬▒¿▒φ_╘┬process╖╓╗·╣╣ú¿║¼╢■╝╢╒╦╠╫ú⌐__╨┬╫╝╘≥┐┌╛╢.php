<h> 注意：</h>
<br>
<h>仅限查询2024年及之后年份数据，2023年及之前按数据不满足统计需要;</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
    $zbukrs = $_POST['zbukrs']; 
}  
echo "公司范围: " . $zbukrs . "*";
echo "<br>";
echo "数据年份: " . $zyear ;
echo "<br>";
echo "数据月份: " . $zmonthS ;
    // 构建SQL查询  
    $sql = "
  	declare  @zyear int ;  set  @zyear = $zyear ;
	declare  @zmonthS int ;  set  @zmonthS = 01  ;  ---起期
	declare  @zmonthE int ;  set  @zmonthE = $zmonthS  ;  ---起期
	declare  @zbukrs VARCHAR(4) ;  set  @zbukrs = $zbukrs  ;  ---公司范围


	with temp0 as (
SELECT '新单保费' as '项目', aa.*
  FROM [DJSX].[dbo].[pzdetail] as aa
  where [会计年度] = @zyear
  and [会计期间] between @zmonthS AND @zmonthE
  and  [科目] like '603101%'
  and [渠道] like '103%'
  and [公司代码] between @zbukrs and  concat(@zbukrs,'Z')
union all
SELECT '续期保费' as '项目', aa.*
  FROM [DJSX].[dbo].[pzdetail] as aa
  where [会计年度] = @zyear
  and [会计期间] between @zmonthS AND @zmonthE
  and  [科目] like '603102%'
  and [渠道] like '103%'
  and [公司代码] between @zbukrs and  concat(@zbukrs,'Z')
  union all
SELECT '新单手续费' as '项目', aa.*
  FROM [DJSX].[dbo].[pzdetail] as aa
  where [会计年度] = @zyear
  and [会计期间] between @zmonthS AND @zmonthE
  and [科目] in('6421040301' )
  and [渠道] like '103%'
  and [公司代码] between @zbukrs and  concat(@zbukrs,'Z')
  )

 select [公司描述], [二级账套描述],[渠道描述],[设计类型描述],[产品描述],[缴费年期描述],
 sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then - 本期发生额 else 0 end  )						  as  新单保费@本期 ,
 sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then - 本期发生额 else 0 end  ) as  新单保费@本年累计 ,
 sum( case when 项目 = '续期保费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then - 本期发生额 else 0 end  )					      as  续期保费@本期 ,
 sum( case when 项目 = '续期保费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then - 本期发生额 else 0 end  ) as  续期保费@本年累计 ,

 sum( case when 项目 = '新单手续费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then  本期发生额 else 0 end  )					   as  新单佣金@本期 ,
 case 
 when  sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then - 本期发生额 else 0 end  ) = 0 then 0
 else   sum( case when 项目 = '新单手续费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then  本期发生额 else 0 end )/ sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] = @zmonthE  then - 本期发生额 else 0 end  )	
 end as 本期佣金率,
 sum( case when 项目 = '新单手续费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then  本期发生额 else 0 end  ) as  新单佣金@本年累计 ,
 case 
 when   sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then - 本期发生额 else 0 end  )	 = 0 then 0
 else   sum( case when 项目 = '新单手续费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then  本期发生额 else 0 end  ) / sum( case when 项目 = '新单保费' and  [会计年度] = @zyear  and [会计期间] between @zmonthS and    @zmonthE  then - 本期发生额 else 0 end  )
 end as 累计佣金率
 from temp0
 GROUP BY  [公司描述],[二级账套描述],[渠道描述],[设计类型描述],[产品描述],[缴费年期描述]
 ORDER BY [公司描述],[二级账套描述],[渠道描述],[设计类型描述],[产品描述],[缴费年期描述] ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>
