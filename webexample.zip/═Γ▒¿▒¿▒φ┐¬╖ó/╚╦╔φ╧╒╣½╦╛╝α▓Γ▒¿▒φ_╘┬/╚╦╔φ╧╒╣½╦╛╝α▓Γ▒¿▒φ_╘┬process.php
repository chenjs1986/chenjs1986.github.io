
<h>寿险整体 </h>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with temp0 as (select * 	  FROM [DJSX].[dbo].[balance]
		where  [会计年度] = @zyear 
and [会计期间] between  '01' and  @zmonthS
	and ([科目]  like '6031%' 
		or [科目] like '6511%' 
		or [科目] like '6531000000%'
		or   [科目] in(  '2703010000','2704010000')
		or  [科目] in ('2711100000','2711101010','2711101020','2711102000','2721010100')
		or [科目]   in( '6531000000','2711080000','2721010700','6402040000') 
		or ( [科目]    in(  '2703010000','2704010000') or [科目] like '2711%'  or [科目] like '2721%' )
		or (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
		)) ,
temp1 as (
	SELECT @zyear as 年份,@zmonthS as 月份 ,'原保险保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  like '6031%'
 
	union all 
	SELECT @zyear ,@zmonthS ,'期交保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  in(  '6031020000','6031010200','6031010300')
 
	union all 
	SELECT @zyear ,@zmonthS  ,'首年期交保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  in(  '6031010200','6031010300')
 
	union all  
	SELECT @zyear ,@zmonthS, '赔付支出' as 项目 ,  sum([期末余额])/100000000  as 金额
		  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    like '6511%'
 
	union all 
	SELECT @zyear ,@zmonthS, '退保金（新准则）' as 项目 ,  sum([期末余额])/100000000  as 金额
		  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    like '6531000000%'
 
	union all 
	SELECT @zyear ,@zmonthS, '准备金期初余额（新准则）' as 项目 ,  - sum([年初余额])/100000000  as 金额
		  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    in(  '2703010000','2704010000')
 
	union all 
		SELECT @zyear ,@zmonthS, '规模保费收入' as 项目 , - sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2721010100')  or ( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )
 
	union all 
	SELECT @zyear ,@zmonthS, '退保金（旧准则）' as 项目 ,  sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and [科目]   in( '6531000000','2711080000','2721010700','6402040000') 
 
	union all 
	SELECT @zyear ,@zmonthS, '新准备金和保户独立账户负债期初余额（旧准则）' as 项目 ,  - sum([年初余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and ( [科目]    in(  '2703010000','2704010000') or [科目] like '2711%'  or [科目] like '2721%' )
 
	union all 
	SELECT @zyear ,@zmonthS , '年初以来净现金流' as 项目 ,    sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
 
	union all 
	SELECT @zyear ,@zmonthS  ,'年初以来经营活动净现金流' as 项目 ,    sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
	 and ([现金流量码]  between	'AR01'	and	'AR99'	or 
[现金流量码]  between	'AP01'	and	'AP99'	)
 

),
temp2 as (
select 年份,月份,
round( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ),2)  as 原保险保费收入 ,
round(sum(case when 项目 = '期交保费收入' then 金额 else 0 end ),2) as 期交保费收入 ,
round(sum(case when 项目 = '首年期交保费收入' then 金额 else 0 end ),2) as 首年期交保费收入 ,
round(sum(case when 项目 = '赔付支出' then 金额 else 0 end ),2) as 赔付支出 ,

case when  ( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ) + sum(case when 项目 = '准备金期初余额（新准则）' then 金额 else 0 end ) ) = 0 then 0 else 
round(sum(case when 项目 = '退保金（新准则）' then 金额 else 0 end )/
( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ) + sum(case when 项目 = '准备金期初余额（新准则）' then 金额 else 0 end ) )*100 ,4) end    as '退保率（原保险保费收入）%' ,

case when  ( sum(case when 项目 = '规模保费收入' then 金额 else 0 end ) + sum(case when 项目 = '新准备金和保户独立账户负债期初余额（旧准则）' then 金额 else 0 end ) ) = 0 then 0 else 
round(sum(case when 项目 = '退保金（旧准则）' then 金额 else 0 end )/
( sum(case when 项目 = '规模保费收入' then 金额 else 0 end ) + sum(case when 项目 = '新准备金和保户独立账户负债期初余额（旧准则）' then 金额 else 0 end ) )*100 ,4) end   as '退保率（规模保费）%' ,

round(sum(case when 项目 = '年初以来净现金流' then 金额 else 0 end ) ,2)as 年初以来净现金流 ,
round(sum(case when 项目 = '年初以来经营活动净现金流' then 金额 else 0 end ) ,2)as 年初以来经营活动净现金流 
from temp1
group by 年份,月份 
  )

select 年份,月份, 
sum(原保险保费收入) as 原保险保费收入,
sum(期交保费收入) as 期交保费收入,  
sum(首年期交保费收入) as 首年期交保费收入,  
sum(赔付支出) as 赔付支出,  
sum([退保率（原保险保费收入）%]) as '退保率（原保险保费收入）%',  
sum([退保率（规模保费）%]) as '退保率（规模保费）%' ,  
sum(年初以来净现金流) as 年初以来净现金流,  
sum(年初以来经营活动净现金流) as 年初以来经营活动净现金流
from temp2
group by 年份,月份  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>

	<br>
	<br>
	<br>
<h> 口径说明: </h><br>
<h> 原保险保费收入:亿元，填写年内累计值 </h><br>
<h> 期交保费收入:亿元，填写年内累计值（新准则） </h><br>
<h> 首年期交保费收入:亿元，填写年内累计值（新准则） </h><br>
<h> 赔付支出:亿元，填写年初以来累计值（新准则）</h><br>
<h> 退保率（原保险保费收入）:填写年初以来累计退保率。若退保率为5%，则填写5，不填%。 </h><br>
<h> 退保率（规模保费）:填写年初以来累计退保率。若退保率为5%，则填写5，不填%。 </h><br>
<h> 退保率补充: 1.经与人行电话沟通确认，此处“退保率”统计口径与偿二代监管规则16号中的“综合退保率”保持一致，具体公式如下：综合退保率＝（退保金+保户储金及投资款的退保金+投资连结保险独立账户的退保金）÷（期初长期险责任准备金+保户储金及投资款期初余额+独立账户负债期初余额+本期签单保费）×100%</h><br>


	<br>	<br>	<br>
<h> 公司代码明细数据 </h>

	<?php  
// 到公司代码数据 
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with temp0 as (select * 	  FROM [DJSX].[dbo].[balance]
		where  [会计年度] = @zyear 
and [会计期间] between  '01' and  @zmonthS
	and ([科目]  like '6031%' 
		or [科目] like '6511%' 
		or [科目] like '6531000000%'
		or   [科目] in(  '2703010000','2704010000')
		or  [科目] in ('2711100000','2711101010','2711101020','2711102000','2721010100')
		or [科目]   in( '6531000000','2711080000','2721010700','6402040000') 
		or ( [科目]    in(  '2703010000','2704010000') or [科目] like '2711%'  or [科目] like '2721%' )
		or (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
		)) ,
temp1 as (
	SELECT @zyear as 年份,@zmonthS as 月份,公司代码,公司描述 ,'原保险保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  like '6031%'
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'期交保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  in(  '6031020000','6031010200','6031010300')
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'首年期交保费收入' as 项目 , - sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]  in(  '6031010200','6031010300')
	group by 公司代码,公司描述
	union all  
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'赔付支出' as 项目 ,  sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    like '6511%'
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'退保金（新准则）' as 项目 ,  sum([期末余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    like '6531000000%'
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'准备金期初余额（新准则）' as 项目 ,  - sum([年初余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and [科目]    in(  '2703010000','2704010000')
	group by 公司代码,公司描述
	union all 
		SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'规模保费收入' as 项目 , - sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2721010100')  or ( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'退保金（旧准则）' as 项目 ,  sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and [科目]   in( '6531000000','2711080000','2721010700','6402040000') 
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS,公司代码,公司描述 ,'新准备金和保户独立账户负债期初余额（旧准则）' as 项目 ,  - sum([年初余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] = @zmonthS
	and ( [科目]    in(  '2703010000','2704010000') or [科目] like '2711%'  or [科目] like '2721%' )
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS ,公司代码,公司描述,'年初以来净现金流' as 项目 ,    sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
	group by 公司代码,公司描述
	union all 
	SELECT @zyear ,@zmonthS ,公司代码,公司描述,'年初以来经营活动净现金流' as 项目 ,    sum([本期余额])/100000000  as 金额
	  FROM temp0
		where  [会计年度] = @zyear   
	and [会计期间] between  '01' and  @zmonthS
	and (   科目  between	'1001010000'	and	'1002019900'	or 
			科目  between	'1002050000'	and	'1002079900'	or 
			科目  between	'1015010000'	and	'1015ZZZZZZ'	or 
			科目  between	'1021010000'	and	'1021990000'	or 
			科目  between	'1031010000'	and	'1031020000'	 )
	 and ([现金流量码]  between	'AR01'	and	'AR99'	or 
[现金流量码]  between	'AP01'	and	'AP99'	)
	group by 公司代码,公司描述

),
temp2 as (
select 年份,月份,公司代码,公司描述,
round( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ),2)  as 原保险保费收入 ,
round(sum(case when 项目 = '期交保费收入' then 金额 else 0 end ),2) as 期交保费收入 ,
round(sum(case when 项目 = '首年期交保费收入' then 金额 else 0 end ),2) as 首年期交保费收入 ,
round(sum(case when 项目 = '赔付支出' then 金额 else 0 end ),2) as 赔付支出 ,

case when  ( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ) + sum(case when 项目 = '准备金期初余额（新准则）' then 金额 else 0 end ) ) = 0 then 0 else 
round(sum(case when 项目 = '退保金（新准则）' then 金额 else 0 end )/
( sum(case when 项目 = '原保险保费收入' then 金额 else 0 end ) + sum(case when 项目 = '准备金期初余额（新准则）' then 金额 else 0 end ) )*100 ,4) end    as '退保率（原保险保费收入）%' ,

case when  ( sum(case when 项目 = '规模保费收入' then 金额 else 0 end ) + sum(case when 项目 = '新准备金和保户独立账户负债期初余额（旧准则）' then 金额 else 0 end ) ) = 0 then 0 else 
round(sum(case when 项目 = '退保金（旧准则）' then 金额 else 0 end )/
( sum(case when 项目 = '规模保费收入' then 金额 else 0 end ) + sum(case when 项目 = '新准备金和保户独立账户负债期初余额（旧准则）' then 金额 else 0 end ) )*100 ,4) end   as '退保率（规模保费）%' ,


round(sum(case when 项目 = '年初以来净现金流' then 金额 else 0 end ) ,2)as 年初以来净现金流 ,
round(sum(case when 项目 = '年初以来经营活动净现金流' then 金额 else 0 end ) ,2)as 年初以来经营活动净现金流 
from temp1
group by 年份,月份,公司代码,公司描述
  )

select * from temp2  order by 公司代码  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>
 