
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with temp1 as (
select [会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  , case 
when aa.公司代码  like '20%'  then  '总公司'
when aa.公司代码  like '211%'  then  '北京'
when aa.公司代码  like '212%'  then  '天津'
when aa.公司代码  like '213%'  then  '河北'
when aa.公司代码  like '214%'  then  '山西'
when aa.公司代码  like '221%'  then  '辽宁'
when aa.公司代码  like '222%'  then  '吉林'
when aa.公司代码  like '223%'  then  '黑龙江'
when aa.公司代码  like '231%'  then  '上海'
when aa.公司代码  like '232%'  then  '江苏'
when aa.公司代码  like '233%'  then  '浙江'
when aa.公司代码  like '234%'  then  '安徽'
when aa.公司代码  like '236%'  then  '江西'
when aa.公司代码  like '237%'  then  '山东'
when aa.公司代码  like '241%'  then  '河南'
when aa.公司代码  like '242%'  then  '湖北'
when aa.公司代码  like '243%'  then  '湖南'
when aa.公司代码  like '244%'  then  '广东'
when aa.公司代码  like '247%'  then  '深圳'
when aa.公司代码  like '251%'  then  '四川'
else '其他' end as 省份, 
case 
when  [渠道] ='101001' then '个人保险代理人渠道'
when  [渠道] ='104001' then '代理机构'
when  [渠道] ='104002' then '经纪机构'
when  [渠道] like  '103%' and  [渠道]  <> '103006' then '兼业机构（银行）'
when  [渠道] =  '103006' then '兼业机构（邮政）'
end as  渠道 ,
case 
when [科目] like '6031%' THEN '渠道保费收入'
when [科目] like '6421%' THEN '佣金支出' END  AS 项目 ,
sum( [期末余额]) as 期末保费收入  FROM [DJSX].[dbo].[balance]  as aa
where ( [会计年度] = @zyear  or  [会计年度] = @zyear  -1) 
and [会计期间] = @zmonthS
---排除银行机构的客户经理佣金
and ( [科目] like '6031%' OR  [科目] like '64210403%' or ([科目] between '6421020100' and '64210402ZZ'  AND  [渠道] = '101001' )    )
and ([渠道] = '101001' or [渠道] = '104001' or [渠道] = '104002' or [渠道] like  '103%' or [渠道] ='103006' )
group by [会计年度],[会计期间],  case 
when aa.公司代码  like '20%'  then  '总公司'
when aa.公司代码  like '211%'  then  '北京'
when aa.公司代码  like '212%'  then  '天津'
when aa.公司代码  like '213%'  then  '河北'
when aa.公司代码  like '214%'  then  '山西'
when aa.公司代码  like '221%'  then  '辽宁'
when aa.公司代码  like '222%'  then  '吉林'
when aa.公司代码  like '223%'  then  '黑龙江'
when aa.公司代码  like '231%'  then  '上海'
when aa.公司代码  like '232%'  then  '江苏'
when aa.公司代码  like '233%'  then  '浙江'
when aa.公司代码  like '234%'  then  '安徽'
when aa.公司代码  like '236%'  then  '江西'
when aa.公司代码  like '237%'  then  '山东'
when aa.公司代码  like '241%'  then  '河南'
when aa.公司代码  like '242%'  then  '湖北'
when aa.公司代码  like '243%'  then  '湖南'
when aa.公司代码  like '244%'  then  '广东'
when aa.公司代码  like '247%'  then  '深圳'
when aa.公司代码  like '251%'  then  '四川'
else '其他' end  , case 
when  [渠道] ='101001' then '个人保险代理人渠道'
when  [渠道] ='104001' then '代理机构'
when  [渠道] ='104002' then '经纪机构'
when  [渠道] like  '103%' and  [渠道]  <> '103006' then '兼业机构（银行）'
when  [渠道] =  '103006' then '兼业机构（邮政）'
end ,
case 
when [科目] like '6031%' THEN '渠道保费收入'
when [科目] like '6421%' THEN '佣金支出' END 
 ) ,
temp2 as ( 
select  省份 ,渠道,
round(-sum( case when concat(会计年度,会计期间) = concat(@zyear,@zmonthS)  and 项目 = '渠道保费收入'  then 期末保费收入 else 0 end ),2) as  渠道保费收入@金额万元 ,
round(-sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS)  and 项目 = '渠道保费收入'  then 期末保费收入 else 0 end ),2) as  渠道保费收入@上年同期 ,

(case when sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS)  and 项目 = '渠道保费收入'  then 期末保费收入 else 0 end ) = 0 then  0 else 
sum( case when concat(会计年度,会计期间) = concat(@zyear,@zmonthS) and 项目 = '渠道保费收入' then 期末保费收入 else 0 end )/
sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS) and 项目 = '渠道保费收入' then 期末保费收入 else 0 end ) - 1  end ) as 渠道保费收入@同比变动,

round(sum( case when concat(会计年度,会计期间) = concat(@zyear,@zmonthS) and 项目 = '佣金支出' then 期末保费收入 else 0 end ),2) as  佣金支出@金额万元 ,
round(sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS )  and 项目 = '佣金支出' then 期末保费收入 else 0 end ),2) as  佣金支出@上年同期 ,
( case when sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS )  and 项目 = '佣金支出' then 期末保费收入 else 0 end ) = 0 then  0 else 
sum( case when concat(会计年度,会计期间) = concat(@zyear,@zmonthS)  and 项目 = '佣金支出' then 期末保费收入 else 0 end )/
sum( case when concat(会计年度,会计期间) = concat(@zyear-1,@zmonthS  )  and 项目 = '佣金支出' then 期末保费收入 else 0 end ) - 1  end )  as 佣金支出@同比变动

from temp1
group by  渠道, 省份),
----------------------------------------------------公司总保费收入（万元）
temp3 as (select [会计年度],[会计期间], case 
when aa.公司代码  like '20%'  then  '总公司'
when aa.公司代码  like '211%'  then  '北京'
when aa.公司代码  like '212%'  then  '天津'
when aa.公司代码  like '213%'  then  '河北'
when aa.公司代码  like '214%'  then  '山西'
when aa.公司代码  like '221%'  then  '辽宁'
when aa.公司代码  like '222%'  then  '吉林'
when aa.公司代码  like '223%'  then  '黑龙江'
when aa.公司代码  like '231%'  then  '上海'
when aa.公司代码  like '232%'  then  '江苏'
when aa.公司代码  like '233%'  then  '浙江'
when aa.公司代码  like '234%'  then  '安徽'
when aa.公司代码  like '236%'  then  '江西'
when aa.公司代码  like '237%'  then  '山东'
when aa.公司代码  like '241%'  then  '河南'
when aa.公司代码  like '242%'  then  '湖北'
when aa.公司代码  like '243%'  then  '湖南'
when aa.公司代码  like '244%'  then  '广东'
when aa.公司代码  like '247%'  then  '深圳'
when aa.公司代码  like '251%'  then  '四川'
else '其他' end as 省份, 
sum(- [期末余额]) as 公司总保费收入  FROM [DJSX].[dbo].[balance]  as aa
where ( [会计年度] = @zyear  ) 
and [会计期间] = @zmonthS
and  [科目] like '6031%' 
group by  [会计年度],[会计期间], case 
when aa.公司代码  like '20%'  then  '总公司'
when aa.公司代码  like '211%'  then  '北京'
when aa.公司代码  like '212%'  then  '天津'
when aa.公司代码  like '213%'  then  '河北'
when aa.公司代码  like '214%'  then  '山西'
when aa.公司代码  like '221%'  then  '辽宁'
when aa.公司代码  like '222%'  then  '吉林'
when aa.公司代码  like '223%'  then  '黑龙江'
when aa.公司代码  like '231%'  then  '上海'
when aa.公司代码  like '232%'  then  '江苏'
when aa.公司代码  like '233%'  then  '浙江'
when aa.公司代码  like '234%'  then  '安徽'
when aa.公司代码  like '236%'  then  '江西'
when aa.公司代码  like '237%'  then  '山东'
when aa.公司代码  like '241%'  then  '河南'
when aa.公司代码  like '242%'  then  '湖北'
when aa.公司代码  like '243%'  then  '湖南'
when aa.公司代码  like '244%'  then  '广东'
when aa.公司代码  like '247%'  then  '深圳'
when aa.公司代码  like '251%'  then  '四川'
else '其他' end)

select t1.*,t2.公司总保费收入  from temp2  as t1  
left join temp3 as t2
on t1.省份 = t2.省份
order by 
case 
when t1.渠道 = '个人保险代理人渠道' then 1 
when t1.渠道 = '代理机构' then 2 
when t1.渠道 = '经纪机构' then 3 
when t1.渠道 = '兼业机构（银行）' then 4
when t1.渠道 = '兼业机构（邮政）' then 5
end,
CASE 
when t1.省份 = 	'北京'	then	1
when t1.省份 = 	'天津'	then	2
when t1.省份 = 	'河北'	then	3
when t1.省份 = 	'山西'	then	4
when t1.省份 = 	'辽宁'	then	5
when t1.省份 = 	'吉林'	then	6
when t1.省份 = 	'黑龙江'	then	7
when t1.省份 = 	'上海'	then	8
when t1.省份 = 	'江苏'	then	9
when t1.省份 = 	'浙江'	then	10
when t1.省份 = 	'安徽'	then	11
when t1.省份 = 	'江西'	then	12
when t1.省份 = 	'山东'	then	13
when t1.省份 = 	'河南'	then	14
when t1.省份 = 	'湖北'	then	15
when t1.省份 = 	'湖南'	then	16
when t1.省份 = 	'广东'	then	17
when t1.省份 = 	'四川'	then	18
when t1.省份 = 	'深圳'	then	19 END ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>