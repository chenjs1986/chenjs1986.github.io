<h> 注意：</h>
<br>
<h>1.使用前，务必确认SAP已结账;</h><br>
<h>2.2023年同比数据取之经营平台数据；2024年及之后数据取自SAP;</h>
	
<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  


$znumber = $zmonthS * 1;

 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
 
    // 构建SQL查询  
    $sql = "
 ----规模口径保费
  	declare  @zyear VARCHAR(4) ;  set  @zyear =  $zyear ;

with temp0 as ( 
 SELECT   substring(账期,1,4) as 会计年度,substring(账期,6,2) as 会计期间,
case
	when 险种 like '%两全%' or  险种 like '%终身%' or  险种 like '%定期%' then '寿险' 
	when 险种 like '%年金%'   then '年金险' 
	when 险种 like '%医疗%'  or  险种 like '%疾病保险%'    or  险种 like '%住院津贴%' or  险种 like '%疾病保险%' or  险种 like '%疾病保险%' or  险种 like '%疾病保险%' then '健康险' 
	when 险种 like '%意外伤害保险%'   then '意外险' 
	else 险种 end as 险种分类,
 case   when [科目代码] between '60310101' and  '60310301' then '新单保费'
		when   [科目代码] = '60310401' then '续期保费'
		end as 保费,
 case 
		when  [渠道代码]   like '103%' then '银保'
		when  [渠道代码]   like '101%' then '个险'
		when  [渠道代码]   in(  '104001%' ,'104002') then '经代'
		else '其他' end as 渠道,
 case
	  when   [缴费年期] is null or [缴费年期] = 1000 then '趸交' 
	  when   [缴费年期]*1  >= 10 then '10年及以上'
	  else    concat([缴费年期],'年交')  end  as [缴费年期],
	  
	  sum([金额])  as 本期发生
  FROM [DJSX].[dbo].[经分平台规模保费收入]
  where 账期  like '2023%'
  group  by   substring(账期,1,4)  ,substring(账期,6,2)  ,
  case
		when 险种 like '%两全%' or  险种 like '%终身%' or  险种 like '%定期%' then '寿险' 
		when 险种 like '%年金%'   then '年金险' 
		when 险种 like '%医疗%'  or  险种 like '%疾病保险%'    or  险种 like '%住院津贴%' or  险种 like '%疾病保险%' or  险种 like '%疾病保险%' or  险种 like '%疾病保险%' then '健康险' 
		when 险种 like '%意外伤害保险%'   then '意外险' 
		else 险种 end  ,
		case when [科目代码] between '60310101' and  '60310301' then '新单保费'
		when   [科目代码] = '60310401' then '续期保费'  end , 
[渠道代码]  ,
[渠道] ,   
case
	  when   [缴费年期] is null or [缴费年期] = 1000 then '趸交' 
	  when   [缴费年期]*1  >= 10 then '10年及以上'
	  else    concat([缴费年期],'年交')  end  ,
 case 
		when  [渠道代码]   like '103%' then '银保'
		when  [渠道代码]   like '101%' then '个险'
		when  [渠道代码]   in(  '104001%' ,'104002') then '经代'
		else '其他' end
			
union all 
---------------2024
select  [会计年度]  ,[会计期间]   ,
case
	when [产品描述] like '%两全%' or  [产品描述] like '%终身%' or  [产品描述] like '%定期%' then '寿险' 
	when [产品描述] like '%年金%'   then '年金险' 
	when [产品描述] like '%医疗%'  or  [产品描述] like '%疾病保险%'    or  [产品描述] like '%住院津贴%' or  [产品描述] like '%疾病保险%' or  [产品描述] like '%疾病保险%' or  [产品描述] like '%疾病保险%' then '健康险' 
	when [产品描述] like '%意外伤害保险%'   then '意外险' 
	else [产品描述] end as 险种分类,
case  
when  科目 like '2711101%' or  科目 like '2711100000%'  or  科目 like '603101%' then '新单保费'
when  科目 like '2711102%' or  科目 like '603102%' then '续期保费' end as 保费, 
 case 
		when  [渠道]   like '103%' then '银保'
		when  [渠道]   like '101%' then '个险'
		when  [渠道]   in(  '104001%' ,'104002') then '经代'
		else '其他' end as 渠道,
case
	  when   ROUND([缴费年期] , 0, 1) *1 = 0 then '趸交' 
	  when   ROUND([缴费年期] , 0, 1) *1 = 1   then   '趸交'
	  when   ROUND([缴费年期] , 0, 1) *1 < 10   and  ROUND([缴费年期] , 0, 1) *1 > 1 then   concat(ROUND([缴费年期] , 0, 1),'年交')
      when   ROUND([缴费年期] , 0, 1) *1 >=  10 then '10年及以上'
     end   as [缴费年期]
	 , sum( - [本期余额])  as 本期发生
from   [DJSX].[dbo].[balance]
where  [会计年度] >=   '2024'
and (  科目 like'6031%' or  科目 like'271110%') 
and not ( 科目 like'6031%' and  ( [产品描述] like '%万能%' or  [产品描述] like '%投资连结%'))
group by   [会计年度]  ,[会计期间]   ,
case
	when [产品描述] like '%两全%' or  [产品描述] like '%终身%' or  [产品描述] like '%定期%' then '寿险' 
	when [产品描述] like '%年金%'   then '年金险' 
	when [产品描述] like '%医疗%'  or  [产品描述] like '%疾病保险%'    or  [产品描述] like '%住院津贴%' or  [产品描述] like '%疾病保险%' or  [产品描述] like '%疾病保险%' or  [产品描述] like '%疾病保险%' then '健康险' 
	when [产品描述] like '%意外伤害保险%'   then '意外险' 
	else [产品描述] end  ,
case  
when  科目 like '2711101%' or  科目 like '2711100000%'or  科目 like '603101%' then '新单保费'
when  科目 like '2711102%' or  科目 like '603102%' then '续期保费' end ,
 case 
		when  [渠道]   like '103%' then '银保'
		when  [渠道]   like '101%' then '个险'
		when  [渠道]   in(  '104001%' ,'104002') then '经代'
		else '其他' end  , 
case
	  when   ROUND([缴费年期] , 0, 1) *1 = 0 then '趸交' 
	  when   ROUND([缴费年期] , 0, 1) *1 = 1   then   '趸交'
	  when   ROUND([缴费年期] , 0, 1) *1 < 10   and  ROUND([缴费年期] , 0, 1) *1 > 1 then   concat(ROUND([缴费年期] , 0, 1),'年交')
      when   ROUND([缴费年期] , 0, 1) *1 >=  10 then '10年及以上'
     end   
	 )
--select * from temp0

select [渠道],险种分类,缴费年期,
sum( case when 会计年度 = @zyear     and 会计期间 <= '01' then  本期发生 else 0 end ) as  '1月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '01' then  本期发生 else 0 end ) as  '同比1A'  ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '01' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '1月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '01' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '同比1B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '01' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '01' and  保费 = '续期保费' then  本期发生 else 0 end ) as   '同比1C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '02' then  本期发生 else 0 end ) as   '1-2月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '02' then  本期发生 else 0 end ) as   '同比2A'  ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '02' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-2月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '02' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '同比2B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '02' and  保费 = '续期保费' then  本期发生 else 0 end ) as   '1-2月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '02' and  保费 = '续期保费' then  本期发生 else 0 end ) as   '同比2C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '03' then  本期发生 else 0 end ) as  '1-3月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '03' then  本期发生 else 0 end ) as  '同比3A' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '03' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-3月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '03' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比3B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '03' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-3月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '03' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比3C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '04' then  本期发生 else 0 end ) as  '1-4月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '04' then  本期发生 else 0 end ) as  '同比4A' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '04' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-4月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '04' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比4B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '04' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-4月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '04' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比4C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '05' then  本期发生 else 0 end ) as '1-5月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '05' then  本期发生 else 0 end ) as  '同比5A' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '05' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-5月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '05' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比5B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '05' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-5月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '05' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比5C',

sum( case when 会计年度 = @zyear     and 会计期间 <= '06' then  本期发生 else 0 end ) as  '1-6月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '06' then  本期发生 else 0 end ) as  '同比6A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '06' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-6月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '06' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比6B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '06' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-6月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '06' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比6C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '07' then  本期发生 else 0 end ) as  '1-7月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '07' then  本期发生 else 0 end ) as  '同比7A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '07' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-7月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '07' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比7B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '07' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-7月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '07' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比7C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '08' then  本期发生 else 0 end ) as  '1-8月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '08' then  本期发生 else 0 end ) as  '同比8A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '08' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-8月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '08' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比8B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '08' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-8月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '08' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比8C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '09' then  本期发生 else 0 end ) as  '1-9月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '09' then  本期发生 else 0 end ) as  '同比9A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '09' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-9月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '09' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比9B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '09' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-9月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '09' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比9C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '10' then  本期发生 else 0 end ) as  '1-10月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '10' then  本期发生 else 0 end ) as  '同比10A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '10' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-10月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '10' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比10B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '10' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-10月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '10' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比10C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '11' then  本期发生 else 0 end ) as  '1-11月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '11' then  本期发生 else 0 end ) as  '同比11A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '11' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-11月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '11' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比11B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '11' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-11月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '11' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比11C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '12' then  本期发生 else 0 end ) as  '1-12月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '12' then  本期发生 else 0 end ) as  '同比12A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '12' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-12月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '12' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比12B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '12' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-12月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '12' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比12C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '13' then  本期发生 else 0 end ) as  '1-13月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '13' then  本期发生 else 0 end ) as  '同比13A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '13' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-13月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '13' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比13B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '13' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-13月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '13' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比13C' ,

sum( case when 会计年度 = @zyear     and 会计期间 <= '14' then  本期发生 else 0 end ) as  '1-14月总保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '14' then  本期发生 else 0 end ) as  '同比14A' , 
sum( case when 会计年度 = @zyear     and 会计期间 <= '14' and  保费 = '新单保费' then  本期发生 else 0 end ) as   '1-14月新单保费' ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '14' and  保费 = '新单保费' then  本期发生 else 0 end ) as  '同比14B' ,
sum( case when 会计年度 = @zyear     and 会计期间 <= '14' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '1-14月续期保费'    ,
sum( case when 会计年度 = @zyear -1  and 会计期间 <= '14' and  保费 = '续期保费' then  本期发生 else 0 end ) as  '同比14C'


from temp0
group by  [渠道],险种分类,缴费年期
order by  
case
when [渠道] =  '银保' then 1
when [渠道] =  '个险' then 2
when [渠道] =  '经代' then 3
when [渠道] =  '其他' then 4
end,
case
when 险种分类 =  '寿险' then 1
when 险种分类 =  '年金险' then 2
when 险种分类 =  '健康险' then 3
when 险种分类 =  '意外险' then 4
end,
case
when 缴费年期 =  '趸交' then 1
when 缴费年期 =  '1年交' then 2
when 缴费年期 =  '2年交' then 3
when 缴费年期 =  '3年交' then 4
when 缴费年期 =  '4年交' then 5
when 缴费年期 =  '5年交' then 6
when 缴费年期 =  '6年交' then 7
when 缴费年期 =  '7年交' then 8
when 缴费年期 =  '8年交' then 9
when 缴费年期 =  '9年交' then 10
when 缴费年期 =  '10年及以上' then 11
end



  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）
$columnNames = array_keys($results[0]);

// 输出HTML表格
echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
// 使用循环输出表头
$counter = 0; // 计数器
foreach ($columnNames as $columnName) {
    if ($counter < $znumber*6 + 3 ) { // 只输出前8列
        echo "<th>" .$columnName ."</th>";
        $counter++;
    }
}
echo "</tr>";
echo "</thead>";

// 输出表格主体
echo "<tbody>";
// 假设$results包含查询结果的数据
foreach ($results as $result) {
    echo "<tr>"; // 开始每一行的<tr>标签
    // 使用循环输出表格数据
    $counter = 0; // 重置计数器
    foreach ($columnNames as $columnName) {
        if ($counter <  $znumber*6 + 3  ) { // 只输出前8列
            echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";
            $counter++;
        }
    }
    echo "</tr>"; // 结束每一行的</tr>标签
}
echo "</tbody>";
echo "</table>";

// 关闭数据库连接
$conn = null;

?>
 