<h> 注意：</h>
<br>
<h>使用前，务必确认SAP已结账;</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  


$znumber = $zmonthS * 1;

 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
 
    // 构建SQL查询  
    $sql = "
 	declare  @zyear VARCHAR(4) ;  set  @zyear = $zyear ;
	declare  @zmonth VARCHAR(4) ;  set  @zmonth = $zmonthS  ;  ---起期
  with temp as  (
select  
 case 
  when [产品描述] not like '%万能%' and  [产品描述] not like '%分红%' and  [产品描述] not like '%投资连结%'  then '传统账户'
  when [产品描述]  like '%分红%'    then '分红账户'
  when [产品描述]  like '%万能%'    then '万能账户'
  when [产品描述]  like '%投资连结%'    then '投连账户'   end as 账户,
  '原保险保费' as 项目 ,
  sum(case when [会计期间] <= '01' then -[本期余额] else 0 end)/100000000 as '1月累计' ,
  sum(case when [会计期间] <= '02' then -[本期余额] else 0 end)/100000000 as '2月累计' ,
  sum(case when [会计期间] <= '03' then -[本期余额] else 0 end)/100000000 as '3月累计' ,
  sum(case when [会计期间] <= '04' then -[本期余额] else 0 end)/100000000 as '4月累计' ,
  sum(case when [会计期间] <= '05' then -[本期余额] else 0 end)/100000000 as '5月累计' ,
  sum(case when [会计期间] <= '06' then -[本期余额] else 0 end)/100000000 as '6月累计' ,
  sum(case when [会计期间] <= '07' then -[本期余额] else 0 end)/100000000 as '7月累计' ,
  sum(case when [会计期间] <= '08' then -[本期余额] else 0 end)/100000000 as '8月累计' ,
  sum(case when [会计期间] <= '09' then -[本期余额] else 0 end)/100000000 as '9月累计' ,
  sum(case when [会计期间] <= '10' then -[本期余额] else 0 end)/100000000 as '10月累计' ,
  sum(case when [会计期间] <= '11' then -[本期余额] else 0 end)/100000000 as '11月累计' ,
  sum(case when [会计期间] <= '12' then -[本期余额] else 0 end)/100000000 as '12月累计' ,
  sum(case when [会计期间] <= '13' then -[本期余额] else 0 end)/100000000 as '13月累计' ,
  sum(case when [会计期间] <= '14' then -[本期余额] else 0 end)/100000000 as '14月累计' 
from   [DJSX].[dbo].[balance]
 where 科目 like '6031%'
 and [会计年度] = @zyear
 group by  case 
  when [产品描述] not like '%万能%' and  [产品描述] not like '%分红%' and  [产品描述] not like '%投资连结%'  then '传统账户'
  when [产品描述]  like '%分红%'    then '分红账户'
  when [产品描述]  like '%万能%'    then '万能账户'
  when [产品描述]  like '%投资连结%'    then '投连账户'   end  
union all
select  
 case 
  when [产品描述] not like '%万能%' and  [产品描述] not like '%分红%' and  [产品描述] not like '%投资连结%'  then '传统账户'
  when [产品描述]  like '%分红%'    then '分红账户'
  when [产品描述]  like '%万能%'    then '万能账户'
  when [产品描述]  like '%投资连结%'    then '投连账户'   end as 账户,
 case
 when 科目 like '603101%' then '    其中：新单保费'
 when 科目 like '603102%' then '          续期保费' end as 项目
 ,
  sum(case when [会计期间] <= '01' then -[本期余额] else 0 end)/100000000 as '1月累计' ,
  sum(case when [会计期间] <= '02' then -[本期余额] else 0 end)/100000000 as '2月累计' ,
  sum(case when [会计期间] <= '03' then -[本期余额] else 0 end)/100000000 as '3月累计' ,
  sum(case when [会计期间] <= '04' then -[本期余额] else 0 end)/100000000 as '4月累计' ,
  sum(case when [会计期间] <= '05' then -[本期余额] else 0 end)/100000000 as '5月累计' ,
  sum(case when [会计期间] <= '06' then -[本期余额] else 0 end)/100000000 as '6月累计' ,
  sum(case when [会计期间] <= '07' then -[本期余额] else 0 end)/100000000 as '7月累计' ,
  sum(case when [会计期间] <= '08' then -[本期余额] else 0 end)/100000000 as '8月累计' ,
  sum(case when [会计期间] <= '09' then -[本期余额] else 0 end)/100000000 as '9月累计' ,
  sum(case when [会计期间] <= '10' then -[本期余额] else 0 end)/100000000 as '10月累计' ,
  sum(case when [会计期间] <= '11' then -[本期余额] else 0 end)/100000000 as '11月累计' ,
  sum(case when [会计期间] <= '12' then -[本期余额] else 0 end)/100000000 as '12月累计' ,
  sum(case when [会计期间] <= '13' then -[本期余额] else 0 end)/100000000 as '13月累计' ,
  sum(case when [会计期间] <= '14' then -[本期余额] else 0 end)/100000000 as '14月累计' 
 from   [DJSX].[dbo].[balance]
 where 科目 like '6031%'
 and [会计年度] = @zyear
 group by  case 
  when [产品描述]  not like '%万能%' and   [产品描述] not like '%分红%' and  [产品描述] not like '%投资连结%'  then '传统账户'
  when [产品描述]  like '%分红%'    then '分红账户'
  when [产品描述]  like '%万能%'    then '万能账户'
  when [产品描述]  like '%投资连结%'    then '投连账户'   end ,
  case
 when 科目 like '603101%' then '    其中：新单保费'
 when 科目 like '603102%' then '          续期保费' end
 ) 
 select * from temp
 ORDER BY 
  CASE 
    WHEN 账户 = '传统账户' THEN 1 
    WHEN 账户 = '分红账户' THEN 2 
    WHEN 账户 = '万能账户' THEN 3 
    WHEN 账户 = '投连账户' THEN 4 
  END,
  case 
    WHEN 项目 = '原保险保费' THEN 1 
    WHEN 项目 = '    其中：新单保费' THEN 2 
    WHEN 项目 = '          续期保费' THEN 3 
  end 
  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）
$columnNames = array_keys($results[0]);

// 输出HTML表格
echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
// 使用循环输出表头
$counter = 0; // 计数器
foreach ($columnNames as $columnName) {
    if ($counter < $znumber + 2 ) { // 只输出前8列
        echo "<th>" .$columnName ."</th>";
        $counter++;
    }
}
echo "</tr>";
echo "</thead>";

// 输出表格主体
echo "<tbody>";
// 假设$results包含查询结果的数据
foreach ($results as $result) {
    echo "<tr>"; // 开始每一行的<tr>标签
    // 使用循环输出表格数据
    $counter = 0; // 重置计数器
    foreach ($columnNames as $columnName) {
        if ($counter < $znumber  + 2 ) { // 只输出前8列
            echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";
            $counter++;
        }
    }
    echo "</tr>"; // 结束每一行的</tr>标签
}
echo "</tbody>";
echo "</table>";

// 关闭数据库连接
$conn = null;

?>
 