<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        /* 这是一个简单的CSS样式规则，将段落文本颜色设置为红色 */
        p {
            color: red;
        }
    </style>
    <meta charset="UTF-8">
    <title>输入参数</title>
    <script>

        // JavaScript函数，用于更新隐藏输入字段的值
        function updateSubmitAction() {
            var radioButton = document.querySelector('input[name="submitAction"]:checked');
            var form = document.getElementById('myForm');
            if (radioButton) {
                form.action = radioButton.value;
            }
        }
    </script>
</head>
<body>
    <form id="myForm" action="" method="post">
        <!-- 单选框，用于选择提交到哪个处理文件 -->
        <input type="radio" id="radio1" name="submitAction" value="表1分账户基本情况表process.php" onchange="updateSubmitAction()">
        <label for="radio1">表1 分账户基本情况表</label><br>
        <input type="radio" id="radio2" name="submitAction" value="表4渠道保费情况表process.php" onchange="updateSubmitAction()"> 
        <label for="radio2">表4 渠道保费情况表</label><br>

        <br>
        <!-- 会计年度和会计期间的选择保持不变 -->
        <label for="zyear">会计年度:</label>
        <select id="zyear" name="zyear" required>
            <!-- 年份选项从2024到2026-->
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
        </select>


        <label for="zmonthS">会计期间:</label>
        <select id="zmonthS" name="zmonthS" required>
            <!-- 月份选项从01到14 -->
            <option value="01">01</option>
            <option value="02">02</option>
            <option value="03">03</option>
            <option value="04">04</option>
            <option value="05">05</option>
            <option value="06">06</option>
            <option value="07">07</option>
            <option value="08">08</option>
            <option value="09">09</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
        </select>

        <!-- 隐藏的输入字段，用于存储提交的目标 -->
        <input type="hidden" id="submitTarget" name="submitTarget">

        <!-- 运行按钮 -->
        <input type="button" value="运行" onclick="document.getElementById('myForm').submit()">
    </form>
</body>
<body>
    <br>
    <p>1.计算数据来源SAP；</p>
    <p>2.使用前，务必确认SAP已结账；</p>
</body>
</html>
			
			

<?php
//记录登录
// 数据库连接配置
$serverName = "localhost";
$connectionOptions = array(
    "dbname" => "sys",
    "username" => "root",
    "password" => "mysql",
    "charset" => "utf8mb4"
);
try {
    // 创建 PDO 实例来连接 MySQL
    $conn = new PDO("mysql:host=$serverName;dbname=" .$connectionOptions['dbname'], $connectionOptions['username'], $connectionOptions['password']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // 设置错误模式为异常

    // 获取当前页面的URL
    $pageUrl = $_SERVER['REQUEST_URI'];

    // 获取用户代理字符串
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // 获取访问者的IP地址
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // 设置时区并获取当前时间
    date_default_timezone_set('Asia/Shanghai');
    $currentTime = date('Y-m-d H:i:s');

    // 准备 SQL 插入语句
    $sql = "INSERT INTO view_records (IPAddress, UserAgent, PageViewed, viewdatetime)  
            VALUES (?, ?, ?, ?)";

   $pageUrl = urldecode($pageUrl);
    // 准备要绑定的参数
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $ipAddress);
    $stmt->bindParam(2, $userAgent);
    $stmt->bindParam(3, $pageUrl);
    $stmt->bindParam(4, $currentTime);

    // 执行 SQL 插入语句
    $stmt->execute();

    // 关闭数据库连接
    $conn = null;
} catch (PDOException $e) {
    echo "Error: " .$e->getMessage();
    die();
}
?>

 

