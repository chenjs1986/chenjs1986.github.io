 
<br>
<h>EBS利润表</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonth = $_POST['zmonth'];  
    $zbukrs = $_POST['zbukrs']; 
}  


echo "公司范围: " . $zbukrs ;
echo "<br>";
echo "报表期间: " . $zyear .  "-" . $zmonth  ;
 

    // 构建SQL查询  
    $sql = "

 declare  @zyear  varchar(50) ;  set  @zyear =  $zyear ; 
 declare  @zmonth  varchar(50) ;  set  @zmonth =  $zmonth ; 
 declare  @zbukrs  varchar(50)  ;  set  @zbukrs =  $zbukrs ; 
 declare  @zqijian  varchar(50) ;   
   if len(@zmonth) = 1   SET    @zmonth = concat('0',@zmonth);
    set  @zqijian =  concat(concat(@zyear,'-'),@zmonth ) ; 
 
 
with temp as (
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'030保险业务收入'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'030保险业务收入'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'050减：分出保费'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'060减：提取未到期责任准备金'
when 	 [SEGMENT3] between	'6111'	and	'6111Z'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601105'	and	'601105zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601108'	and	'601112zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601102'	and	'601104zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6101'	and	'6101Z'	THEN	'090公允价值变动收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6061'	and	'6061Z'	THEN	'100汇兑收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6081'	and	'6081Z'	THEN	'105其他收益'--------------------------------------------其他收益
when 	 [SEGMENT3] between	'6051'	and	'6051zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601106'	and	'601107zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601101'	and	'601101Z'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601113'	and	'601115zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'6071'	and	'6071zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601190'	and	'601190Z'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'6531'	and	'6531Z'	THEN	'125退保金'
when 	 [SEGMENT3] between	'6511'	and	'6514zZ'	THEN	'130赔付支出'
when 	 [SEGMENT3] between	'6544'	and	'6544Z'	THEN	'130赔付支出'
when 	 [SEGMENT3] between	'6202'	and	'6202zZ'	THEN	'140减：摊回赔付支出'
when 	 [SEGMENT3] between	'6502'	and	'6504zZ'	THEN	'150提取保险责任准备金'
when 	 [SEGMENT3] between	'6201'	and	'6201Z'	THEN	'160减：摊回保险责任准备金'
when 	 [SEGMENT3] between	'6205'	and	'6206zZ'	THEN	'160减：摊回保险责任准备金'
when 	 [SEGMENT3] between	'6521'	and	'6521Z'	THEN	'170保单红利支出'
when 	 [SEGMENT3] between	'6542'	and	'6543zZ'	THEN	'180分保费用'
when 	 [SEGMENT3] between	'6403'	and	'6403Z'	THEN	'190税金及附加'
when 	 [SEGMENT3] between	'6421'	and	'6421Z'	and     SEGMENT5_D  not  like '%万能型%' and     SEGMENT5_D  not  like '%投资连结%'      THEN	'200手续费及佣金支出'
when 	 [SEGMENT3] between	'6601'	and	'6601Z'	THEN	'210业务及管理费'
when 	 [SEGMENT3] between	'6203'	and	'6204zZ'	THEN	'220减：摊回分保费用'
when 	 [SEGMENT3] between	'6411'	and	'6411zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6402'	and	'6402zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6421'	and	'6421ZZ' and  (   SEGMENT5_D     like '%万能型%' or     SEGMENT5_D     like '%投资连结%' )	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6702'	and	'6702zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6701'	and	'6701Z'	THEN	'240资产减值损失'
when 	 [SEGMENT3] between	'6301'	and	'6301Z'	THEN	'260加：营业外收入'
when 	 [SEGMENT3] between	'6711'	and	'6711Z'	THEN	'270减：营业外支出'
when 	 [SEGMENT3] between	'6801'	and	'6801Z'	THEN	'290减：所得税费用'

else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'030保险业务收入'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'030保险业务收入'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'050减：分出保费'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'060减：提取未到期责任准备金'
when 	 [SEGMENT3] between	'6111'	and	'6111Z'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601105'	and	'601105zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601108'	and	'601112zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'601102'	and	'601104zZ'	THEN	'070投资收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6101'	and	'6101Z'	THEN	'090公允价值变动收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6061'	and	'6061Z'	THEN	'100汇兑收益（损失以“－”号填列）'
when 	 [SEGMENT3] between	'6081'	and	'6081Z'	THEN	'105其他收益'--------------------------------------------其他收益
when 	 [SEGMENT3] between	'6051'	and	'6051zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601106'	and	'601107zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601101'	and	'601101Z'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601113'	and	'601115zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'6071'	and	'6071zZ'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'601190'	and	'601190Z'	THEN	'110其他业务收入'
when 	 [SEGMENT3] between	'6531'	and	'6531Z'	THEN	'125退保金'
when 	 [SEGMENT3] between	'6511'	and	'6514zZ'	THEN	'130赔付支出'
when 	 [SEGMENT3] between	'6544'	and	'6544Z'	THEN	'130赔付支出'
when 	 [SEGMENT3] between	'6202'	and	'6202zZ'	THEN	'140减：摊回赔付支出'
when 	 [SEGMENT3] between	'6502'	and	'6504zZ'	THEN	'150提取保险责任准备金'
when 	 [SEGMENT3] between	'6201'	and	'6201Z'	THEN	'160减：摊回保险责任准备金'
when 	 [SEGMENT3] between	'6205'	and	'6206zZ'	THEN	'160减：摊回保险责任准备金'
when 	 [SEGMENT3] between	'6521'	and	'6521Z'	THEN	'170保单红利支出'
when 	 [SEGMENT3] between	'6542'	and	'6543zZ'	THEN	'180分保费用'
when 	 [SEGMENT3] between	'6403'	and	'6403Z'	THEN	'190税金及附加'
when 	 [SEGMENT3] between	'6421'	and	'6421Z'	and     SEGMENT5_D  not  like '%万能型%' and     SEGMENT5_D  not  like '%投资连结%'      THEN	'200手续费及佣金支出'
when 	 [SEGMENT3] between	'6601'	and	'6601Z'	THEN	'210业务及管理费'
when 	 [SEGMENT3] between	'6203'	and	'6204zZ'	THEN	'220减：摊回分保费用'
when 	 [SEGMENT3] between	'6411'	and	'6411zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6402'	and	'6402zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6421'	and	'6421ZZ' and  (   SEGMENT5_D     like '%万能型%' or     SEGMENT5_D     like '%投资连结%' )	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6702'	and	'6702zZ'	THEN	'230其他业务成本'
when 	 [SEGMENT3] between	'6701'	and	'6701Z'	THEN	'240资产减值损失'
when 	 [SEGMENT3] between	'6301'	and	'6301Z'	THEN	'260加：营业外收入'
when 	 [SEGMENT3] between	'6711'	and	'6711Z'	THEN	'270减：营业外支出'
when 	 [SEGMENT3] between	'6801'	and	'6801Z'	THEN	'290减：所得税费用'
else 'other'   end 
------------union all
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'020已赚保费'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'020已赚保费'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'020已赚保费'
else 'other'   end 
------------union all
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'040其中：分保费收入'
when 	 [SEGMENT3] between	'61110501'	and	'61110501zZ'  and  [SEGMENT4] between	'030512'	and	'030512z' 	THEN	'075其中：对联营企业和合营企业的投资收益'
when 	 [SEGMENT3] between	'61110501'	and	'61110501zZ'  and  [SEGMENT4] between	'030612'	and	'030612z'	THEN	'075其中：对联营企业和合营企业的投资收益'

else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'040其中：分保费收入'
when 	 [SEGMENT3] between	'61110501'	and	'61110501zZ'  and  [SEGMENT4] between	'030512'	and	'030512z' 	THEN	'075其中：对联营企业和合营企业的投资收益'
when 	 [SEGMENT3] between	'61110501'	and	'61110501zZ'  and  [SEGMENT4] between	'030612'	and	'030612z'	THEN	'075其中：对联营企业和合营企业的投资收益'

else 'other'   end 
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6531'	and	'6531Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6511'	and	'6514zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6544'	and	'6544Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6202'	and	'6202zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6502'	and	'6504zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6201'	and	'6201Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6205'	and	'6206zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6521'	and	'6521Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6542'	and	'6543zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6403'	and	'6403Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6421'	and	'6421Z'	and     SEGMENT5_D  not  like '%万能型%' and     SEGMENT5_D  not  like '%投资连结%'      THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6601'	and	'6601Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6203'	and	'6204zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6411'	and	'6411zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6402'	and	'6402zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6421'	and	'6421ZZ' and  (   SEGMENT5_D     like '%万能型%' or     SEGMENT5_D     like '%投资连结%' )	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6702'	and	'6702zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6701'	and	'6701Z'	THEN	'120二、营业支出'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6531'	and	'6531Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6511'	and	'6514zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6544'	and	'6544Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6202'	and	'6202zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6502'	and	'6504zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6201'	and	'6201Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6205'	and	'6206zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6521'	and	'6521Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6542'	and	'6543zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6403'	and	'6403Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6421'	and	'6421Z'	and     SEGMENT5_D  not  like '%万能型%' and     SEGMENT5_D  not  like '%投资连结%'      THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6601'	and	'6601Z'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6203'	and	'6204zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6411'	and	'6411zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6402'	and	'6402zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6421'	and	'6421ZZ' and  (   SEGMENT5_D     like '%万能型%' or     SEGMENT5_D     like '%投资连结%' )	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6702'	and	'6702zZ'	THEN	'120二、营业支出'
when 	 [SEGMENT3] between	'6701'	and	'6701Z'	THEN	'120二、营业支出'
else 'other'   end 
union all

SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6111'	and	'6111Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601105'	and	'601105zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601108'	and	'601112zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601102'	and	'601104zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6101'	and	'6101Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6061'	and	'6061Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6051'	and	'6051zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601106'	and	'601107zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601101'	and	'601101Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601113'	and	'601115zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6071'	and	'6071zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601190'	and	'601190Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6081'	and	'6081Z'	THEN	'010一、营业收入'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6031'	and	'6031Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6041'	and	'6041Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6501'	and	'6501Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6541'	and	'6541Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6111'	and	'6111Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601105'	and	'601105zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601108'	and	'601112zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601102'	and	'601104zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6101'	and	'6101Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6061'	and	'6061Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6051'	and	'6051zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601106'	and	'601107zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601101'	and	'601101Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601113'	and	'601115zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6071'	and	'6071zZ'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'601190'	and	'601190Z'	THEN	'010一、营业收入'
when 	 [SEGMENT3] between	'6081'	and	'6081Z'	THEN	'010一、营业收入'
else 'other'   end 
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6011'	and	'6207Z'	THEN	'250三、营业利润'
when 	 [SEGMENT3] between	'6402'	and	'6702Z'	THEN	'250三、营业利润'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6011'	and	'6207Z'	THEN	'250三、营业利润'
when 	 [SEGMENT3] between	'6402'	and	'6702Z'	THEN	'250三、营业利润'
else 'other'   end 
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6011'	and	'6711Z'	THEN	'280四、利润总额'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6011'	and	'6711Z'	THEN	'280四、利润总额'
else 'other'   end 
union all
SELECT  [EBS会计期间],
case  
when 	 [SEGMENT3] between	'6011'	and	'6801zZ'	THEN	'300五、净利润'
else 'other'   end  as  项目,
sum(本期余额) as 本期余额, sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian or [EBS会计期间] = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  )
  and SEGMENT3 like '6%'
  group by [EBS会计期间] ,
case  
when 	 [SEGMENT3] between	'6011'	and	'6801zZ'	THEN	'300五、净利润'
else 'other'   end 
)
,temp1 as (
select 项目,
sum(case  when EBS会计期间  = @zqijian then 本期余额 else 0 end ) as  本期金额,
sum(case  when EBS会计期间  = @zqijian then 期末余额 else 0 end ) as  本年累计金额,
sum(case  when EBS会计期间  = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  then 本期余额 else 0 end ) as  上年同期金额,
sum(case  when EBS会计期间  = concat(concat(SUBSTRING(@zqijian,1,4) -1  ,'-'),@zmonth)  then 期末余额 else 0 end ) as  上年同期累计
from temp
group by 项目
)
select   substring(项目,4,20)  AS  报表项目	,
sum(case when substring(项目,1,3)  between  '010' and '030' or  substring(项目,1,3)  between  '070' and '110'  or   substring(项目,1,3)  between  '250' and '260' or  substring(项目,1,3)  between  '280' and '300'  or  substring(项目,1,3)  in ('140','160','220')  then   - 本期金额  else  本期金额 end ) as 本期金额 ,
sum(case when substring(项目,1,3)  between  '010' and '030' or  substring(项目,1,3)  between  '070' and '110'  or   substring(项目,1,3)  between  '250' and '260' or  substring(项目,1,3)  between  '280' and '300'  or  substring(项目,1,3)  in ('140','160','220')  then   - 本年累计金额  else  本年累计金额 end ) as 本年累计金额 ,    	
sum(case when substring(项目,1,3)  between  '010' and '030' or  substring(项目,1,3)  between  '070' and '110'  or   substring(项目,1,3)  between  '250' and '260' or  substring(项目,1,3)  between  '280' and '300'  or  substring(项目,1,3)  in ('140','160','220')  then   - 上年同期金额  else  上年同期金额 end ) as 上年同期金额 ,    	
sum(case when substring(项目,1,3)  between  '010' and '030' or  substring(项目,1,3)  between  '070' and '110'  or   substring(项目,1,3)  between  '250' and '260' or  substring(项目,1,3)  between  '280' and '300'   or  substring(项目,1,3)  in ('140','160','220') then   - 上年同期累计  else  上年同期累计 end ) as 上年同期累计
from temp1
where 项目 <> 'other'
group by 项目
order by 项目
   ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    // 判断行是否填充颜色
 $rowColor = ($result[$columnNames[0]] == '一、营业收入' || $result[$columnNames[0]] == '二、营业支出' || $result[$columnNames[0]] == '三、营业利润' || $result[$columnNames[0]] == '五、净利润' || $result[$columnNames[0]] == '四、利润总额') ? ' style="background-color:yellow;"' : '';
    echo "<tr$rowColor>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>
