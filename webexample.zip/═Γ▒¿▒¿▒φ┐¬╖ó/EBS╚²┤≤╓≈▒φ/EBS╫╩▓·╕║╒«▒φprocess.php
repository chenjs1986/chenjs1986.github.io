 
<br>
<h>EBS资产负债表</h>

<br>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonth = $_POST['zmonth'];  
    $zbukrs = $_POST['zbukrs']; 
}  


echo "公司范围: " . $zbukrs ;
echo "<br>";
echo "报表期间: " . $zyear .  "-" . $zmonth  ;
 

    // 构建SQL查询  
    $sql = "

 declare  @zyear  varchar(50) ;  set  @zyear =  $zyear ; 
 declare  @zmonth  varchar(50) ;  set  @zmonth =  $zmonth ; 
 declare  @zbukrs  varchar(50)  ;  set  @zbukrs =  $zbukrs ; 
 declare  @zqijian  varchar(50) ;   
   if len(@zmonth) = 1   SET    @zmonth = concat('0',@zmonth);
    set  @zqijian =  concat(concat(@zyear,'-'),@zmonth ) ; 
 
 
with temp as (
SELECT  [EBS会计期间],
case  
when [SEGMENT3] between	'1001' and '1001Z'	then	'020货币资金'
when [SEGMENT3] between	'1012' and '1012ZZ'	then	'020货币资金'
when [SEGMENT3] between	'1021' and '1021ZZ'	then	'020货币资金'
when [SEGMENT3] between	'10310101' and '10310101Z'	then	'020货币资金'
when [SEGMENT3] between	'100205' and '100205ZZ'	then	'020货币资金'
when [SEGMENT3] between	'100201' and '100201zZ'	then	'020货币资金'
when [SEGMENT3] between	'1302' and '1302Z'	then	'030拆出资金'
when [SEGMENT3] between	'1101' and '1101zZ'	then	'040以公允价值计量且其变动计入当期损益的金融资产'
when [SEGMENT3] between	'1111' and '1111Z'	then	'060买入返售金融资产'
when [SEGMENT3] between	'1132' and '1132Z'	then	'070应收利息'
when [SEGMENT3] between	'123101' and '123101Z'	then	'070应收利息'
when [SEGMENT3] between	'1124' and '1124Z'	then	'080应收保费'
when [SEGMENT3] between	'123102' and '123102Z'	then	'080应收保费'
when [SEGMENT3] between	'1211' and '1211Z'	then	'095应收分保账款'
when [SEGMENT3] between	'123103' and '123103Z'	then	'095应收分保账款'
when [SEGMENT3] between	'1223' and '1223Z'	then	'100应收分保未到期责任准备金'
when [SEGMENT3] between	'1225' and '1225Z'	then	'110应收分保未决赔款准备金'
when [SEGMENT3] between	'1224' and '1224Z'	then	'120应收分保寿险责任准备金'
when [SEGMENT3] between	'1226' and '1226Z'	then	'130应收分保长期健康险责任准备金'
when [SEGMENT3] between	'130301' and '130301ZZ'	then	'140保户质押贷款'
when [SEGMENT3] between	'100202' and '100202Z'	then	'150定期存款'
when [SEGMENT3] between	'100203' and '100203Z'	then	'150定期存款'
when [SEGMENT3] between	'100204' and '100204Z'	then	'150定期存款'
when [SEGMENT3] between	'1503' and '1503Z'	then	'160可供出售金融资产'
when [SEGMENT3] between	'1504' and '1504Z'	then	'160可供出售金融资产'
when [SEGMENT3] between	'1501' and '1501Z'	then	'170持有至到期投资'
when [SEGMENT3] between	'1502' and '1502Z'	then	'170持有至到期投资'
when [SEGMENT3] between	'130305' and '130305ZZ'	then	'175应收款项类投资'
when [SEGMENT3] between	'1511' and '1511Z'	then	'180长期股权投资'
when [SEGMENT3] between	'1512' and '1512Z'	then	'180长期股权投资'
when [SEGMENT3] between	'1541' and '1541Z'	then	'190存出资本保证金'
when [SEGMENT3] between	'1521' and '1521Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1523' and '1523Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1522' and '1522Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1601' and '1601Z'	then	'210固定资产'
when [SEGMENT3] between	'1602' and '1602Z'	then	'210固定资产'
when [SEGMENT3] between	'1603' and '1603Z'	then	'210固定资产'
when [SEGMENT3] between	'1604' and '1604Z'	then	'215在建工程'
when [SEGMENT3] between	'1605' and '1605Z'	then	'215在建工程'
when [SEGMENT3] between	'1701' and '1701Z'	then	'220无形资产'
when [SEGMENT3] between	'1703' and '1703Z'	then	'220无形资产'
when [SEGMENT3] between	'1702' and '1702Z'	then	'220无形资产'
when [SEGMENT3] between	'1621' and '1621Z'	then	'225使用权资产'
when [SEGMENT3] between	'1623' and '1623Z'	then	'225使用权资产'
when [SEGMENT3] between	'1622' and '1622Z'	then	'225使用权资产'
when [SEGMENT3] between	'1821' and '1821Z'	then	'230独立账户资产'
when [SEGMENT3] between	'1811' and '1811Z'	then	'240递延所得税资产'
when [SEGMENT3] between	'1196' and '1196zZ'	then	'241系统往来'
when [SEGMENT3] between	'1197' and '1197Z'	then	'245内部往来'
when [SEGMENT3] between	'1131' and '1131Z'	then	'250其他资产'
when [SEGMENT3] between	'1409' and '1410ZZ'	then	'250其他资产'
when [SEGMENT3] between	'1221' and '1221Z'	then	'250其他资产'
when [SEGMENT3] between	'1121' and '1121Z'	then	'250其他资产'
when [SEGMENT3] between	'130402' and '130402zZ'	then	'250其他资产'
when [SEGMENT3] between	'130302' and '130302zZ'	then	'250其他资产'
when [SEGMENT3] between	'103102' and '103190ZZ'	then	'250其他资产'
when [SEGMENT3] between	'123104' and '123105Z'	then	'250其他资产'
when [SEGMENT3] between	'1901' and '1901Z'	then	'250其他资产'
when [SEGMENT3] between	'1801' and '1801Z'	then	'250其他资产'
when [SEGMENT3] between	'1606' and '1606Z'	then	'250其他资产'
when [SEGMENT3] between	'1123' and '1123Z'	then	'250其他资产'
when [SEGMENT3] between	'2001' and '2001Z'	then	'330短期借款'
when [SEGMENT3] between	'2003' and '2003Z'	then	'340拆入资金'
when [SEGMENT3] between	'2101' and '2101Z'	then	'350以公允价值计量且其变动计入当期损益的金融负债'
when [SEGMENT3] between	'2102' and '2102Z'	then	'360衍生金融负债'
when [SEGMENT3] between	'2111' and '2111Z'	then	'370卖出回购金融资产款'
when [SEGMENT3] between	'2204' and '2204Z'	then	'380预收保费'
when [SEGMENT3] between	'2202' and '2202Z'	then	'390应付手续费及佣金'
when [SEGMENT3] between	'2261' and '2261Z'	then	'400应付分保账款'
when [SEGMENT3] between	'2211' and '2211Z'	then	'410应付职工薪酬'
when [SEGMENT3] between	'2221' and '2221Z'	then	'420应交税费'
when [SEGMENT3] between	'2231' and '2231Z'	then	'425应付利息'
when [SEGMENT3] between	'2206' and '2206Z'	then	'430应付赔付款'
when [SEGMENT3] between	'2251' and '2251Z'	then	'440应付保单红利'
when [SEGMENT3] between	'2611' and '2611Z'	then	'450保户储金及投资款'
when [SEGMENT3] between	'2601' and '2601Z'	then	'460未到期责任准备金'
when [SEGMENT3] between	'2603' and '2603Z'	then	'470未决赔款准备金'
when [SEGMENT3] between	'2602' and '2602Z'	then	'480寿险责任准备金'
when [SEGMENT3] between	'2604' and '2604Z'	then	'490长期健康险责任准备金'
when [SEGMENT3] between	'2501' and '2501Z'	then	'500长期借款'
when [SEGMENT3] between	'2502' and '2502Z'	then	'510应付债券'
when [SEGMENT3] between	'2503' and '2503ZZ'	then	'515租赁负债'
when [SEGMENT3] between	'2621' and '2621Z'	then	'520独立账户负债'
when [SEGMENT3] between	'2901' and '2901Z'	then	'530递延所得税负债'
when [SEGMENT3] between	'2002' and '2002Z'	then	'540其他负债'
when [SEGMENT3] between	'2145' and '2145Z'	then	'540其他负债'
when [SEGMENT3] between	'2232' and '2232Z'	then	'540其他负债'
when [SEGMENT3] between	'2241' and '2241Z'	then	'540其他负债'
when [SEGMENT3] between	'2271' and '2271Z'	then	'540其他负债'
when [SEGMENT3] between	'2701' and '2701Z'	then	'540其他负债'
when [SEGMENT3] between	'2801' and '2801Z'	then	'540其他负债'
when [SEGMENT3] between	'4001' and '4001Z'	then	'570股本'
when [SEGMENT3] between	'400201' and '40020101Z'	then	'580资本公积'
when [SEGMENT3] between	'40029007' and '40029090Z'	then	'580资本公积'
when [SEGMENT3] between	'40029001' and '40029003Z'	then	'580资本公积'
when [SEGMENT3] between	'40029004' and '40029006Z'	then	'585其他综合收益'
when [SEGMENT3] between	'4101' and '4101Z'	then	'590盈余公积'
when [SEGMENT3] between	'4102' and '4102Z'	then	'600一般风险准备'
when [SEGMENT3] between	'410401' and '4104zZ'	then	'610未分配利润'
when [SEGMENT3] between	'6011' and '6801zZ'	then	'610未分配利润'
else 'other'   end  as  项目,
 sum(期末余额) as 期末余额
  FROM [DJSX].[dbo].[EBS_balance]
  where [EBS币种] = 'CNY'
  and [SEGMENT1] like concat(@zbukrs,'%')
  and ( [EBS会计期间] = @zqijian  or   [EBS会计期间] = concat(SUBSTRING(@zqijian,1,4) -1  ,'-A12')  )
  group by [EBS会计期间] ,
  case 
when [SEGMENT3] between	'1001' and '1001Z'	then	'020货币资金'
when [SEGMENT3] between	'1012' and '1012ZZ'	then	'020货币资金'
when [SEGMENT3] between	'1021' and '1021ZZ'	then	'020货币资金'
when [SEGMENT3] between	'10310101' and '10310101Z'	then	'020货币资金'
when [SEGMENT3] between	'100205' and '100205ZZ'	then	'020货币资金'
when [SEGMENT3] between	'100201' and '100201zZ'	then	'020货币资金'
when [SEGMENT3] between	'1302' and '1302Z'	then	'030拆出资金'
when [SEGMENT3] between	'1101' and '1101zZ'	then	'040以公允价值计量且其变动计入当期损益的金融资产'
when [SEGMENT3] between	'1111' and '1111Z'	then	'060买入返售金融资产'
when [SEGMENT3] between	'1132' and '1132Z'	then	'070应收利息'
when [SEGMENT3] between	'123101' and '123101Z'	then	'070应收利息'
when [SEGMENT3] between	'1124' and '1124Z'	then	'080应收保费'
when [SEGMENT3] between	'123102' and '123102Z'	then	'080应收保费'
when [SEGMENT3] between	'1211' and '1211Z'	then	'095应收分保账款'
when [SEGMENT3] between	'123103' and '123103Z'	then	'095应收分保账款'
when [SEGMENT3] between	'1223' and '1223Z'	then	'100应收分保未到期责任准备金'
when [SEGMENT3] between	'1225' and '1225Z'	then	'110应收分保未决赔款准备金'
when [SEGMENT3] between	'1224' and '1224Z'	then	'120应收分保寿险责任准备金'
when [SEGMENT3] between	'1226' and '1226Z'	then	'130应收分保长期健康险责任准备金'
when [SEGMENT3] between	'130301' and '130301ZZ'	then	'140保户质押贷款'
when [SEGMENT3] between	'100202' and '100202Z'	then	'150定期存款'
when [SEGMENT3] between	'100203' and '100203Z'	then	'150定期存款'
when [SEGMENT3] between	'100204' and '100204Z'	then	'150定期存款'
when [SEGMENT3] between	'1503' and '1503Z'	then	'160可供出售金融资产'
when [SEGMENT3] between	'1504' and '1504Z'	then	'160可供出售金融资产'
when [SEGMENT3] between	'1501' and '1501Z'	then	'170持有至到期投资'
when [SEGMENT3] between	'1502' and '1502Z'	then	'170持有至到期投资'
when [SEGMENT3] between	'130305' and '130305ZZ'	then	'175应收款项类投资'
when [SEGMENT3] between	'1511' and '1511Z'	then	'180长期股权投资'
when [SEGMENT3] between	'1512' and '1512Z'	then	'180长期股权投资'
when [SEGMENT3] between	'1541' and '1541Z'	then	'190存出资本保证金'
when [SEGMENT3] between	'1521' and '1521Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1523' and '1523Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1522' and '1522Z'	then	'200投资性房地产'
when [SEGMENT3] between	'1601' and '1601Z'	then	'210固定资产'
when [SEGMENT3] between	'1602' and '1602Z'	then	'210固定资产'
when [SEGMENT3] between	'1603' and '1603Z'	then	'210固定资产'
when [SEGMENT3] between	'1604' and '1604Z'	then	'215在建工程'
when [SEGMENT3] between	'1605' and '1605Z'	then	'215在建工程'
when [SEGMENT3] between	'1701' and '1701Z'	then	'220无形资产'
when [SEGMENT3] between	'1703' and '1703Z'	then	'220无形资产'
when [SEGMENT3] between	'1702' and '1702Z'	then	'220无形资产'
when [SEGMENT3] between	'1621' and '1621Z'	then	'225使用权资产'
when [SEGMENT3] between	'1623' and '1623Z'	then	'225使用权资产'
when [SEGMENT3] between	'1622' and '1622Z'	then	'225使用权资产'
when [SEGMENT3] between	'1821' and '1821Z'	then	'230独立账户资产'
when [SEGMENT3] between	'1811' and '1811Z'	then	'240递延所得税资产'
when [SEGMENT3] between	'1196' and '1196zZ'	then	'241系统往来'
when [SEGMENT3] between	'1197' and '1197Z'	then	'245内部往来'
when [SEGMENT3] between	'1131' and '1131Z'	then	'250其他资产'
when [SEGMENT3] between	'1409' and '1410ZZ'	then	'250其他资产'
when [SEGMENT3] between	'1221' and '1221Z'	then	'250其他资产'
when [SEGMENT3] between	'1121' and '1121Z'	then	'250其他资产'
when [SEGMENT3] between	'130402' and '130402zZ'	then	'250其他资产'
when [SEGMENT3] between	'130302' and '130302zZ'	then	'250其他资产'
when [SEGMENT3] between	'103102' and '103190ZZ'	then	'250其他资产'
when [SEGMENT3] between	'123104' and '123105Z'	then	'250其他资产'
when [SEGMENT3] between	'1901' and '1901Z'	then	'250其他资产'
when [SEGMENT3] between	'1801' and '1801Z'	then	'250其他资产'
when [SEGMENT3] between	'1606' and '1606Z'	then	'250其他资产'
when [SEGMENT3] between	'1123' and '1123Z'	then	'250其他资产'
when [SEGMENT3] between	'2001' and '2001Z'	then	'330短期借款'
when [SEGMENT3] between	'2003' and '2003Z'	then	'340拆入资金'
when [SEGMENT3] between	'2101' and '2101Z'	then	'350以公允价值计量且其变动计入当期损益的金融负债'
when [SEGMENT3] between	'2102' and '2102Z'	then	'360衍生金融负债'
when [SEGMENT3] between	'2111' and '2111Z'	then	'370卖出回购金融资产款'
when [SEGMENT3] between	'2204' and '2204Z'	then	'380预收保费'
when [SEGMENT3] between	'2202' and '2202Z'	then	'390应付手续费及佣金'
when [SEGMENT3] between	'2261' and '2261Z'	then	'400应付分保账款'
when [SEGMENT3] between	'2211' and '2211Z'	then	'410应付职工薪酬'
when [SEGMENT3] between	'2221' and '2221Z'	then	'420应交税费'
when [SEGMENT3] between	'2231' and '2231Z'	then	'425应付利息'
when [SEGMENT3] between	'2206' and '2206Z'	then	'430应付赔付款'
when [SEGMENT3] between	'2251' and '2251Z'	then	'440应付保单红利'
when [SEGMENT3] between	'2611' and '2611Z'	then	'450保户储金及投资款'
when [SEGMENT3] between	'2601' and '2601Z'	then	'460未到期责任准备金'
when [SEGMENT3] between	'2603' and '2603Z'	then	'470未决赔款准备金'
when [SEGMENT3] between	'2602' and '2602Z'	then	'480寿险责任准备金'
when [SEGMENT3] between	'2604' and '2604Z'	then	'490长期健康险责任准备金'
when [SEGMENT3] between	'2501' and '2501Z'	then	'500长期借款'
when [SEGMENT3] between	'2502' and '2502Z'	then	'510应付债券'
when [SEGMENT3] between	'2503' and '2503ZZ'	then	'515租赁负债'
when [SEGMENT3] between	'2621' and '2621Z'	then	'520独立账户负债'
when [SEGMENT3] between	'2901' and '2901Z'	then	'530递延所得税负债'
when [SEGMENT3] between	'2002' and '2002Z'	then	'540其他负债'
when [SEGMENT3] between	'2145' and '2145Z'	then	'540其他负债'
when [SEGMENT3] between	'2232' and '2232Z'	then	'540其他负债'
when [SEGMENT3] between	'2241' and '2241Z'	then	'540其他负债'
when [SEGMENT3] between	'2271' and '2271Z'	then	'540其他负债'
when [SEGMENT3] between	'2701' and '2701Z'	then	'540其他负债'
when [SEGMENT3] between	'2801' and '2801Z'	then	'540其他负债'
when [SEGMENT3] between	'4001' and '4001Z'	then	'570股本'
when [SEGMENT3] between	'400201' and '40020101Z'	then	'580资本公积'
when [SEGMENT3] between	'40029007' and '40029090Z'	then	'580资本公积'
when [SEGMENT3] between	'40029001' and '40029003Z'	then	'580资本公积'
when [SEGMENT3] between	'40029004' and '40029006Z'	then	'585其他综合收益'
when [SEGMENT3] between	'4101' and '4101Z'	then	'590盈余公积'
when [SEGMENT3] between	'4102' and '4102Z'	then	'600一般风险准备'
when [SEGMENT3] between	'410401' and '4104zZ'	then	'610未分配利润'
when [SEGMENT3] between	'6011' and '6801zZ'	then	'610未分配利润'
else 'other'
 end
 )
 ,temp1 as  (
 select  EBS会计期间 , '242系统往来（借项）' as  项目 , case when 期末余额 > 0 then 期末余额 else 0  end  as  期末余额  from temp  where 项目 = '241系统往来'
 union all  select   EBS会计期间 , '242系统往来（借项）' , case when 期末余额 > 0 then 期末余额 else 0  end  as  期末余额  from temp  where 项目 = '245内部往来'
 union all  select   EBS会计期间 , '535系统往来(贷项）' , case when 期末余额 < 0 then 期末余额 else 0  end  as  期末余额  from temp  where 项目 = '241系统往来'
 union all  select   EBS会计期间 , '538内部往来(贷项)' , case when 期末余额 < 0 then 期末余额 else 0  end  as  期末余额  from temp  where 项目 = '245内部往来'
 union all  select   EBS会计期间,项目,期末余额 from temp where 项目 not in ('241系统往来','245内部往来') )
 ,temp2 as (
 select EBS会计期间 , 项目 ,  case when  substring(项目,1,3)   >= '300'   then -期末余额 else 期末余额 end as  期末余额 from temp1
 )
  ,temp3 as (
 select EBS会计期间 , '300资产合计' as  项目 , sum( case when  substring(项目,1,3)  < '300'   then  期末余额 else 0  end )  as  期末余额 from temp2    group by EBS会计期间
 union all
 select EBS会计期间 , '550负债合计' as  项目 , sum( case when  substring(项目,1,3) between  '310' and '540'   then  期末余额 else 0  end )  as  期末余额 from temp2    group by EBS会计期间
 union all
 select EBS会计期间 , '620股东权益合计' as  项目 , sum( case when  substring(项目,1,3) between  '570' and '610'   then  期末余额 else 0  end )  as  期末余额 from temp2    group by EBS会计期间
 union all
 select EBS会计期间 , '630负债和股东权益总计' as  项目 , sum( case when  substring(项目,1,3) between  '310' and '610'   then  期末余额 else 0  end )  as  期末余额 from temp2    group by EBS会计期间
 union all
 select EBS会计期间 ,  项目 ,  期末余额   from temp2   where 项目 <> 'other'
)
select substring(项目,4,20) as 报表项目 ,sum( case when   [EBS会计期间]   = @zqijian     then 期末余额 else  0 end ) as 期末余额   , sum(case when   [EBS会计期间]   =  concat(SUBSTRING(@zqijian,1,4) -1  ,'-A12')   then 期末余额 else  0 end ) as 年初余额    from temp3
group by 项目
order by 项目
  ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    // 判断行是否填充颜色
 $rowColor = ($result[$columnNames[0]] == '资产合计' || $result[$columnNames[0]] == '负债合计' || $result[$columnNames[0]] == '股东权益合计' || $result[$columnNames[0]] == '负债和股东权益总计') ? ' style="background-color:yellow;"' : '';
    echo "<tr$rowColor>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>
