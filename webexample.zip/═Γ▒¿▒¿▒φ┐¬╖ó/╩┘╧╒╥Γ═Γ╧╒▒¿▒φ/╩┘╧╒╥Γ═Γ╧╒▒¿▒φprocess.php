
<h> 一年期及以下意外险业务分险种监管报表 </h>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
    $a66010089 = $_POST['a66010089'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
    // 构建SQL查询  
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear ;----------------------输入期间
declare  @zmonthS int ;  set  @zmonthS = $zmonthS ;  -----------------
declare  @a66010089 FLOAT  ;  set  @a66010089 = $a66010089  ;  -----------------统信指标“业务及管理费－意外伤害险”的全国值
declare  @a66010089xiao FLOAT;


------计算小于等于一年意外险承担的业管费
set @a66010089xiao = @a66010089 * (select -sum([期末余额])  FROM [DJSX].[dbo].[balance]  
where   [会计年度] = @zyear   
and [会计期间]  =   @zmonthS  
and 科目 like '6031%'    
and 产品描述  like '%意外伤害保险%'
and [保险责任] = 'YWX'   and  [长短期] in ('SHORT' ,'ONE'))/
(
select -sum([期末余额])  FROM [DJSX].[dbo].[balance]  
where   [会计年度] = @zyear   
and [会计期间]  =  @zmonthS 
and 科目 like '6031%'    
and 产品描述  like '%意外伤害保险%'
and [保险责任] = 'YWX' ) ;


-----一年期及以下意外险业务分险种监管报表
with temp1 as (
select [会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间]  , 产品描述,
case 
 when  [科目] like '6031%' then  '一、已赚保费 '
 when  [科目] like '6032%' then  '一、已赚保费 '
 when  [科目] like '6541%' then  '一、已赚保费 '
 when  [科目] like '6501%' then  '一、已赚保费 '
 when  [科目] like '6203%' then  '一、已赚保费 '
 when  [科目] like '6511%' then  '二、保险业务支出'
 when  [科目] like '6543%' then  '二、保险业务支出'
 when  [科目] like '6205%' then  '二、保险业务支出'
 when  [科目] like '6503%' then  '二、保险业务支出'
 when  [科目] like '6204%' then  '二、保险业务支出'
 when  [科目] like '6421%' then  '二、保险业务支出'
 when  [科目] like '6601%' then  '二、保险业务支出'
 when  [科目] like '6542%' then  '二、保险业务支出'
 when  [科目] like '6206%' then  '二、保险业务支出'
 when  [科目] like '6405%' then  '二、保险业务支出'
   else concat('其他未匹配项目科目',[科目])  end as 大项 ,
case 
 when  [科目] like '6031%' then  '1.原保险保费收入'
 when  [科目] like '6032%' then  '2.分保费收入'
 when  [科目] like '6541%' then  '     减：分出保费'
 when  [科目] like '6501%' then  '        提取未到期责任准备金'
 when  [科目] like '6203%' then  '        提取未到期责任准备金' -------增加摊回
 when  [科目] like '6511%' then  '1.赔付支出－赔款支出'
 when  [科目] like '6543%' then  '2.赔付支出－分保赔款支出'
 when  [科目] like '6205%' then  '     减：摊回赔付支出'
 when  [科目] like '6503%' then  '3.提取未决赔款准备金'
 when  [科目] like '6204%' then  '     减：摊回未决赔款准备金'
 when  [科目] like '6421%' then  '4.手续费及佣金支出'
 when  [科目] like '6601%' then  '5.业务及管理费'
 when  [科目] like '6542%' then  '6.分保费用'
 when  [科目] like '6206%' then  '     减：摊回分保费用'
 when  [科目] like '6405%' then  '7.税金及附加'
   else concat('其他未匹配项目科目',[科目]) end as 项目 ,
    sum(
case 
 when  [科目] like '6031%' then -[期末余额]  ---'1.原保险保费收入'
 when  [科目] like '6032%' then -[期末余额]  --- '2.分保费收入'
 when  [科目] like '6541%' then  [期末余额]  ---'     减：分出保费'
 when  [科目] like '6501%' then  [期末余额]  --- '        提取未到期责任准备金'
 when  [科目] like '6511%' then  [期末余额]  ---  '1.赔付支出－赔款支出'
 when  [科目] like '6543%' then  [期末余额]  --- '2.赔付支出－分保赔款支出'
 when  [科目] like '6205%' then -[期末余额]  --- '     减：摊回赔付支出'
 when  [科目] like '6503%' then  [期末余额]  ---  '3.提取未决赔款准备金'
 when  [科目] like '6204%' then -[期末余额]  --- '     减：摊回未决赔款准备金'
 when  [科目] like '6421%' then  [期末余额]  --- '4.手续费及佣金支出'
 when  [科目] like '6601%' then  [期末余额]  --- '5.业务及管理费'
 when  [科目] like '6542%' then  [期末余额]  --- '6.分保费用'
 when  [科目] like '6206%' then -[期末余额]  --- '     减：摊回分保费用'
 when  [科目] like '6405%' then  [期末余额]  --- '7.税金及附加'	
 else [期末余额]
 end )  as 期末余额  FROM [DJSX].[dbo].[balance]  as aa
where ( [会计年度] = @zyear   ) 
and [会计期间] = @zmonthS
and 科目 like '6%'  and 科目 not like '6601%'  ----业管费由@a66010089分摊得到
and 产品描述  like '%意外伤害保险%'
and [保险责任] = 'YWX'   and  [长短期] in ('SHORT' ,'ONE')
group by [会计年度],[会计期间],[科目], 产品描述 ) ,


temp11 as (
select [会计年度],[会计期间],大项,项目,
sum(  case when  ( 产品描述 like '%意外伤害保险%' or   产品描述 like '%附加%意外伤害保险%' )   and 产品描述 not like '%交通工具意外伤害%'  and  产品描述 not like '%团体%' then 期末余额 else  0 end   )   as 普通意外险@个人意外险,
sum(  case when  产品描述 like '%航空意外险%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )  as 航空意外险@个人意外险,
sum(  case when  产品描述 like '%借款人意外险%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )  as 借款人意外险@个人意外险,
sum(  case when  产品描述 like '%旅行意外险%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )  as 旅行意外险@个人意外险,
sum(  case when  产品描述 like '%交通工具意外伤害%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )  as 交通意外险@个人意外险,
sum(  case when  产品描述 like '%学生意外险%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )  as 学生意外险@个人意外险,
sum(  case when  产品描述 like '%老年人意外险%' and  产品描述 not like '%团体%' then 期末余额 else  0 end   )   as 老年人意外险@个人意外险 ,
sum(  case when     产品描述   like '%团体%' then 期末余额 else  0 end   )   as 小计@团体意外险 ,
sum(  case when     产品描述   like '%团体%' and   产品描述   like '%建筑工程%' then 期末余额 else  0 end   )   as 建筑工程团体意外险@团体意外险 ,
sum(  case when     产品描述   like '%团体%' and   产品描述 not  like '%建筑工程%' then 期末余额 else  0 end   )   as 其他@团体意外险  

from temp1
group by [会计年度],[会计期间],大项,项目
union all
select [会计年度],[会计期间],'二、保险业务支出' as 大项,'5.业务及管理费' as 项目,
sum(  case when  ( 产品描述 like '%意外伤害保险%' or   产品描述 like '%附加%意外伤害保险%') and 产品描述 not like '%交通工具意外伤害%'     and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )* @a66010089xiao/sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )   as 普通意外险@个人意外险,
sum(  case when  产品描述 like '%航空意外险%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )      as 航空意外险@个人意外险,
sum(  case when  产品描述 like '%借款人意外险%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )      as 借款人意外险@个人意外险,
sum(  case when  产品描述 like '%旅行意外险%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )     as 旅行意外险@个人意外险,
	------计算--先乘后除，就金额一致了
 sum(  case when  产品描述 like '%交通工具意外伤害%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )  * @a66010089xiao / sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )     as 交通意外险@个人意外险,
sum(  case when  产品描述 like '%学生意外险%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )      as 学生意外险@个人意外险,
sum(  case when  产品描述 like '%老年人意外险%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )       as 老年人意外险@个人意外险 ,

sum(  case when  产品描述 like '%团体%' and   项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )      as 小计@团体意外险 ,
sum(  case when  产品描述 like '%团体%' and   产品描述   like '%建筑工程%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )       as 建筑工程团体意外险@团体意外险 ,
sum(  case when  产品描述 like '%团体%' and   产品描述   not  like '%建筑工程%' and  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )*@a66010089xiao/ sum(  case when  项目 = '1.原保险保费收入'   then 期末余额 else  0 end   )     as 其他@团体意外险 

from temp1
group by [会计年度],[会计期间])

select * from temp11 
order by 
case 
  when 项目 = '1.原保险保费收入' then 1
  when 项目 = '2.分保费收入'     then 2
  when 项目 = '     减：分出保费'  then 3
  when 项目 = '        提取未到期责任准备金'  then 4
  when 项目 = '1.赔付支出－赔款支出'  then 5
  when 项目 = '2.赔付支出－分保赔款支出' then 6
  when 项目 = '     减：摊回赔付支出'  then 7
  when 项目 = '3.提取未决赔款准备金' then 8
  when 项目 = '     减：摊回未决赔款准备金' then 9
  when 项目 = '4.手续费及佣金支出'  then 10
  when 项目 = '5.业务及管理费'   then 11
  when 项目 = '6.分保费用'  then 12
  when 项目 = '     减：摊回分保费用'  then 13
  when 项目 = '7.税金及附加出'  then 14
  else 99 end  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 输出HTML表格    
echo "<table border='1'>";    
echo "<thead>";    
echo "<tr>";    
echo "<th>会计年度</th>";    
echo "<th>会计期间</th>";  
echo "<th>大项</th>";    
echo "<th>项目</th>";    
echo "<th>普通意外险@个人意外险</th>";    
echo "<th>航空意外险@个人意外险</th>";    
echo "<th>借款人意外险@个人意外险</th>";    
echo "<th>旅行意外险@个人意外险</th>";    
echo "<th>交通意外险@个人意外险</th>";    
echo "<th>学生意外险@个人意外险</th>";    
echo "<th>老年人意外险@个人意外险</th>";    
echo "<th>小计@团体意外险</th>";    
echo "<th>建筑工程团体意外险@团体意外险</th>";    
echo "<th>其他@团体意外险</th>";    
echo "</tr>";    
echo "</thead>";    
    
// 输出表格主体    
echo "<tbody>";    
foreach ($results as $result) {    
    echo "<tr>"; // 开始每一行的<tr>标签    
    echo "<td>" . $result['会计年度'] . "</td>";    
    echo "<td>" . $result['会计期间'] . "</td>";    
    echo "<td>" . $result['大项'] . "</td>";    
    echo "<td>" . $result['项目'] . "</td>";    
    echo "<td>" . $result['普通意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['航空意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['借款人意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['旅行意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['交通意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['学生意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['老年人意外险@个人意外险'] . "</td>";    
    echo "<td>" . $result['小计@团体意外险'] . "</td>";    
    echo "<td>" . $result['建筑工程团体意外险@团体意外险'] . "</td>";    
    echo "<td>" . $result['其他@团体意外险'] . "</td>";    
    echo "</tr>"; // 结束每一行的</tr>标签    
}    
echo "</tbody>";
  
// 结束表格  
echo "</table>";  

?>


		<br>		
		<br>	
		<br>	
		<br>
<h> 一年期以上意外险业务分险种监管报表  </h>	
<?php  
  // 构建SQL查询  
    $sql = "
declare  @zyear int ;  set  @zyear = $zyear ;----------------------输入期间
declare  @zmonthS int ;  set  @zmonthS = $zmonthS ;  -----------------
declare  @a66010089 FLOAT  ;  set  @a66010089 = $a66010089  ;  -----------------统信指标“业务及管理费－意外伤害险”的全国值
declare  @a66010089xiao FLOAT;

-----  一年期以上意外险业务分险种监管报表
 with temp2 as (
select [会计年度]*1 as [会计年度]  ,[会计期间]*1 as [会计期间] , 
case 
when   [科目] like '6031%'  AND 渠道 LIKE '102%' then '1.公司直销' 
when   [科目] like '6031%'  AND 渠道 LIKE '104001%' then '2.保险专业代理' 
when   [科目] like '6031%'  AND 渠道 LIKE '104002%' then '3.保险经纪' 
when   [科目] like '6031%'  AND 渠道 LIKE '103%' then '4.商业银行类保险兼业代理' 
when   [科目] like '6031%'  AND 渠道 IN( '101001','104003','104004','104AAA','1AAAAA') then '7.其他渠道' 
else ''end as  渠道  , 
case 
 when  [科目] like '6031%' then  '一、原保险保费收入'
 when  [科目] like '6032%' then  '2.分保费收入'
 when  [科目] like '6541%' then  '     减：分出保费'
 when  [科目] like '6501%' then  '四、未到期责任准备金'
 when  [科目] like '6203%' then  '摊回未到期'
 when  [科目] like '6511%' then  '二、赔付支出'
 when  [科目] like '6543%' then  '2.赔付支出－分保赔款支出'
 when  [科目] like '6205%' then  '     减：摊回赔付支出'
 when  [科目] like '6503%' then  '3.提取未决赔款准备金'
 when  [科目] like '6204%' then  '     减：摊回未决赔款准备金'
 when  [科目] like '6421%' then  '五、手续费及佣金支出'
 when  [科目] like '6601%' then  '5.业务及管理费'
 when  [科目] like '6542%' then  '6.分保费用'
 when  [科目] like '6206%' then  '     减：摊回分保费用'
 when  [科目] like '6405%' then  '7.税金及附加'
   else  concat('未分配科目-',[科目描述]) end as 项目 , 
----将收入值转为正数
   sum(case when [科目] like '6031%'   then - [本期余额] else  [本期余额] end  )  as 本期余额, 
   sum(case when [科目] like '6031%'   then - [期末余额] else  [期末余额] end  )  as 期末余额 
   
   FROM [DJSX].[dbo].[balance]  as aa
where ( [会计年度] = @zyear  or [会计年度] = @zyear  -1   ) 
and [会计期间] = @zmonthS --------------------------------------------------------只取当期
and 科目 like '6%'  and 科目 not like '6601%'  ----业管费由@a66010089分摊得到
and 产品描述  like '%意外伤害保险%'
and  [保险责任] = 'YWX'   and  [长短期] in ('LONG') 
group by [会计年度],[会计期间],[科目],科目描述, case 
when   [科目] like '6031%'  AND 渠道 LIKE '102%' then '1.公司直销' 
when   [科目] like '6031%'  AND 渠道 LIKE '104001%' then '2.保险专业代理' 
when   [科目] like '6031%'  AND 渠道 LIKE '104002%' then '3.保险经纪' 
when   [科目] like '6031%'  AND 渠道 LIKE '103%' then '4.商业银行类保险兼业代理' 
when   [科目] like '6031%'  AND 渠道 IN( '101001','104003','104004','104AAA','1AAAAA') then '7.其他渠道' 
else ''end  ,case 
 when  [科目] like '6031%' then  '一、原保险保费收入'
 when  [科目] like '6032%' then  '2.分保费收入'
 when  [科目] like '6541%' then  '     减：分出保费'
 when  [科目] like '6501%' then  '四、未到期责任准备金'
 when  [科目] like '6203%' then  '摊回未到期'
 when  [科目] like '6511%' then  '二、赔付支出'
 when  [科目] like '6543%' then  '2.赔付支出－分保赔款支出'
 when  [科目] like '6205%' then  '     减：摊回赔付支出'
 when  [科目] like '6503%' then  '3.提取未决赔款准备金'
 when  [科目] like '6204%' then  '     减：摊回未决赔款准备金'
 when  [科目] like '6421%' then  '五、手续费及佣金支出'
 when  [科目] like '6601%' then  '5.业务及管理费'
 when  [科目] like '6542%' then  '6.分保费用'
 when  [科目] like '6206%' then  '     减：摊回分保费用'
 when  [科目] like '6405%' then  '7.税金及附加'
   else  concat('未分配科目-',[科目描述])   end
  )
--------------------------------------------------------只有当期
 , temp21 as (
   SELECT  项目,渠道,
   sum(case when 会计年度 = @zyear  then 本期余额 else 0 end ) as  '本月发生' ,
   sum(case when 会计年度 = @zyear -1  then 本期余额 else 0 end ) as  '上年同期' ,
   sum(case when 会计年度 = @zyear  then 期末余额 else 0 end ) as  '本年累计发生' ,
   sum(case when 会计年度 = @zyear -1  then 期末余额 else 0 end ) as  '上年同期累计' 
   from temp2
   group by 项目,渠道   )

   select 项目,渠道,
   本月发生,
   上年同期,
   round(case when  上年同期 = 0 then 0 else  本月发生/上年同期 -1 end ,4)  as 本月发生同比增长  ,
   本年累计发生,
   上年同期累计,
   round(case when  上年同期累计 = 0 then 0 else  本年累计发生/上年同期累计 -1 end,4) as 本年累计同比增长  
   from temp21
   order by 
   case 
when 项目 = '一、原保险保费收入' then 1  
when 项目 = '1.公司直销' then 2  
when 项目 = '2.保险专业代理' then 3  
when 项目 = '3.保险经纪' then 4  
when 项目 = '4.商业银行类保险兼业代理' then 5  
when 项目 = '5.互联网企业代理渠道' then 6  
when 项目 = '6.其他兼业代理' then 7  
when 项目 = '7.其他渠道' then 8  
when 项目 = '二、赔付支出' then 9  
when 项目 = '三、退保金' then 10  
when 项目 = '四、未到期责任准备金' then 11  
when 项目 = '五、手续费及佣金支出' then 12  
when 项目 = '六、新增保险金额' then 13  
when 项目 = '七、期末有效保险金额' then 14
else 99
end  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results2 = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results2[] = $row;  
}  


// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results2[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results2 as $result2) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result2[$columnName]) ? htmlspecialchars($result2[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 结束表格  


// 关闭数据库连接  
$conn = null;  
?>