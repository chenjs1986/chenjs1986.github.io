 

<br>
<H2> 赢时胜科目和全称为空的，属于未导入名称，待补充</h1>
<br>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  


$znumber = $zmonthS * 1;

 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
 
    // 构建SQL查询  
    $sql = "
 	declare  @zyear VARCHAR(4) ;  set  @zyear = $zyear ;
	declare  @zmonth VARCHAR(4) ;  set  @zmonth = $zmonthS  ;  ---起期
  
  
 

WITH tempke AS(
SELECT   aa.[科目编码] AS [赢时胜全科目] ,
      aa.[科目名称]   ,
      aa.[科目全称],
      aa.[科目层级],
	  (select top(1)  bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '1级') as  赢时胜一级科目,
	  (select top(1)   bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '1级') as  赢时胜一级科目名称	  ,
	  (select top(1)   bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '2级') as  赢时胜二级科目,
	  (select  top(1)  bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '2级') as  赢时胜二级科目名称	  ,
	  (select top(1)   bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '3级') as  赢时胜三级科目,
	  (select top(1)   bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '3级') as  赢时胜三级科目名称	  ,
	  (select top(1)   bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '4级') as  赢时胜四级科目,
	  (select top(1)   bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '4级') as  赢时胜四级科目名称	  ,
	  (select top(1)   bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '5级') as  赢时胜五级科目,
	  (select top(1)   bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '5级') as  赢时胜五级科目名称	  ,
	  (select top(1)   bb.[科目编码] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '6级') as  赢时胜六级科目,
	  (select top(1)   bb.[科目全称] from [DJSX].[dbo].[GZ_INTER] as  bb where  substring(aa.[科目编码],1,len(bb.[科目编码]) ) =  bb.[科目编码]  and bb.科目层级 = '6级') as  赢时胜六级科目名称 ,
	  CASE         WHEN CHARINDEX('.', [科目编码]) > 0 THEN     RIGHT([科目编码], CHARINDEX('.', REVERSE([科目编码])) - 1)         ELSE             NULL    END AS   赢时胜金融产品类型 , 
	  [科目名称] as 赢时胜金融产品名称 
  FROM [DJSX].[dbo].[GZ_INTER] as aa
)
,temp02 as ( SELECT  distinct [科目]  ,[科目描述]   FROM [DJSX].[dbo].[balance])
,temp03 as ( SELECT  distinct [金融产品类型]  ,[金融产品类型描述]   FROM [DJSX].[dbo].[balance])
,temp2 as (
SELECT   aa.[EBS账簿编码], aa.[辅助核算项目名15] as [赢时胜全科目] ,   aa.[资产账套] as 赢时胜资产账套  , gg.[账套名称] as  赢时胜资产账套名称 , bb.[公司代码]  as SAP公司代码  ,
    EE.赢时胜一级科目  ,EE.赢时胜一级科目名称, EE.赢时胜二级科目 ,EE.赢时胜二级科目名称, EE.赢时胜三级科目 ,EE.赢时胜三级科目名称, EE.赢时胜四级科目 ,EE.赢时胜四级科目名称, EE.赢时胜五级科目 ,EE.赢时胜五级科目名称, EE.赢时胜六级科目 ,EE.赢时胜六级科目名称,
    bb.[总账科目]  as SAP科目, 
	dd.[科目描述]  as SAP科目描述  ,
	ee.赢时胜金融产品类型,
	EE.赢时胜金融产品名称,
    bb.[金融产品类型] as  SAP金融产品类型,
    cc.金融产品类型描述 as  SAP金融产品名称 ,
	SUM( CASE WHEN BB.[借/贷标识] = 'S' THEN 金额 ELSE 0 END) AS 借方发生,
	SUM( CASE WHEN BB.[借/贷标识] = 'H' THEN 金额 ELSE 0 END) AS 贷方发生,
	SUM( CASE WHEN BB.[借/贷标识] = 'H' THEN 金额 ELSE - 金额 END) AS 本期发生
FROM 
    [DJSX].[dbo].[GZ估值_赢时胜] as aa
LEFT JOIN [DJSX].[dbo].[GZ估值SAP] as bb
	ON  aa.[EBS账簿编码] = bb.[EBS账簿编码]
    AND aa.[EBS会计凭证号] = bb.[EBS会计凭证号]
    AND aa.[EBS会计凭证行项目] = bb.[EBS会计凭证行项目]
    AND aa.[资产账套] = bb.[资产账套]
    AND aa.[会计年度] = bb.[会计年度]
    AND aa.[会计期间] = bb.[过账期间]
left join temp03  as cc
    on  bb.[金融产品类型] = cc.[金融产品类型] 
left join temp02 as dd 
	on bb.[总账科目] = dd.[科目]
left join tempke AS EE
    ON    trim(aa.[辅助核算项目名15]) = trim(ee.[赢时胜全科目])
left join [DJSX].[dbo].[GZ_company] AS GG
    ON  AA.[资产账套] =    GG.[账套代码]

where aa.[会计年度]*1  = @zyear *1
and aa.[会计期间] *1 = @zmonth *1

group by   aa.[资产账套],aa.[EBS账簿编码], gg.[账套名称], bb.[公司代码] , aa.[辅助核算项目名15],ee.赢时胜金融产品类型 ,  EE.赢时胜一级科目  ,EE.赢时胜一级科目名称, EE.赢时胜二级科目 ,EE.赢时胜二级科目名称, EE.赢时胜三级科目 ,EE.赢时胜三级科目名称, EE.赢时胜四级科目 ,EE.赢时胜四级科目名称, EE.赢时胜五级科目 ,EE.赢时胜五级科目名称, EE.赢时胜六级科目 ,EE.赢时胜六级科目名称,	EE.赢时胜金融产品名称,
    bb.[总账科目], 
	dd.[科目描述],
    bb.[金融产品类型],
    cc.金融产品类型描述
) 
  
  --select * from  temp2

-------展示资产账套及名称与SAP的对照
--select distinct   EBS账簿编码,资产账套,账套名称,公司代码  from  temp2 
--order by  EBS账簿编码  ,  资产账套;

-----展示资产账套及名称与SAP的对照
select distinct     EBS账簿编码 , 赢时胜全科目 , 	赢时胜资产账套 , 	赢时胜资产账套名称	 , SAP公司代码	 , 赢时胜一级科目 , 	赢时胜一级科目名称 , 赢时胜二级科目 , 	赢时胜二级科目名称 , 赢时胜三级科目 , 	赢时胜三级科目名称 , 赢时胜四级科目 , 	赢时胜四级科目名称
 	  from  temp2 
 
  ";  
  
  // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  }  
// 调用functions.php并输出
require $_SERVER['DOCUMENT_ROOT'] .'/functions.php'; // 引入 www 目录下的 functions.php 文件
outputResults($results);

?>
 