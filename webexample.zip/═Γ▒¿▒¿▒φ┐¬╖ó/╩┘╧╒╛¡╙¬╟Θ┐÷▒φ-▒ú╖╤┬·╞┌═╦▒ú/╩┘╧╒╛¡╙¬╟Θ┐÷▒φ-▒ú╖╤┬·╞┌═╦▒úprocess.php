<h> </h>
<br>
 <h> 保费收入情况（规模保费） </h>
<p> 注意：
2023年及之前，“保户储金及保户投资款-合同收入”、“独立账户负债-账户价值-本金”按新单统计;
<br>
2024年及之后，“保户储金及保户投资款-合同收入”已拆分首续期，分别统计；“独立账户负债-账户价值-本金”按新单统计;
</p>

<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
    $zg1 = $_POST['zg1'];  
    $zg2 = $_POST['zg2'];  
    $zg3 = $_POST['zg3'];  
    $zx1 = $_POST['zx1'];  
    $zx2 = $_POST['zx2'];  
    $zx3 = $_POST['zx3'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
 echo "\n";  
 
 echo "保费收入情况（规模保费）";
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2711060000','2721010100','2721010400')  or  [科目]  like '6031%'   )
and 会计年度 <= 2023
and ((科目 like '6031%' and 产品 not in  ('121080','121018','121022','121023','122044','121001') ) or  (科目 like '2711060000' and 产品 not in  ('121001','122035','121022','121080' ) )
or  (科目 like '27%' and 科目 <>'2711060000' ) )
union all
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or  [科目]  like '6031%'   )
and 会计年度 >= 2024
and ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or 
( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月规模保费 from temp0
where 会计年度 = @zyear 
and  会计期间 = @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)

select 分公司代码 ,分公司 ,
sum( case when  科目 in('6031010100','2711101010','2711100000','2721010100') then 当月规模保费 else 0 end )/10000  as 新单趸交@业务结构,
sum( case when  科目 in('6031010100','2711101010','2711100000','2721010100') then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比 ,
sum( case when  科目 in('6031010200','6031010300') then 当月规模保费 else 0 end )/10000  as 新单期交@业务结构,
sum( case when  科目 in('6031010200','6031010300') then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比1,
sum( case when  科目 in('6031020000','2711102000') then 当月规模保费 else 0 end )/10000  as 续期@业务结构,
sum( case when  科目 in('6031020000','2711102000') then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比2 ,
sum( case when  渠道 like '103%' then 当月规模保费 else 0 end )/10000  as 银邮代理@渠道结构 ,
sum( case when  渠道 like '103%' then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比3,
sum( case when  渠道 in('104001','104002')  then 当月规模保费 else 0 end )/10000  as 保险专业中介@渠道结构 ,
sum( case when  渠道 in('104001','104002')  then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比4,
sum( case when  渠道 like '101%' then 当月规模保费 else 0 end )/10000  as 个人代理@渠道结构 ,
sum( case when  渠道 like '101%' then 当月规模保费 else 0 end )  /sum( 当月规模保费 )  as 占比5,
sum( case when  渠道 not like '101%'  and  渠道 not like '103%' and 渠道 not in ('104001','104002') then 当月规模保费 else 0 end )/10000  as 其他@渠道结构 ,
sum( case when  渠道 not like '101%'  and  渠道 not like '103%' and 渠道 not in ('104001','104002') then 当月规模保费 else 0 end ) / sum( 当月规模保费 )  as 占比6,
sum( case when ( [产品描述] not like '%投资连结%' and    [产品描述] not like '%分红%' and  [产品描述] not like '%万能%')   then 当月规模保费 else 0 end )/10000  as 普通寿险@产品结构 ,
sum( case when ( [产品描述] not like '%投资连结%' and     [产品描述] not like '%分红%' and  [产品描述] not like '%万能%' )  then 当月规模保费 else 0 end )/sum( 当月规模保费 )  as 占比7,
sum( case when  [产品描述] like '%分红%'    then 当月规模保费 else 0 end )/10000  as 分红险@产品结构 ,
sum( case when  [产品描述] like '%分红%'    then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比8,
sum( case when  [产品描述] like '%万能%'    then 当月规模保费 else 0 end )/10000  as 万能险@产品结构 ,
sum( case when  [产品描述] like '%万能%'    then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比9,
sum( case when  [产品描述] like '%投资连结%'    then 当月规模保费 else 0 end )/10000  as 投连险@产品结构 ,
sum( case when  [产品描述] like '%投资连结%'    then 当月规模保费 else 0 end )  /sum( 当月规模保费 )  as 占比a,
sum( 当月规模保费 )/10000  as 总规模保费
from temp1
group by 分公司代码,分公司
order by 分公司代码 ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>


<h> </h>
<br>
 <h> 保费收入渠道明细（规模保费） </h>
 <?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
    $zg1 = $_POST['zg1'];  
    $zg2 = $_POST['zg2'];  
    $zg3 = $_POST['zg3'];  
    $zx1 = $_POST['zx1'];  
    $zx2 = $_POST['zx2'];  
    $zx3 = $_POST['zx3'];  
}  

switch ($zg1) {
    case 103001:        $zg1n = "工行";         break;
    case 103002:        $zg1n = "建行";        break;
    case 103003:        $zg1n = "农行";        break;
    case 103004:        $zg1n = "交行";        break;
    case 103005:        $zg1n = "中行";        break;
    case 103006:        $zg1n = "邮储银行";        break;
    case 103007:        $zg1n = "地方商业银行";        break;
    case 103008:        $zg1n = "招行";        break;
    case 103009:        $zg1n = "兴业银行";        break;
    case 103010:        $zg1n = "华夏银行";        break;
    case 103011:        $zg1n = "农商行";        break;
    case 103012:        $zg1n = "民生银行";        break;
    case 103013:        $zg1n = "中信银行";        break;
    case 103014:        $zg1n = "浦发行";        break;
    case 103015:        $zg1n = "广发行";        break;
    case 103016:        $zg1n = "上海银行";        break;
    case 103017:        $zg1n = "光大银行";        break;
    case 103018:        $zg1n = "平安银行";        break;
    default:        $zg1n = "其他值";
}
 
switch ($zg2) {
    case 103001:        $zg2n = "工行";         break;
    case 103002:        $zg2n = "建行";        break;
    case 103003:        $zg2n = "农行";        break;
    case 103004:        $zg2n = "交行";        break;
    case 103005:        $zg2n = "中行";        break;
    case 103006:        $zg2n = "邮储银行";        break;
    case 103007:        $zg2n = "地方商业银行";        break;
    case 103008:        $zg2n = "招行";        break;
    case 103009:        $zg2n = "兴业银行";        break;
    case 103010:        $zg2n = "华夏银行";        break;
    case 103011:        $zg2n = "农商行";        break;
    case 103012:        $zg2n = "民生银行";        break;
    case 103013:        $zg2n = "中信银行";        break;
    case 103014:        $zg2n = "浦发行";        break;
    case 103015:        $zg2n = "广发行";        break;
    case 103016:        $zg2n = "上海银行";        break;
    case 103017:        $zg2n = "光大银行";        break;
    case 103018:        $zg2n = "平安银行";        break;
    default:        $zg2n = "其他值";
}

switch ($zg3) {
    case 103001:        $zg3n = "工行";         break;
    case 103002:        $zg3n = "建行";        break;
    case 103003:        $zg3n = "农行";        break;
    case 103004:        $zg3n = "交行";        break;
    case 103005:        $zg3n = "中行";        break;
    case 103006:        $zg3n = "邮储银行";        break;
    case 103007:        $zg3n = "地方商业银行";        break;
    case 103008:        $zg3n = "招行";        break;
    case 103009:        $zg3n = "兴业银行";        break;
    case 103010:        $zg3n = "华夏银行";        break;
    case 103011:        $zg3n = "农商行";        break;
    case 103012:        $zg3n = "民生银行";        break;
    case 103013:        $zg3n = "中信银行";        break;
    case 103014:        $zg3n = "浦发行";        break;
    case 103015:        $zg3n = "广发行";        break;
    case 103016:        $zg3n = "上海银行";        break;
    case 103017:        $zg3n = "光大银行";        break;
    case 103018:        $zg3n = "平安银行";        break;
    default:        $zg3n = "其他值";
}

switch ($zx1) {
    case 103001:        $zx1n= "工行";         break;
    case 103002:        $zx1n= "建行";        break;
    case 103003:        $zx1n= "农行";        break;
    case 103004:        $zx1n= "交行";        break;
    case 103005:        $zx1n= "中行";        break;
    case 103006:        $zx1n= "邮储银行";        break;
    case 103007:        $zx1n= "地方商业银行";        break;
    case 103008:        $zx1n= "招行";        break;
    case 103009:        $zx1n= "兴业银行";        break;
    case 103010:        $zx1n= "华夏银行";        break;
    case 103011:        $zx1n= "农商行";        break;
    case 103012:        $zx1n= "民生银行";        break;
    case 103013:        $zx1n= "中信银行";        break;
    case 103014:        $zx1n= "浦发行";        break;
    case 103015:        $zx1n= "广发行";        break;
    case 103016:        $zx1n= "上海银行";        break;
    case 103017:        $zx1n= "光大银行";        break;
    case 103018:        $zx1n= "平安银行";        break;
    default:        $zx1n= "其他值";
}

switch ($zx2) {
    case 103001:        $zx2n= "工行";         break;
    case 103002:        $zx2n= "建行";        break;
    case 103003:        $zx2n= "农行";        break;
    case 103004:        $zx2n= "交行";        break;
    case 103005:        $zx2n= "中行";        break;
    case 103006:        $zx2n= "邮储银行";        break;
    case 103007:        $zx2n= "地方商业银行";        break;
    case 103008:        $zx2n= "招行";        break;
    case 103009:        $zx2n= "兴业银行";        break;
    case 103010:        $zx2n= "华夏银行";        break;
    case 103011:        $zx2n= "农商行";        break;
    case 103012:        $zx2n= "民生银行";        break;
    case 103013:        $zx2n= "中信银行";        break;
    case 103014:        $zx2n= "浦发行";        break;
    case 103015:        $zx2n= "广发行";        break;
    case 103016:        $zx2n= "上海银行";        break;
    case 103017:        $zx2n= "光大银行";        break;
    case 103018:        $zx2n= "平安银行";        break;
    default:        $zx2n= "其他值";
}

switch ($zx3) {
    case 103001:        $zx3n= "工行";         break;
    case 103002:        $zx3n= "建行";        break;
    case 103003:        $zx3n= "农行";        break;
    case 103004:        $zx3n= "交行";        break;
    case 103005:        $zx3n= "中行";        break;
    case 103006:        $zx3n= "邮储银行";        break;
    case 103007:        $zx3n= "地方商业银行";        break;
    case 103008:        $zx3n= "招行";        break;
    case 103009:        $zx3n= "兴业银行";        break;
    case 103010:        $zx3n= "华夏银行";        break;
    case 103011:        $zx3n= "农商行";        break;
    case 103012:        $zx3n= "民生银行";        break;
    case 103013:        $zx3n= "中信银行";        break;
    case 103014:        $zx3n= "浦发行";        break;
    case 103015:        $zx3n= "广发行";        break;
    case 103016:        $zx3n= "上海银行";        break;
    case 103017:        $zx3n= "光大银行";        break;
    case 103018:        $zx3n= "平安银行";        break;
    default:        $zx3n= "其他值";
}


    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
   declare  @zg1 int ;  set  @zg1 = $zg1;  -----------------
   declare  @zg2 int ;  set  @zg2 = $zg2;  -----------------
   declare  @zg3 int ;  set  @zg3 = $zg3;  -----------------
   declare  @zx1 int ;  set  @zx1 = $zx1;  -----------------
   declare  @zx2 int ;  set  @zx2 = $zx2;  -----------------
   declare  @zx3 int ;  set  @zx3 = $zx3;  -----------------

with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2711060000','2721010100','2721010400')  or  [科目]  like '6031%'   )
and 会计年度 <= 2023
and ((科目 like '6031%' and 产品 not in  ('121080','121018','121022','121023','122044','121001') ) or  (科目 like '2711060000' and 产品 not in  ('121001','122035','121022','121080' ) )
or  (科目 like '27%' and 科目 <>'2711060000' ) )
union all
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or  [科目]  like '6031%'   )
and 会计年度 >= 2024
and ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or 
( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月规模保费 from temp0
where 会计年度 = @zyear 
and  会计期间 = @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)
 

select 分公司代码 ,分公司 ,
sum( case when  渠道 = @zg1  then 当月规模保费 else 0 end )/10000        as   "  .   $zg1n  .  "@银邮代理,
sum( case when  渠道 = @zg1  then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比1 ,

sum( case when  渠道 = @zg2   then 当月规模保费 else 0 end )/10000  as   "  .   $zg2n  .  "@银邮代理,
sum( case when  渠道 = @zg2   then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比2 ,

sum( case when  渠道 = @zg3  then 当月规模保费 else 0 end )/10000  as  "  .   $zg3n  .  "@银邮代理,
sum( case when  渠道 =@zg3   then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比3 ,

sum( case when  渠道 like '103%' and  渠道 not in (@zg1 ,@zg2,@zg3)  then 当月规模保费 else 0 end )/10000  as 其他@银邮代理,
sum( case when  渠道 like '103%' and  渠道 not in (@zg1 ,@zg2,@zg3)  then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比4 ,

sum( case when  渠道 like '103%'   then 当月规模保费 else 0 end )/10000  as 保费小计@银邮代理,
sum( case when  渠道 like '103%'   then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比5  ,

'' as 合作机构数量@保险专业中介,

sum( case when  渠道 in ( '104001','104002')   then 当月规模保费 else 0 end )/10000  as 保费@保险专业中介,
sum( case when  渠道 in ( '104001','104002')   then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比6  ,

'' as 人员数量@个人代理,

sum( case when  渠道 like  '101%'   then 当月规模保费 else 0 end )/10000  as 保费@个人代理,
sum( case when  渠道 like  '101%'   then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比7,

sum( case when  渠道 not  like  '101%'  and  渠道 not  like  '103%' and  渠道 not  in ( '104001','104002')      then 当月规模保费 else 0 end )/10000  as 保费@其他 ,
sum( case when  渠道 not  like  '101%'  and  渠道 not  like  '103%' and  渠道 not  in ( '104001','104002')      then 当月规模保费 else 0 end ) /sum( 当月规模保费 )  as 占比8 ,

sum( 当月规模保费 )/10000   as 保费合计

from temp1
group by 分公司代码,分公司
order by 分公司代码  ";  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
echo  "填写说明：	1.其他（可补充添加）：各分公司在当地有业务量较大的其他合作机构需列明情况。
	2.各合作机构保费占比=该机构保费收入/保费合计。";

// 关闭数据库连接  
$conn = null;  
?>

<br><br>



<h> </h>
<br>
 <h> 业务计划完成情况（规模保费） </h>
 <?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711100000','2711101010','2711101020','2711102000','2711060000','2721010100','2721010400')  or  [科目]  like '6031%'   )
and 会计年度 <= 2023
and ((科目 like '6031%' and 产品 not in  ('121080','121018','121022','121023','122044','121001') ) or  (科目 like '2711060000' and 产品 not in  ('121001','122035','121022','121080' ) )
or  (科目 like '27%' and 科目 <>'2711060000' ) )
union all
select *   FROM [DJSX].[dbo].[balance]  
where    ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or  [科目]  like '6031%'   )
and 会计年度 >= 2024
and ( [科目] in ('2711101010','2711101020','2711102000','2721010100')  or 
( [科目]  like '6031%' and  [产品描述] not like '%万能%' and  [产品描述] not like '%投资连结%' ) )
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月规模保费 from temp0
where 会计年度 = @zyear 
and  会计期间 between  01 and @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)
   
select 分公司代码 ,分公司 ,

'' as 计划任务@新单趸交,
sum( case when  科目描述 like '%新单%趸交%' or 科目描述 like '%独立%本金%'   then 当月规模保费 else 0 end )/10000  as 累计完成@新单趸交,
'' as 完成进度@新单趸交,

'' as 计划任务@新单期缴,
sum( case when  科目描述 like '%新单%期%'  or  科目描述 like '%首年续期%'  then 当月规模保费 else 0 end )/10000  as 累计完成@新单期缴,
'' as 完成进度@新单期缴,

'' as 计划任务@续期,
sum( case when  科目描述 like '%续期%'  and  科目描述 not  like '%首年%' then 当月规模保费 else 0 end )/10000  as 累计完成@续期,
'' as 完成进度@续期

from temp1
group by 分公司代码,分公司
order by 分公司代码  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>


<?php  
//// // // ///// // // ///// // // ///// // // ///// // // ///// // // ///// // // ///// // // //  新准则数据报表
?>
<br><br>
<h>以下为新准则</h>
<br><br>

<h></h>
<br>
 <h> 保费收入情况 (原保险保费) </h>

<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
 echo  $zyear  .  "年"  .  $zmonthS  .  "月" ;
 echo "\n";  
 
 echo "保费收入情况（规模保费）";
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where      [科目]  like '6031%'  
and     会计年度 = @zyear 
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月新准则保费 from temp0
where 会计年度 = @zyear 
and  会计期间 = @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)

select 分公司代码 ,分公司 ,
sum( case when  科目 in('6031010100') then 当月新准则保费 else 0 end )/10000  as 新单趸交@业务结构,
sum( case when  科目 in('6031010100') then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比 ,
sum( case when  科目 in('6031010200','6031010300') then 当月新准则保费 else 0 end )/10000  as 新单期交@业务结构,
sum( case when  科目 in('6031010200','6031010300') then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比1,
sum( case when  科目 in('6031020000') then 当月新准则保费 else 0 end )/10000  as 续期@业务结构,
sum( case when  科目 in('6031020000') then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比2 ,
sum( case when  渠道 like '103%' then 当月新准则保费 else 0 end )/10000  as 银邮代理@渠道结构 ,
sum( case when  渠道 like '103%' then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比3,
sum( case when  渠道 in('104001','104002')  then 当月新准则保费 else 0 end )/10000  as 保险专业中介@渠道结构 ,
sum( case when  渠道 in('104001','104002')  then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比4,
sum( case when  渠道 like '101%' then 当月新准则保费 else 0 end )/10000  as 个人代理@渠道结构 ,
sum( case when  渠道 like '101%' then 当月新准则保费 else 0 end )  /sum( 当月新准则保费 )  as 占比5,
sum( case when  渠道 not like '101%'  and  渠道 not like '103%' and 渠道 not in ('104001','104002') then 当月新准则保费 else 0 end )/10000  as 其他@渠道结构 ,
sum( case when  渠道 not like '101%'  and  渠道 not like '103%' and 渠道 not in ('104001','104002') then 当月新准则保费 else 0 end ) / sum( 当月新准则保费 )  as 占比6,
sum( case when ( [产品描述] not like '%投资连结%' and    [产品描述] not like '%分红%' and  [产品描述] not like '%万能%')   then 当月新准则保费 else 0 end )/10000  as 普通寿险@产品结构 ,
sum( case when ( [产品描述] not like '%投资连结%' and     [产品描述] not like '%分红%' and  [产品描述] not like '%万能%' )  then 当月新准则保费 else 0 end )/sum( 当月新准则保费 )  as 占比7,
sum( case when  [产品描述] like '%分红%'    then 当月新准则保费 else 0 end )/10000  as 分红险@产品结构 ,
sum( case when  [产品描述] like '%分红%'    then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比8,
sum( case when  [产品描述] like '%万能%'    then 当月新准则保费 else 0 end )/10000  as 万能险@产品结构 ,
sum( case when  [产品描述] like '%万能%'    then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比9,
sum( case when  [产品描述] like '%投资连结%'    then 当月新准则保费 else 0 end )/10000  as 投连险@产品结构 ,
sum( case when  [产品描述] like '%投资连结%'    then 当月新准则保费 else 0 end )  /sum( 当月新准则保费 )  as 占比a,
sum( 当月新准则保费 )/10000  as 总规模保费
from temp1
group by 分公司代码,分公司
order by 分公司代码 ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>




<h> </h>
<br>
 <h> 保费收入渠道明细 (原保险保费) </h>
 <?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
    $zg1 = $_POST['zg1'];  
    $zg2 = $_POST['zg2'];  
    $zg3 = $_POST['zg3'];  
    $zx1 = $_POST['zx1'];  
    $zx2 = $_POST['zx2'];  
    $zx3 = $_POST['zx3'];  
}  

 

switch ($zx1) {
    case 103001:        $zx1n= "工行";         break;
    case 103002:        $zx1n= "建行";        break;
    case 103003:        $zx1n= "农行";        break;
    case 103004:        $zx1n= "交行";        break;
    case 103005:        $zx1n= "中行";        break;
    case 103006:        $zx1n= "邮储银行";        break;
    case 103007:        $zx1n= "地方商业银行";        break;
    case 103008:        $zx1n= "招行";        break;
    case 103009:        $zx1n= "兴业银行";        break;
    case 103010:        $zx1n= "华夏银行";        break;
    case 103011:        $zx1n= "农商行";        break;
    case 103012:        $zx1n= "民生银行";        break;
    case 103013:        $zx1n= "中信银行";        break;
    case 103014:        $zx1n= "浦发行";        break;
    case 103015:        $zx1n= "广发行";        break;
    case 103016:        $zx1n= "上海银行";        break;
    case 103017:        $zx1n= "光大银行";        break;
    case 103018:        $zx1n= "平安银行";        break;
    default:        $zx1n= "其他值";
}

switch ($zx2) {
    case 103001:        $zx2n= "工行";         break;
    case 103002:        $zx2n= "建行";        break;
    case 103003:        $zx2n= "农行";        break;
    case 103004:        $zx2n= "交行";        break;
    case 103005:        $zx2n= "中行";        break;
    case 103006:        $zx2n= "邮储银行";        break;
    case 103007:        $zx2n= "地方商业银行";        break;
    case 103008:        $zx2n= "招行";        break;
    case 103009:        $zx2n= "兴业银行";        break;
    case 103010:        $zx2n= "华夏银行";        break;
    case 103011:        $zx2n= "农商行";        break;
    case 103012:        $zx2n= "民生银行";        break;
    case 103013:        $zx2n= "中信银行";        break;
    case 103014:        $zx2n= "浦发行";        break;
    case 103015:        $zx2n= "广发行";        break;
    case 103016:        $zx2n= "上海银行";        break;
    case 103017:        $zx2n= "光大银行";        break;
    case 103018:        $zx2n= "平安银行";        break;
    default:        $zx2n= "其他值";
}

switch ($zx3) {
    case 103001:        $zx3n= "工行";         break;
    case 103002:        $zx3n= "建行";        break;
    case 103003:        $zx3n= "农行";        break;
    case 103004:        $zx3n= "交行";        break;
    case 103005:        $zx3n= "中行";        break;
    case 103006:        $zx3n= "邮储银行";        break;
    case 103007:        $zx3n= "地方商业银行";        break;
    case 103008:        $zx3n= "招行";        break;
    case 103009:        $zx3n= "兴业银行";        break;
    case 103010:        $zx3n= "华夏银行";        break;
    case 103011:        $zx3n= "农商行";        break;
    case 103012:        $zx3n= "民生银行";        break;
    case 103013:        $zx3n= "中信银行";        break;
    case 103014:        $zx3n= "浦发行";        break;
    case 103015:        $zx3n= "广发行";        break;
    case 103016:        $zx3n= "上海银行";        break;
    case 103017:        $zx3n= "光大银行";        break;
    case 103018:        $zx3n= "平安银行";        break;
    default:        $zx3n= "其他值";
}


    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
   declare  @zg1 int ;  set  @zg1 = $zg1;  -----------------
   declare  @zg2 int ;  set  @zg2 = $zg2;  -----------------
   declare  @zg3 int ;  set  @zg3 = $zg3;  -----------------
   declare  @zx1 int ;  set  @zx1 = $zx1;  -----------------
   declare  @zx2 int ;  set  @zx2 = $zx2;  -----------------
   declare  @zx3 int ;  set  @zx3 = $zx3;  -----------------

with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where      [科目]  like '6031%'  
and     会计年度 = @zyear 
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月新准则保费 from temp0
where 会计年度 = @zyear 
and  会计期间 = @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)
 

select 分公司代码 ,分公司 ,
sum( case when  渠道 = @zx1   then 当月新准则保费 else 0 end )/10000  as    "  .   $zx1n  .  "@银邮代理,
sum( case when  渠道 = @zx1    then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比1 ,

sum( case when  渠道 = @zx2   then 当月新准则保费 else 0 end )/10000  as    "  .   $zx2n  .  "@银邮代理,
sum( case when  渠道 =@zx2    then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比2 ,

sum( case when  渠道 = @zx3  then 当月新准则保费 else 0 end )/10000  as    "  .   $zx3n  .  "@银邮代理,
sum( case when  渠道 = @zx3  then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比3 ,

sum( case when  渠道 like '103%' and  渠道 not in (@zg1 ,@zg2,@zg3)  then 当月新准则保费 else 0 end )/10000  as 其他@银邮代理,
sum( case when  渠道 like '103%' and  渠道 not in (@zg1 ,@zg2,@zg3)  then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比4 ,

sum( case when  渠道 like '103%'   then 当月新准则保费 else 0 end )/10000  as 保费小计@银邮代理,
sum( case when  渠道 like '103%'   then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比5  ,

'' as 合作机构数量@保险专业中介,

sum( case when  渠道 in ( '104001','104002')   then 当月新准则保费 else 0 end )/10000  as 保费@保险专业中介,
sum( case when  渠道 in ( '104001','104002')   then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比6  ,

'' as 人员数量@个人代理,

sum( case when  渠道 like  '101%'   then 当月新准则保费 else 0 end )/10000  as 保费@个人代理,
sum( case when  渠道 like  '101%'   then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比7,

sum( case when  渠道 not  like  '101%'  and  渠道 not  like  '103%' and  渠道 not  in ( '104001','104002')      then 当月新准则保费 else 0 end )/10000  as 保费@其他 ,
sum( case when  渠道 not  like  '101%'  and  渠道 not  like  '103%' and  渠道 not  in ( '104001','104002')      then 当月新准则保费 else 0 end ) /sum( 当月新准则保费 )  as 占比8 ,

sum( 当月新准则保费 )/10000   as 保费合计

from temp1
group by 分公司代码,分公司
order by 分公司代码  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
echo  "填写说明：	1.其他（可补充添加）：各分公司在当地有业务量较大的其他合作机构需列明情况。
	2.各合作机构保费占比=该机构保费收入/保费合计。";

// 关闭数据库连接  
$conn = null;  
?>

<br><br>


<h> </h>
<br>
 <h> 业务计划完成情况  (原保险保费) </h>
 <?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where      [科目]  like '6031%'  
and     会计年度 = @zyear 
),
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,
  分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],-sum([本期余额]) as 当月新准则保费 from temp0
where 会计年度 = @zyear 
and  会计期间 between  01 and @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)
   
select 分公司代码 ,分公司 ,

'' as 计划任务@新单趸交,
sum( case when  科目描述 like '%新单%趸交%'    then 当月新准则保费 else 0 end )/10000  as 累计完成@新单趸交,
'' as 完成进度@新单趸交,

'' as 计划任务@新单期缴,
sum( case when  科目描述 like '%新单%期%'  or  科目描述 like '%首年续期%'  then 当月新准则保费 else 0 end )/10000  as 累计完成@新单期缴,
'' as 完成进度@新单期缴,

'' as 计划任务@续期,
sum( case when  科目描述 like '%续期%'  and  科目描述 not  like '%首年%' then 当月新准则保费 else 0 end )/10000  as 累计完成@续期,
'' as 完成进度@续期

from temp1
group by 分公司代码,分公司
order by 分公司代码  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>




<h> </h>
<br>
 <h> 退保满期情况（不含万能投连） </h>
 <?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
if ($_SERVER["REQUEST_METHOD"] == "POST") {  
    // 获取表单数据  
    $zyear = $_POST['zyear'];  
    $zmonthS = $_POST['zmonthS'];  
}  
    // 构建SQL查询  
    $sql = "
   declare  @zyear int ;  set  @zyear = $zyear;----------------------输入期间
   declare  @zmonthS int ;  set  @zmonthS = $zmonthS;  -----------------
with  temp0 as( 
select *   FROM [DJSX].[dbo].[balance]  
where  科目 = '6511020000' or  科目 = '6531000000' ) ,
temp1  as (
select  substring([公司代码],1,3) as 分公司代码,    分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品]  ,[产品描述],  sum([本期余额]) as 当月满期退保 from temp0
where 会计年度 = @zyear 
and  会计期间 = @zmonthS
group by  substring([公司代码],1,3)  ,分公司 ,[科目],[科目描述],[渠道],[渠道描述],[产品],[产品描述]
)

select 分公司代码 ,分公司 ,
sum( case when  渠道 like '103%' and  科目 = '6511020000' then 当月满期退保 else 0 end )/10000  as 银邮代理@满期给付 ,
sum( case when  渠道 in('104001','104002')  and  科目 = '6511020000' then 当月满期退保 else 0 end )/10000  as 保险专业中介@满期给付 ,
sum( case when  渠道 like '101%'  and  科目 = '6511020000'then 当月满期退保 else 0 end )/10000  as 个人代理@满期给付 ,
sum( case when  渠道 not like '101%'  and  渠道 not like '103%' and 渠道 not in ('104001','104002')  and  科目 = '6511020000' then 当月满期退保 else 0 end )/10000  as 其他@满期给付 ,
sum( case when    科目 = '6511020000' then 当月满期退保 else 0 end )/10000    as 小计1,
sum( case when ( [产品描述] not like '%投资连结%' and    [产品描述] not like '%分红%' and  [产品描述] not like '%万能%')   and  科目 = '6531000000' then 当月满期退保 else 0 end )/10000  as 普通寿险@退保 ,
sum( case when  [产品描述] like '%分红%'  and  科目 = '6531000000'    then 当月满期退保 else 0 end )/10000  as 分红险@退保 ,
sum( case when  [产品描述] like '%万能%'   and  科目 = '6531000000'   then 当月满期退保 else 0 end )/10000  as 万能险@退保 ,
sum( case when  [产品描述] like '%投资连结%'   and  科目 = '6531000000'   then 当月满期退保 else 0 end )/10000  as 投连险@退保 ,
sum( case when 科目 = '6531000000'  then 当月满期退保 else 0 end  )/10000    as 小计2,
sum( 当月满期退保 )/10000  as 合计
from temp1
group by 分公司代码,分公司
order by 分公司代码 ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
// 关闭数据库连接  
$conn = null;  
?>
<br><br><br>
	
