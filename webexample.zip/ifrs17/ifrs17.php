<!DOCTYPE html>
<html>
<body>
<style>
    th:nth-child(1) { width: 25%; }
    th:nth-child(2) { width: 5%; }
    th:nth-child(3) { width: 5%; }
    th:nth-child(4) { width: 65%; }
</style>
<h2>IFRS9/17 培训资料（持续更新中）</h2>
<br>
<h2>项目组织</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>公司发文</th>
    <th>PDF</th>
    <th>备注1</th>
    <th>备注2</th>
  </tr>
  <tr>
    <td style="text-align:left;" >关于实施新会计准则的通知</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/项目组织/关于实施新会计准则的通知.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" ></td>
  </tr>
   <tr>
    <td style="text-align:left;" >附件1. 实施新会计准则专项工作组成员名单</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/项目组织/附件1. 实施新会计准则专项工作组成员名单.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" ></td>
  </tr>
   <tr>
    <td style="text-align:left;" >附件2. 集团及子公司执行组各条线主要职责</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/项目组织/附件2. 集团及子公司执行组各条线主要职责.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" ></td>
   <tr>
    <td style="text-align:left;" >附件3.实施新会计准则专项工作组工作规则</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/项目组织/附件3.实施新会计准则专项工作组工作规则.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" ></td>
  </tr>
  </tr>
</table>
</body>
</html>
	 
	
		  
<!DOCTYPE html>
<html>
<body>

<style>
    th:nth-child(1) { width: 25%; }
    th:nth-child(2) { width: 5%; }
    th:nth-child(3) { width: 5%; }
    th:nth-child(4) { width: 65%; }
</style>

<br>		  
<h2>一、启动会/高管培训资料</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>内容</th>
    <th>PPT</th>
    <th>视频</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:left;" >启动会-新会计准则介绍（2023.10.17启动会）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/高管培训启动会/【安永】新会计准则介绍（10.17启动会）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/高管培训启动会/新会计准则启动会_会议录屏.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >整体项目介绍和准则解释</td>
    </tr>
  <tr>
    <td style="text-align:left;" >高管培训会-新会计准则培训与上市公司结果分析（2024.8.22高管培训会）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/高管培训启动会/【大家保险集团】新会计准则培训与上市公司结果分析_20240822.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/高管培训启动会/20240822新会计准则培训会录屏.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >新会计准则培训与上市公司结果分析</td>
  </tr>
   <tr>
    <td style="text-align:left;" >新准则相关词汇释义表</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/新准则相关词汇释义表.pdf" target="_blank">(PDF)</a></td>
     <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/新准则相关词汇释义表.docx" target="_blank">(doc)</a></td>
    </td>
    <td style="text-align:left;" ></td>
  </tr>
</table>

<h2>二、寿险IFRS17培训资料</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>内容</th>
    <th>PPT</th>
    <th>视频</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:left;" >（寿险）1.IFRS 17准则培训材料（一）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）1.IFRS 17准则培训材料（一）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）1.IFRS 17准则培训材料（一）.mkv";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第1章 准则的应用范围”和“第2章 合同分组及确认”</td>
  </tr>
  <tr>
    <td style="text-align:left;" >（寿险）2.IFRS 17准则培训材料（二）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）2.IFRS 17准则培训材料（二）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）2.IFRS 17准则培训材料（二）.mkv";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第3章 履约现金流的计量”和“第4章 费用分类”</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）3.IFRS 17准则培训材料（三）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）3.IFRS 17准则培训材料（三）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）3.IFRS 17准则培训材料（三）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第5章 一般计量模型BBA”</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）4.IFRS 17准则培训材料（四）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）4.IFRS 17准则培训材料（四）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）4.IFRS 17准则培训材料（四）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第6章 分红合同”</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）5.IFRS 17准则培训材料（五）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）5.IFRS 17准则培训材料（五）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）5.IFRS 17准则培训材料（五）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第7章 保费分配法(PAA)”和“第8章 过渡期处理“</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）6.IFRS 17准则培训材料（六）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）6.IFRS 17准则培训材料（六）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）6.IFRS 17准则培训材料（六）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第9章 再保险处理”和“第10章 财务核算、列报及披露“</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）7.IFRS 17准则培训材料（串讲_上）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）7.IFRS 17准则培训材料（串讲_上）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）7.IFRS 17准则培训材料（串讲_上）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >串讲：”第1章 BBA计量合同“ 和 ”第2章 间接分红的保险合同“</td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）7.IFRS 17准则培训材料（串讲_下）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）7.IFRS 17准则培训材料（串讲_上）.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）7.IFRS 17准则培训材料（串讲_下）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >串讲：”第3章 直接分红保险合同“ 和 ”第4章 PAA计量合同“ </td>
  </tr>
<!--                     添加项目                        -->
  <tr>
    <td style="text-align:left;" >（寿险）8.IFRS 17准则培训材料-回顾</td>
    <td><a href="" target="_blank"></a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs17培训材料/寿险/（寿险）8. 新保险合同准则培训视频（安永）-新会计准则重点讲解视频.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍新准则的主要影响、新旧准则报表主要变动等</td>
  </tr>
  </table>
  		  
  
  <h2>三、寿险IFRS9培训资料</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>内容</th>
    <th>PPT</th>
    <th>视频</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:left;" >1.IFRS9会计政策培训_第一次培训（上）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/1.IFRS9会计政策培训_第一次培训.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/1.IFRS9会计政策培训_第一次培训（上）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第1章 准则背景介绍以及行业实施情况”</td>
  </tr>
   
<!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >1.IFRS9会计政策培训_第一次培训（下）</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/1.IFRS9会计政策培训_第一次培训.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/1.IFRS9会计政策培训_第一次培训（下）.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“第2章 准则解读”和“第3章 准则影响分析”</td>
  </tr>

<!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >2.IFRS9会计政策培训_第二次培训</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/2.IFRS9会计政策培训_第二次培训.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/2.IFRS9会计政策培训_第二次培训.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“新金融工具准则分类与计量介绍”</td>
  </tr>

<!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >3.IFRS9会计政策培训_第三次培训</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/3.IFRS9会计政策培训_第三次培训-Final.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/3.IFRS9会计政策培训_第三次培训.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“新金融工具准则估值介绍”</td>
  </tr>
  		  
<!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >4.IFRS9会计政策培训_第四次培训</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/4.IFRS9会计政策培训_第四次培训-FINAL.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/4.IFRS9会计政策培训_第四次培训.mp4";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank">(视频）</a>
    </td>
    <td style="text-align:left;" >主要介绍“新金融工具准则减值介绍”</td>
  </tr>
  		  
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >5.普华培训1</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/普华培训/普华10.25商誉&房地产减值—会计与评估实务分享.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank"></a>
    </td>
    <td style="text-align:left;" >普华：商誉&房地产减值—会计与评估实务分享</td>
  </tr>
  		  
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >5.普华培训2</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/普华培训/普华10.25新金融工具相关准则及资产估值减值培训.pdf" target="_blank">(PPT)</a></td>
    <td>
      <?php
      $video_file = "";
      ?>
      <a href="play_video.php?video=<?php echo urlencode($video_file); ?>" target="_blank"></a>
    </td>
    <td style="text-align:left;" >普华：新金融工具相关准则及资产估值减值培训</td>
  </tr>
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >6.大家保险新金融工具准则项目阶段汇报</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/6.大家保险新金融工具准则项目阶段汇报20240529.pdf" target="_blank">(PPT)</a></td>
    <td></td>
    <td style="text-align:left;" >安永：2024年05月29日汇报</td>
  </tr>
  </table>



<h2>四、工作汇报材料/不定期培训</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>内容</th>
    <th>PDF</th>
    <th>视频</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:left;" >新会计准则项目月度汇报1_保险合同准则-寿险类</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/月度工作会材料/新会计准则项目月度汇报1_保险合同准则-寿险类_20231128.pdf" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2023年11月28日-汇报材料</td>
  </tr>
  <tr>
    <td style="text-align:left;" >新会计准则项目月度汇报2_保险合同准则-财险</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/月度工作会材料/新会计准则项目月度汇报2_保险合同准则-财险_20231128.pdf" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2023年11月28日-汇报材料</td>
  </tr>
   <tr>
    <td style="text-align:left;" >新会计准则项目月度汇报3_金融工具准则</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/月度工作会材料/新会计准则项目月度汇报3_金融工具准则_20231129.pdf" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2023年11月28日-汇报材料</td>
  </tr>
  <tr>
    <td style="text-align:left;" >大家人寿-新保险合同准则互动测试(模拟)_20240709</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/互动测试/【大家人寿】新保险合同准则互动测试(模拟)_20240709.PDF" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2024年7月10日-互动测试(模拟)汇报</td>
 </tr>
  <tr>
    <td style="text-align:left;" >大家人寿-新保险合同准则互动测试(模拟)_20240805</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/互动测试/【大家人寿】新保险合同准则互动测试(模拟)_20240805.PDF" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2024年8月7日-互动测试(模拟)汇报</td>
  </tr>
  <tr>
    <td style="text-align:left;" >大家人寿-CAS 22&CAS 25互动分享20240709</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/互动测试/大家人寿CAS 22&CAS 25互动分享20240709.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2024年7月10日-CAS 22&CAS 25</td>
  </tr>
  <tr>
    <td style="text-align:left;" >大家人寿-新会计准则咨询项目-0819-合并I9</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/月度工作会材料/新会计准则咨询项目-0819-合并I9.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2024年8月19日</td>
  </tr>
  <tr>
    <td style="text-align:left;" >大家人寿-新会计准则培训与上市公司结果分析</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/月度工作会材料/新会计准则培训与上市公司结果分析_20240822.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >2024年8月22日</td>
  </tr>
</table>

<h2>五、上市公司审计报告</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>公司</th>
    <th>PDF</th>
    <th>视频</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:center;" >中国平安</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/中国平安：中国平安2023年年度报告.PDF" target="_blank">(PDF)</a></td>
   <td style="text-align:left;" ></td>
    <td style="text-align:left;" >中国平安：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >中国人寿</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/中国人寿：中国人寿2023年年度报告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >中国人寿：2023年度报告</td>
  </tr>
   <tr>
    <td style="text-align:center;" >中国人保</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/中国人保：中国人保2023年度已审财务报表.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >中国人保：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >新华保险</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/新华保险：2023年度财务报表及审计报告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >新华保险：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >阳光人寿</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/阳光人寿：2023年全年业绩公告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >阳光人寿：2023年度报告</td>
  </tr>
    
   <tr>
    <td style="text-align:center;" >中国太保</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/中国太保：中国太保2023年年度报告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >中国太保：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >中国太平</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/中国太平：中国太平2023年年度报告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >中国太平：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >友邦人寿</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/友邦人寿：友邦人寿2023年年度报告.PDF" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >友邦人寿：2023年度报告</td>
  </tr>
  <tr>
    <td style="text-align:center;" >2023年度保险公司上市报告-新准则财务结果分析</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/上市公司审计报告/2023年度保险公司新准则财务结果分析_20240510.pdf" target="_blank">(PDF)</a></td>
     <td style="text-align:left;" ></td>
    <td style="text-align:left;" >上市公司2023年度财务结果分析-20240510</td>
  </tr>
    
</table>
</body>
</html>



<!DOCTYPE html>
<html>
<body>
<style>
    th:nth-child(1) { width: 25%; }
    th:nth-child(2) { width: 5%; }
    th:nth-child(3) { width: 5%; }
    th:nth-child(4) { width: 65%; }
</style>
<br>
<h2>六、准则及外部链接等</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>名称</th>
    <th>PDF/链接</th>
    <th>备注1</th>
    <th>备注2</th>
  </tr>
  <tr>
    <td style="text-align:left;" >安永培训资料分享网盘链接</td>
    <td><a href="https://drive.weixin.qq.com/s?k=AHoAHAf0AA0l2SqInS" target="_blank">(链接)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >需要通过企业微信登录</td>
  </tr>
  <tr>
    <td style="text-align:left;" >企业会计准则第25号——保险合同</td>
    <td><a href="https://kjs.mof.gov.cn/zt/kjzzss/kuaijizhunzeshishi/202202/t20220224_3790240.htm" target="_blank">(链接)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >（财会〔2020〕20号）</td>
  </tr>
   <tr>
    <td style="text-align:left;" >企业会计准则第22号——金融工具确认和计量</td>
    <td><a href="https://kjs.mof.gov.cn/zt/kjzzss/kuaijizhunzeshishi/201709/t20170908_2694655.htm" target="_blank">(链接)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" >（财会〔2017〕7号）</td>
  </tr>
   <tr>
    <td style="text-align:left;" >普华：IFRS 17：保险合同</td>
    <td><a href="https://www.pwccn.com/zh/services/audit-and-assurance/capabilities/fra/ifrs/ifrs17-insurance-contracts.html" target="_blank">(链接)</a></td>
    <td style="text-align:left;" ></td>
    <td style="text-align:left;" ></td>
  </tr>
   <tr>
    <td style="text-align:left;" >IFRS9与IFRS17联动下的资产负债管理优化</td>
    <td><a href="https://mp.weixin.qq.com/s?__biz=MzUzMDM5NTczOQ==&mid=2247504450&idx=1&sn=f0d9127565e2a5ddc71b023c7991fec3&chksm=fa50f576cd277c60c838cfc1271e45ec13f8fd72a5be8a053e7899081898391f8c935d92ff94&mpshare=1&srcid=1020ipO8rYRoNNTk2sdMQSCj&sharer_shareinfo=3c7c84894347a294ad495ef54a4cb8ab&sharer_shareinfo_first=878285c9dd498d5573e1c83b392fcf48&from=timeline&scene=2&subscene=2&clicktime=1698225859&enterid=1698225859&sessionid=0&ascene=45&fasttmpl_type=0&fasttmpl_fullversion=6912672-zh_CN-zip&fasttmpl_flag=0&realreporttime=1698225859605&devicetype=android-31&version=4.1.22.8031&nettype=cmnet&lang=zh_CN&countrycode=CN&exportkey=n_ChQIAhIQpnJ9wY4TNAAZF6a6hQVBwBLvAQIE97dBBAEAAAAAAHCBJZZ5DhgAAAAOpnltbLcz9gKNyK89dVj01GTbyfFvivg3VbI1r9oZTnSbzOQbC9KEJhMTLgWGlhJtIIs%2BbGueDwQVUtFLAFqf%2FmEPqEhDH8VN3nXHA0qicCN68%2Folv9az6RDCrXoo5g7Odh5g7Pb4x8G89Jw33vFI1Qu8f4GtFB2n9lghzMo9U8FehLDP4nrGPik3%2BnAO0zcVXnUSrbxkGX20j67OBH2jfEgKuqw%2B2Do1fmmnweFJSzBeRqKvEyxvG2YKaL%2FEHj97QMlpCzj%2BRN2ZteJIhS2BibbGdVy91Jbg&pass_ticket=LB4PAdvnmKqfkmcmWJzBhlMbOcE0is5rmoDI%2FhLkQBZF%2BPnTGjFXeZ2XUSVIlvb%2F&wx_header=3&platform=win&nwr_flag=1#wechat_redirect" target="_blank">(链接)</a></td>
    <td style="text-align:left;" >领导分享</td>
 <td style="text-align:left;" >20周年 | 人保资产袁新良等</td>
  </tr>
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >IFRS17 对保险公司经营管理的影响</td>
    <td><a href="https://mp.weixin.qq.com/s?__biz=Mzg5ODY2ODEyMg==&mid=2247501013&idx=1&sn=d351eef7aa8fa8e29cc5dadca61b6702&chksm=c05d87e0f72a0ef6fb1fcb367a9816c701ea11dcf8b8fe005e2a1b0508458d8e8565e3bcbd0d&mpshare=1&scene=1&srcid=1028kWqAClRKq3J2F2ASt39D&sharer_shareinfo=3ad09e4df853a9304ecb4d11c9c17f6e&sharer_shareinfo_first=3ad09e4df853a9304ecb4d11c9c17f6e&version=4.1.22.8031&platform=win&nwr_flag=1#wechat_redirect" target="_blank">(链接)</a></td>
    <td style="text-align:left;" >领导分享</td>
    <td style="text-align:left;" >作者｜ 班颖杰 孙敏清「人保再保险股份有限公司财务管理部」《中国保险》2023年第10期</td>
  </tr>
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >IFRS9新金融工具准则实施的方案建设及落地
</td>
    <td><a href="/d/WWW2/IFRS17安永培训资料/培训资料/ifrs9培训材料/IFRS9新金融工具准则（人保资产）.pdf" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" >领导分享</td>
    <td style="text-align:left;" >人保资产  王梅等</td>
  </tr>
 <!--                     添加项目                        -->
   <tr>
    <td style="text-align:left;" >保险新旧会计准则适用差异有多大？人保寿险一季度净利润相差超50亿
</td>
    <td><a href="https://mp.weixin.qq.com/s?__biz=MjM5OTExMjYwMA==&mid=2670249508&idx=8&sn=65cb7824c3509a25e6c6b0eab53a8276&chksm=bc1c1cd38b6b95c5e5412f4ab51e5104ba9cc71e97fc1c29e9c256edc5099ec0add3b8b849b7&mpshare=1&scene=1&srcid=0603k4PF9qYSiImMISl9td7B&sharer_shareinfo=cf684530b45d9e7ceb578085cca118ba&sharer_shareinfo_first=9a6437ae20560506428cfa937c2c7a20&version=4.1.22.8031&platform=win&nwr_flag=1#wechat_redirect" target="_blank">(链接)</a></td>
    <td style="text-align:left;" >领导分享</td>
    <td style="text-align:left;" >姜鑫 经济观察报</td>
  </tr>
</table>
</body>
</html>
 
	 
	
<?php

// 设置日志文件路径  
$logFile = '../access.log';

// 获取当前页面的URL  
$pageUrl = $_SERVER['REQUEST_URI'];

// 获取用户代理字符串  
$userAgent = $_SERVER['HTTP_USER_AGENT'];

// 获取访问者的IP地址  
$ipAddress = $_SERVER['REMOTE_ADDR'];

// 设置时区并获取当前时间  
date_default_timezone_set('Asia/Shanghai');
$currentTime = date('Y-m-d H:i:s');

// 构建日志条目，使用制表符作为分隔符  
$logMessage = "{$currentTime}\t{$ipAddress}\t{$userAgent}\t{$pageUrl}\n";

// 尝试写入日志文件  
try {
    // 使用 'a' 模式打开文件以追加内容，如果文件不存在则创建它  
    $fileHandle = fopen($logFile, 'a');
    if ($fileHandle) {
        fwrite($fileHandle, $logMessage);
        fclose($fileHandle);
    } else {
        // 处理文件打开失败的情况  
        error_log("Failed to open log file: {$logFile}");
    }
} catch (Exception $e) {
    // 处理异常  
    error_log("Exception caught while writing to log file: " . $e->getMessage());
}

?>



<?php
//记录登录
// 数据库连接配置
$serverName = "localhost";
$connectionOptions = array(
    "dbname" => "sys",
    "username" => "root",
    "password" => "mysql",
    "charset" => "utf8mb4"
);
try {
    // 创建 PDO 实例来连接 MySQL
    $conn = new PDO("mysql:host=$serverName;dbname=" .$connectionOptions['dbname'], $connectionOptions['username'], $connectionOptions['password']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // 设置错误模式为异常

    // 获取当前页面的URL
    $pageUrl = $_SERVER['REQUEST_URI'];

    // 获取用户代理字符串
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // 获取访问者的IP地址
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // 设置时区并获取当前时间
    date_default_timezone_set('Asia/Shanghai');
    $currentTime = date('Y-m-d H:i:s');

    // 准备 SQL 插入语句
    $sql = "INSERT INTO view_records (IPAddress, UserAgent, PageViewed, viewdatetime)  
            VALUES (?, ?, ?, ?)";

   $pageUrl = urldecode($pageUrl);
    // 准备要绑定的参数
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $ipAddress);
    $stmt->bindParam(2, $userAgent);
    $stmt->bindParam(3, $pageUrl);
    $stmt->bindParam(4, $currentTime);

    // 执行 SQL 插入语句
    $stmt->execute();

    // 关闭数据库连接
    $conn = null;
} catch (PDOException $e) {
    echo "Error: " .$e->getMessage();
    die();
}
?>

 


 