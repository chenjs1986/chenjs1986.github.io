<!DOCTYPE html>
<html>
<body>

<?php
$video_file = urldecode($_GET['video']);
?>


<video width="936" height="702" controls> 
  <source src="<?php echo $video_file; ?>" type="video/mp4">
  Your browser does not support the video tag.
</video>

</body>
</html>
