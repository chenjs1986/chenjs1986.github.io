<!DOCTYPE html>
<html>
<body>
<style>
    th:nth-child(1) { width: 30%; }
    th:nth-child(2) { width: 5%; }
    th:nth-child(3) { width:65%; }
</style>
<br>
<h2>六、准则及外部链接等</h2>
<table border="1" style="width:100%; text-align:center;">
  <tr>
    <th>公司发文</th>
    <th>PDF</th>
    <th>备注</th>
  </tr>
  <tr>
    <td style="text-align:left;" >企业会计准则第 25 号——保险合同</td>
    <td><a href="https://kjs.mof.gov.cn/zt/kjzzss/kuaijizhunzeshishi/202202/t20220224_3790240.htm" target="_blank">(PDF)</a></td>
    <td style="text-align:left;" ></td>
  </tr>
   <tr>
    <td style="text-align:left;" >普华：IFRS 17：保险合同</td>
    <td><a href="https://www.pwccn.com/zh/services/audit-and-assurance/capabilities/fra/ifrs/ifrs17-insurance-contracts.html" target="_blank">(链接)</a></td>
    <td style="text-align:left;" ></td>
  </tr>
   <tr>
    <td style="text-align:left;" >IFRS9与IFRS17联动下的资产负债管理优化</td>
    <td><a href="https://mp.weixin.qq.com/s?__biz=MzUzMDM5NTczOQ==&mid=2247504450&idx=1&sn=f0d9127565e2a5ddc71b023c7991fec3&chksm=fa50f576cd277c60c838cfc1271e45ec13f8fd72a5be8a053e7899081898391f8c935d92ff94&mpshare=1&srcid=1020ipO8rYRoNNTk2sdMQSCj&sharer_shareinfo=3c7c84894347a294ad495ef54a4cb8ab&sharer_shareinfo_first=878285c9dd498d5573e1c83b392fcf48&from=timeline&scene=2&subscene=2&clicktime=1698225859&enterid=1698225859&sessionid=0&ascene=45&fasttmpl_type=0&fasttmpl_fullversion=6912672-zh_CN-zip&fasttmpl_flag=0&realreporttime=1698225859605&devicetype=android-31&version=4.1.22.8031&nettype=cmnet&lang=zh_CN&countrycode=CN&exportkey=n_ChQIAhIQpnJ9wY4TNAAZF6a6hQVBwBLvAQIE97dBBAEAAAAAAHCBJZZ5DhgAAAAOpnltbLcz9gKNyK89dVj01GTbyfFvivg3VbI1r9oZTnSbzOQbC9KEJhMTLgWGlhJtIIs%2BbGueDwQVUtFLAFqf%2FmEPqEhDH8VN3nXHA0qicCN68%2Folv9az6RDCrXoo5g7Odh5g7Pb4x8G89Jw33vFI1Qu8f4GtFB2n9lghzMo9U8FehLDP4nrGPik3%2BnAO0zcVXnUSrbxkGX20j67OBH2jfEgKuqw%2B2Do1fmmnweFJSzBeRqKvEyxvG2YKaL%2FEHj97QMlpCzj%2BRN2ZteJIhS2BibbGdVy91Jbg&pass_ticket=LB4PAdvnmKqfkmcmWJzBhlMbOcE0is5rmoDI%2FhLkQBZF%2BPnTGjFXeZ2XUSVIlvb%2F&wx_header=3&platform=win&nwr_flag=1#wechat_redirect" target="_blank">(链接)</a></td>
    <td style="text-align:left;" >20周年 | 人保资产袁新良等</td>
   <tr>
    <td style="text-align:left;" >IFRS17 对保险公司经营管理的影响</td>
    <td><a href="https://mp.weixin.qq.com/s?__biz=Mzg5ODY2ODEyMg==&mid=2247501013&idx=1&sn=d351eef7aa8fa8e29cc5dadca61b6702&chksm=c05d87e0f72a0ef6fb1fcb367a9816c701ea11dcf8b8fe005e2a1b0508458d8e8565e3bcbd0d&mpshare=1&scene=1&srcid=1028kWqAClRKq3J2F2ASt39D&sharer_shareinfo=3ad09e4df853a9304ecb4d11c9c17f6e&sharer_shareinfo_first=3ad09e4df853a9304ecb4d11c9c17f6e&version=4.1.22.8031&platform=win&nwr_flag=1#wechat_redirect" target="_blank">(链接)</a></td>
    <td style="text-align:left;" >作者｜ 班颖杰 孙敏清「人保再保险股份有限公司财务管理部」《中国保险》2023年第10期</td>
  </tr>
  </tr>
</table>
</body>
</html>