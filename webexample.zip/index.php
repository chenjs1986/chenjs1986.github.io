<h1> 提醒：1.当月结账前，数据非最终状态；2.使用前，务必与SAP财务系统数据核对。</h1>
<?php  
// 数据库连接配置  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  
// 处理表单提交  
 
 
    // 构建SQL查询  
    $sql = "
 	SELECT   [科目余额表更新时间]
      ,[凭证明细表更新时间]
  FROM [DJSX].[dbo].[updaterecord]
  ";  
  
    // 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格  
echo "<table border='1'>";  
echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
echo "注：除需按日统计的数据来源《凭证明细表》外，其余财务数据都来源于《科目余额表》。";
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>财务报表</title>
</head>
<body>

	<h2>一、 财务外报报表</h2>
	<a href="/外报报表开发/寿险中介报表/寿险中介报表.html">1.寿险中介报表</a>
	<br>
	<a href="/外报报表开发/寿险意外险报表/寿险意外险报表.html">2.寿险意外险报表</a>
	<br>
	<a href="/外报报表开发/人身险公司监测报表_月/人身险公司监测报表_月.html">3.人身险公司监测报表_月</a>
	<br>
	<a href="/外报报表开发/寿险经营情况表-保费满期退保/寿险经营情况表-保费满期退保.html">4.寿险经营情况表-保费满期退保</a>
	<br>
	<a href="/外报报表开发/银保代理保费及佣金情况月报表/银保代理保费及佣金情况月报表_月_旧准则（规模）.html">5.1银保代理保费及佣金情况月报表-旧准则口径</a>
	<br>
	<a href="/外报报表开发/银保代理保费及佣金情况月报表_新准则口径/银保代理保费及佣金情况月报表__新准则口径.html">5.2银保代理保费及佣金情况月报表-新准则口径</a>
	<br>
	<a href="/外报报表开发/人身保险公司风险监测和监管评级指标数据/人身保险公司风险监测和监管评级指标数据_月.html">6.人身保险公司风险监测和监管评级指标数据（验证中）</a>
	<br>
	<a href="/外报报表开发/四张表to监管/四张表to监管.php">7.四张表to监管</a>
	<br>
	<h2>二、 财务内部报表</h2>
	<a href="/外报报表开发/寿险规模保费报表/寿险规模保费报表.html">1.寿险规模保费报表</a>
	<br>
	<a href="/外报报表开发/分红险公司部分红利计算/分红险公司部分红利计算.html">2.分红险公司部分红利计算</a>
	<br>
	<a href="/外报报表开发/EBS三大主表/EBS三大主表.html">3.EBS三大主表（验证中）</a>
	<br>
	<a href="/外报报表开发/业务数据明细表/业务数据明细表.html">4.业务数据明细表to精算（验证中）</a>
	<br>
	<h2> 三、财务报告图表（试用中）</h2>
	<a href="/R报表/R.php">点击链接查看详细报表</a>
	<br>
	<h2>四、其他链接</h2>
	<a href="/ifrs17/ifrs17.php">1.IFRS9/17新准则培训资料链接</a>     
	<br> 
	<a href="/east/east.php">2.1 east监管制度等链接</a>     
	<br> 
	<a href="https://idataserch.com/docs/system-test">2.2 统计信息报送制度链接</a>     
	<br> 
	<a href="/coa/coa.html">3.查看COA</a>     
	<br> 

</body>
</html>



<?php
//记录登录
// 数据库连接配置
$serverName = "localhost";
$connectionOptions = array(
    "dbname" => "sys",
    "username" => "root",
    "password" => "mysql",
    "charset" => "utf8mb4"
);
try {
    // 创建 PDO 实例来连接 MySQL
    $conn = new PDO("mysql:host=$serverName;dbname=" .$connectionOptions['dbname'], $connectionOptions['username'], $connectionOptions['password']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // 设置错误模式为异常

    // 获取当前页面的URL
    $pageUrl = $_SERVER['REQUEST_URI'];

    // 获取用户代理字符串
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    // 获取访问者的IP地址
    $ipAddress = $_SERVER['REMOTE_ADDR'];

    // 设置时区并获取当前时间
    date_default_timezone_set('Asia/Shanghai');
    $currentTime = date('Y-m-d H:i:s');

    // 准备 SQL 插入语句
    $sql = "INSERT INTO view_records (IPAddress, UserAgent, PageViewed, viewdatetime)  
            VALUES (?, ?, ?, ?)";

   $pageUrl = urldecode($pageUrl);
    // 准备要绑定的参数
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(1, $ipAddress);
    $stmt->bindParam(2, $userAgent);
    $stmt->bindParam(3, $pageUrl);
    $stmt->bindParam(4, $currentTime);

    // 执行 SQL 插入语句
    $stmt->execute();

    // 关闭数据库连接
    $conn = null;
} catch (PDOException $e) {
    echo "Error: " .$e->getMessage();
    die();
}
?>

