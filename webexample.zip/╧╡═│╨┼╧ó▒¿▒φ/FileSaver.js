function exportToExcel() {  
 
    data = $results;  
  
    // 将数据转换为工作簿对象  
    var wb = XLSX.utils.book_new();  
    var ws = XLSX.utils.json_to_sheet(data);  
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");  
  
    // 生成 Excel 文件的二进制字符串表示  
    var wbout = XLSX.write(wb, { bookType:'xlsx', type:'binary' });  
  
    // 创建一个 Blob 对象来表示文件  
    var blob = new Blob([s2ab(wbout)], {type:"application/octet-stream"});  
  
    // 使用 FileSaver.js 保存文件  
    saveAs(blob, "data.xlsx");  
}  
  
// 将二进制字符串转换为 Array Buffer  
function s2ab(s) {  
    var buffer = new ArrayBuffer(s.length);  
    var view = new Uint8Array(buffer);  
    for (var i=0; i<s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;  
    return buffer;  
}