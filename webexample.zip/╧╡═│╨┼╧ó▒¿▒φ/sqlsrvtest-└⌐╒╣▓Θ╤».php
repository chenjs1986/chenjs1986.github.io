<?php
if (extension_loaded('sqlsrv')) {
    echo 'SQLSRV已经成功加载。';
} else {
    echo '未能加载SQLSRV。';
}
?>