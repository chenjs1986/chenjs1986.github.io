<?php
Phpinfo();
?>