<?php  
// 假设你已经建立了到SQL Server的连接，并且$conn是有效的连接资源  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
   
// 连接到SQL Server  
$conn = sqlsrv_connect($serverName, $connectionOptions);  
if ($conn === false) {  
    die(print_r(sqlsrv_errors(), true));  
}  
  
// 从表单获取用户输入的SQL（示例）  
$userSql = isset($_POST['sql']) ? $_POST['sql'] : '';  
  
// 假设你已经做了足够的验证，现在执行SQL  
try {  
    $stmt = sqlsrv_query($conn, $userSql);  
    if ($stmt === false) {  
        // SQL执行失败，显示错误  
        echo "Error in query: " . print_r(sqlsrv_errors(), true);  
    } else {  
        // SQL执行成功，处理结果集  
        if (sqlsrv_has_rows($stmt)) {  
            echo "<table border='1'>";  

   // 假设变量 $headerPrinted 用来跟踪是否已经打印了列标题  
            $headerPrinted = false;  
              
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {    
                if (!$headerPrinted) {  
                    // 输出列标题  
                    echo "<tr>";  
                    foreach ($row as $columnName => $value) {    
                        echo "<th>" . htmlspecialchars($columnName) . "</th>";    
                    }    
                    echo "</tr>";  
                    $headerPrinted = true; // 标记列标题已打印  
                }  
                  
                // 输出行数据  
                echo "<tr>";    
                foreach ($row as $column => $value) {    
                    echo "<td>" . htmlspecialchars($value) . "</td>";    
                }    
                echo "</tr>";    
            }    
            echo "</table>";    
        } else {    
            echo "Query returned no results.";    
        }    
  
        // 释放资源  
        sqlsrv_free_stmt($stmt);  
    }  
} catch (Exception $e) {  
    // 捕获并处理任何异常  
    echo "An error occurred: " . $e->getMessage();  
}  
  
// 关闭连接  
sqlsrv_close($conn);  
?>  
  
<!DOCTYPE html>  
<html lang="en">  
<head>  
    <meta charset="UTF-8">  
    <title>Run SQL Query</title>  
</head>  
<body>  
  
<h1>Run SQL Query</h1>  
<form method="post" action="">  
    <textarea name="sql" rows="20" cols="200"></textarea>  
    <br>      <br>  
    <input type="submit" value="Run Query">  
</form>  
  
<!-- 展示查询结果的表格将在这里显示 -->  
  
</body>  
 <p>注1： 要查询SQL Server中的所有数据库，您可以使用以下SQL查询：    <br>  
SELECT name   FROM sys.databases   ORDER BY name    <br>  <br> 

注2：如果您想要查询所有数据库中的所有表，可以使用以下SQL查询：<br> 

EXEC sp_MSforeachdb '<br> 
USE [?];<br> 
SELECT name    FROM sys.tables   ORDER BY name '<br> <br> 
请注意，这些查询将返回数据库和表的名称，您可以根据需要进行进一步的操作或筛选。  </p>  
</html>