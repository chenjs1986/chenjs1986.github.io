<?php
$serverName = "127.0.0.1,1433"; // SQL Server主机地址
$connectionOptions = array(
    "Database" => "DJSX", // 指定要连接的数据库名称
    "Uid" => "admin", // 指定登录SQL Server的用户名
    "PWD" => "admin" // 指定登录SQL Server的密码
);
// 尝试连接到SQL Server
try {
    $conn = sqlsrv_connect($serverName, $connectionOptions);
    if ($conn) {
        echo "成功连接到SQL Server！";
    } else {
        die("无法连接到SQL Server：".print_r(sqlsrv_errors(), true));
    }
} catch (Exception $e) {
    die("发生错误：".$e->getMessage());
} finally {
    // 关闭与SQL Server的连接
    sqlsrv_close($conn);
}

?>