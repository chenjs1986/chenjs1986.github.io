  



<h>一、科目层级表配置检查</h>

<?php  
// 数据库连接信息11111111111111111111111111111111111111111111111111111111111111  
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
// SQL查询-----------科目层级表配置检查--------------------

$sql = " select distinct  科目 , 科目描述   from  [DJSX].[dbo].[balance]  where 科目 not in ( SELECT   [总账科目]  FROM [DJSX].[dbo].[SAP科目层级配置] )  ";  
  
// 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $columnName) {  
    echo "<th>" . $columnName . "</th>";  
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $columnName) {  
        echo "<td>" . (isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') . "</td>";  
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>
<br>
<br>

<h>二、数据导入情况检查</h>
<?php  
// 数据库连接信息  2222222222222222222222222222222222222222222222222222222
$serverName = "localhost";  
$connectionOptions = array(  
    "Database" => "DJSX",  
    "Uid" => "admin",  
    "PWD" => "admin",  
    "CharacterSet" => "UTF-8"  
);  
  

// SQL查询  -----------余额表导入情况检查--------------------
$sql = "with temp1 as ( SELECT  concat(aa.[会计年度],aa.[会计期间]) as balance期间 , count(aa.[会计年度]) as balance导入条数  ,[时间戳]   as balance时间戳  FROM [DJSX].[dbo].[balance] as aa   group by   concat(aa.[会计年度],aa.[会计期间])  ,[时间戳]  )  
, temp2 as (     SELECT CAST([期间]  AS VARCHAR(6) ) as circ新准则期间   ,[新旧准则] as 新准则 , count(1) as circ新准则导入条数 ,[时间戳]   as  circ新准则时间戳    FROM [CIRC].[dbo].[circ]   where   [新旧准则] = '新准则'   group by  [期间]  ,[新旧准则],[时间戳]  )
, temp3 as (   SELECT CAST([期间]  AS VARCHAR(6) ) as circ旧准则期间   ,[新旧准则] as 旧准则 ,count(1) as circ旧准则导入条数 ,[时间戳]   as circ旧准则时间戳    FROM [CIRC].[dbo].[circ]   where   [新旧准则] = '旧准则'   group by  [期间]  ,[新旧准则],[时间戳]    )
, temp4 as (   select concat([会计年度],[会计期间]) as SAP_voucher期间 ,count(1) as SAP_voucher导入条数,count(distinct  [过帐日期]) as SAP_voucher天数 ,[时间戳]    as SAP_voucher时间戳 from  [DJSX].[dbo].[SAP_voucher]  	group by  [会计年度],会计期间,[时间戳]  ) 
, temp5 as (   select replace([账期],'-','') as 经分规模保费期间  ,count(1) as 经分规模保费导入条数 ,sum([金额]) as 经分规模保费规模保费  from   [DJSX].[dbo].[经分平台规模保费收入]  	 group by [账期]  )
, temp6 as (   select concat([会计年度],[会计期间]) as pzdetail期间  ,COUNT(1) as pzdetail导入条数  ,count(distinct  [过帐日期]) as pzdetail天数,[时间戳]   as pzdetail时间戳 from  [DJSX].[dbo].[pzdetail]  	group by  [会计年度],会计期间,[时间戳] )
	
select aa.* ,bb.* ,cc.* , dd.*, ee.*, ff.* from temp1 as aa 
left join  temp2 as bb
on aa.balance期间 = bb.circ新准则期间
left join  temp3 as cc
on aa.balance期间 = cc.circ旧准则期间
left join  temp4 as dd
on aa.balance期间 = dd.SAP_voucher期间
left join  temp5 as ee
on aa.balance期间 = ee.经分规模保费期间
left join  temp6 as ff
on aa.balance期间 = ff.pzdetail期间
order by aa.balance期间 "
;  
  
// 连接数据库并执行查询  
    $conn = sqlsrv_connect($serverName, $connectionOptions);  
    if ($conn === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
    $stmt = sqlsrv_query($conn, $sql);  
    if ($stmt === false) {  
        die(print_r(sqlsrv_errors(), true));  
    }  
  
// 获取查询结果并赋值给$results  
$results = array();  
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {  
    $results[] = $row;  
}  
  
// 假设您已经执行了SQL查询并将结果存储在$results数组中  
// $results是一个二维数组，其中每个子数组代表一行数据，键是列名  
  
// 获取列名（即$results中第一个子数组的键）  
$columnNames = array_keys($results[0]);  
  
// 输出HTML表格   
echo "<table border='1'>";  

echo "<thead>";  
echo "<tr>";  
// 使用循环输出表头  
foreach ($columnNames as $key => $columnName) {  
    if ($key < 3) {  echo "<th style='background-color: yellow;'>" .$columnName ."</th>";    } 
       else if ($key >= 3 && $key < 7) {  echo "<th style='background-color: white;'>" .$columnName ."</th>";    } 
       else if ($key >= 7 && $key < 11) {  echo "<th style='background-color: yellow;'>" .$columnName ."</th>";   } 
       else if ($key >= 12 && $key < 15) {  echo "<th style='background-color: white;'>" .$columnName ."</th>";   } 
       else if ($key >= 15 && $key < 18) { echo "<th style='background-color: yellow;'>" .$columnName ."</th>";   } 
       else { echo "<th>" .$columnName ."</th>";  }
}  
echo "</tr>";  
echo "</thead>";  
  
// 输出表格主体  
echo "<tbody>";  
// 假设$results包含查询结果的数据  
foreach ($results as $result) {  
    echo "<tr>"; // 开始每一行的<tr>标签  
    // 使用循环输出表格数据  
    foreach ($columnNames as $key => $columnName) {  
    	 if ($key < 3) {  echo "<td style='background-color: yellow;'>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";    } 
           else if ($key >= 3 && $key < 7) { echo "<td style='background-color: white;'>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";     }
           else if ($key >= 7 && $key < 11) { echo "<td style='background-color: yellow;'>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";     }
           else if ($key >= 11 && $key < 15) { echo "<td style='background-color: white;'>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";     }
           else if ($key >= 15 && $key < 18) { echo "<td style='background-color: yellow;'>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";     }
	    else {  echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";  }
        // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符  
    }  
    echo "</tr>"; // 结束每一行的</tr>标签  
}  
echo "</tbody>";  
echo "</table>";
?>
