
<h1> 用户登录情况<h>
<br> <br> 
	
<?php
// 数据库连接配置
$serverName = "localhost";
$connectionOptions = array(
    "dbname" => "sys",
    "username" => "root",
    "password" => "mysql",
    "charset" => "utf8mb4"
);

try {
    // 创建 PDO 实例来连接 MySQL
    $conn = new PDO("mysql:host=$serverName;dbname=" .$connectionOptions['dbname'], $connectionOptions['username'], $connectionOptions['password']);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // 设置错误模式为异常

    // 准备 SQL 查询语句
    $sql = "SELECT viewdatetime as  系统登录时间  , IPAddress  as IP地址 ,PageViewed	AS 浏览页面 	,UserAgent	 as 登录设备    FROM view_records where  IPAddress <>  '10.10.72.23'  and   IPAddress <>  '10.10.9.57'   order by   viewdatetime desc ";
    // 执行 SQL 查询语句
    $stmt = $conn->query($sql);
    // 获取查询结果并赋值给$results
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // 获取列名（即$results中第一个子数组的键）
    $columnNames = array_keys($results[0]);
    // 输出HTML表格
    echo "<table border='1'>";
    echo "<thead>";
    echo "<tr>";
    // 使用循环输出表头
    foreach ($columnNames as $key => $columnName) {

            echo "<th>" .$columnName ."</th>";

    }
    echo "</tr>";
    echo "</thead>";

    // 输出表格主体
    echo "<tbody>";
    // 假设$results包含查询结果的数据
    foreach ($results as $result) {
        echo "<tr>"; // 开始每一行的<tr>标签
        // 使用循环输出表格数据
        foreach ($columnNames as $key => $columnName) {
 
                echo "<td>" .(isset($result[$columnName]) ? htmlspecialchars($result[$columnName]) : '&nbsp;') ."</td>";
 
            // 使用htmlspecialchars函数来转义可能存在的HTML特殊字符
        }
        echo "</tr>"; // 结束每一行的</tr>标签
    }
    echo "</tbody>";
    echo "</table>";

    // 关闭数据库连接
    $conn = null;
} catch (PDOException $e) {
    echo "Error: " .$e->getMessage();
    die();
}
?>
